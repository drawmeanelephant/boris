# Awesome open-source alternatives to SaaS
[](https://github.com/sindresorhus/awesome)

Awesome list of open-source startup alternatives to established SaaS products. Maintained by folks at [](https://runacap.com) 

Also checkout our [ROSS index](https://runacap.com/ross-index/): fastest-growing open-source startups, every quarter.

## Criteria
Open-source company is added to the list if: 
1. Its product is strongly based on an open-source repo 
2. It has a well-known closed-source competitor, solving a similar business problem
3. It is a private for-profit company, founded in the last 10 years
4. Its repo has 100+ stars on GitHub

Things change really fast in the startup world, so this list can neither be fully complete, nor 100% up to date.

Don't hesitate to [contribute](.github/CONTRIBUTING.md) and add new startups. Let's build the most comprehensive list together.

Any questions or suggestions? Feel free to DM project maintainer [@garrrikkotua](https://twitter.com/garrrikkotua)

--------------------

## Startup List

All startups in the list are sorted by categories and sorted in alphabetical order. If you click on the stars badge you will get to the product's repo. 
**Have a good search!**

<!-- BEGIN STARTUP LIST -->

|Category|Company|Description|GitHub Stars|Alternative to|
|:-------|:------|:----------|:----------:|:------------:|
API Gateway|[Apache APISIX](https://github.com/apache/apisix)|Cloud Native API Gateway under the Apache Software Foundation|<a href=https://github.com/apache/apisix></a>|[apigee](https://cloud.google.com/apigee)
API Platform|[Firecamp](https://firecamp.dev/)|DX first open-source API devtool|<a href=https://github.com/firecamp-dev/firecamp></a>|[Postman](https://www.postman.com/)
API Platform|[Fusio](https://github.com/apioo/fusio)|API management platform|<a href=https://github.com/apioo/fusio></a>|[Postman](https://www.postman.com/)
API Platform|[Hoppscotch](https://hoppscotch.io/)|API development ecosystem|<a href=https://github.com/hoppscotch/hoppscotch></a>|[Postman](https://www.postman.com/)
API Platform|[Keploy](https://keploy.io/)|e2e Testing and Data Mocking|<a href=https://github.com/keploy/keploy></a>|[Smartbear](https://smartbear.com/), [Newman](https://learning.postman.com/docs/running-collections/using-newman-cli/command-line-integration-with-newman/)
API Platform|[Step CI](https://stepci.com/)|API Testing and Monitoring|<a href=https://github.com/stepci/stepci></a>|[Checkly](https://www.checklyhq.com), [Postman](https://www.postman.com/)
Auth & SSO|[BoxyHQ](https://boxyhq.com)|Enterprise Readiness made simple|<a href=https://github.com/boxyhq/jackson></a>|[Auth0](https://auth0.com/)|
Auth & SSO|[Cerbos](https://cerbos.dev/)|Granular access control|<a href=https://github.com/cerbos/cerbos></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[FusionAuth](https://fusionauth.io/)|User authentication and session management framework|<a href=https://github.com/FusionAuth/fusionauth-containers></a>|[Okta](https://www.okta.com/), [Auth0](https://auth0.com/)|
Auth & SSO|[Hanko](https://www.hanko.io)|Passkey-first authentication framework|<a href=https://github.com/teamhanko/hanko></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[Keycloak](https://www.cloud-iam.com/)|User authentication and session management framework|<a href=https://github.com/keycloak/keycloak></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[OPAL (Permit.io)](https://www.opal.ac/)|Authorization administration framework (Open Policy)|<a href=https://github.com/permitio/opal></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[Ory](https://www.ory.sh/)|Identity platform|<a href=https://github.com/ory/kratos></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[Oso](https://www.osohq.com/)|Authorization building framework|<a href=https://github.com/osohq/oso></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[Supertokens](https://supertokens.io/)|User authentication and session management framework|<a href=https://github.com/supertokens/supertokens-core></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[Warrant](https://warrant.dev/)|Authorization and access control as a service|<a href=https://github.com/warrant-dev/warrant></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)
Auth & SSO|[Zitadel](https://zitadel.com/)|User authentication and session management framework|<a href=https://github.com/zitadel/zitadel></a>|[Okta](https://okta.com/), [Auth0](https://auth0.com/)|
Backend as a service|[AceBase](https://acebase.io/)|Backend server with REST APIs to manage core backend needs|<a href=https://github.com/appy-one/acebase></a>|[Firebase](https://firebase.google.com/)
Backend as a service|[Amplication](https://amplication.com/)|Backend server with REST and GraphQL APIs to manage core backend needs|<a href=https://github.com/amplication/amplication></a>|[Firebase](https://firebase.google.com/)
Backend as a service|[Appwrite](https://appwrite.io/)|Backend server with REST APIs to manage core backend needs|<a href=https://github.com/appwrite/appwrite></a>|[Firebase](https://firebase.google.com/)
Backend as a service|[CASE](https://case.app)|Lightweight Backend-as-a-Service with essential features|<a href=https://github.com/casejs/case></a>|[Firebase](https://firebase.google.com/)|
Backend as a service|[Encore](https://encore.dev/)|Backend Development Engine for cloud-based apps, APIs, and distributed systems|<a href=https://github.com/encoredev/encore></a>|[Firebase](https://firebase.google.com/)|
Backend as a service|[Kuzzle](https://kuzzle.io/kuzzle-backend/)|Backend server with REST APIs to manage core backend needs|<a href=https://github.com/kuzzleio/kuzzle></a>|[Firebase](https://firebase.google.com/)
Backend as a service|[Nhost](https://nhost.io/)|Backend server with GraphQL|<a href=https://github.com/nhost/nhost></a>|[Firebase](https://firebase.google.com/)
Backend as a service|[PocketBase](https://pocketbase.io/)|Backend server with REST APIs to manage core backend needs|<a href=https://github.com/pocketbase/pocketbase></a>|[Firebase](https://firebase.google.com/)|
Backend as a service|[Supabase](https://supabase.io/)|Backend server with REST APIs to manage core backend needs|<a href=https://github.com/supabase/supabase></a>|[Firebase](https://firebase.google.com/)
Business Intelligence|[Metabase](https://www.metabase.com/)|Business intelligence software|<a href=https://github.com/metabase/metabase></a>|[Tableau](https://www.tableau.com/), [Power BI](https://powerbi.microsoft.com/), [DataStudio](https://datastudio.google.com/)
Business Intelligence|[Preset](https://www.preset.io)|Modern BI platform powered by Apache Superset|<a href=https://github.com/apache/superset></a>|[PowerBI](https://powerbi.microsoft.com/), [Tableau](https://www.tableau.com/), [Mode Analytics](https://mode.com/)|
CMS|[Builder](https://builder.io/)|Drag and drop page builder and CMS|<a href=https://github.com/builderio/builder></a>|[Contentful](https://www.contentful.com/)
CMS|[Concrete](https://www.concretecms.com/)|CMS for teams|<a href=https://github.com/concrete5/concrete5></a>|[Contentful](https://www.contentful.com/)|
CMS|[Directus](https://directus.io/)|Data platform which wraps any database with an intuitive app|<a href=https://github.com/directus/directus></a>|[Contentful](https://www.contentful.com/)
CMS|[Ghost](https://ghost.org/)|Headless Node.js publishing platform|<a href=https://github.com/tryghost/ghost></a>|[Medium](https://www.medium.com/), [Substack](https://substack.com/)
CMS|[Netlify CMS](https://www.netlifycms.org/)|Git-based CMS for static site generators|<a href=https://github.com/netlify/netlify-cms></a>|[Contentful](https://www.contentful.com/)
CMS|[Plasmic](https://plasmic.app/)|The headless page builder for singe-page frameworks|<a href=https://github.com/plasmicapp/plasmic></a>|[Contentful](https://www.contentful.com/)|
CMS|[Strapi](https://strapi.io/)|Node.js Headless CMS to build customisable APIs|<a href=https://github.com/strapi/strapi></a>|[Contentful](https://www.contentful.com/)
CMS|[Sulu](https://sulu.io/)|Modern Symfony based CMS|<a href=https://github.com/sulu/sulu></a>|[Contentful](https://www.contentful.com/)
CMS|[Tina](https://tina.io/)|Visual editor for React websites|<a href=https://github.com/tinacms/tinacms></a>|[Contentful](https://www.contentful.com/)
CMS|[Webiny](https://www.webiny.com/)|Enterprise serverless CMS|<a href=https://github.com/webiny/webiny-js></a>|[Contentful](https://www.contentful.com/)
Cloud Data Warehouse|[Databend](https://databend.rs)|Elastic and Workload-Aware Modern Cloud Data Warehouse|<a href=https://github.com/datafuselabs/databend></a>|[Snowflake](https://www.snowflake.com)|
Cloud Development Environment|[Gitpod](https://gitpod.io)|Automated provisioning of cloud development environments with multiple git providers & IDEs|<a href=https://github.com/gitpod-io/gitpod></a>|[Codespaces](https://github.com/features/codespaces)|
Cloud Storage|[Minio](https://min.io/)|S3 compatible object storage|<a href=https://github.com/minio/minio></a>|[Amazon S3](https://aws.amazon.com/s3/)|
Cloud Storage|[Storj](https://www.storj.io/)|Decentralized cloud storage|<a href=https://github.com/storj/storj></a>|[Amazon S3](https://aws.amazon.com/s3/)|
Cloud-Native Application Protection Platform|[Deepfence ThreatMapper](https://github.com/deepfence/ThreatMapper)|Apache v2, powerful runtime vulnerability and compliance scanner for kubernetes, virtual machines, cloud and serverless.|<a href=https://github.com/deepfence/ThreatMapper></a>|[Palo Alto Prisma](https://www.paloaltonetworks.com/prisma/cloud)|
Communication|[Fonoster](https://fonoster.com/)|APIs for SMS, voice and video|<a href=https://github.com/fonoster/fonoster></a>|[Twilio](https://www.twilio.com/)|
Communication|[Novu](https://novu.co/)|Components and APIs for email, sms, direct and push|<a href=https://github.com/novuhq/novu></a>|[Courier](https://www.courier.com/), [MagicBell](https://www.magicbell.com/), [Knock](https://knock.app/)|
Community Platform|[crowd.dev](https://crowd.dev/)|Suite of community and data tools built to unlock community-led growth for your organization|<a href=https://github.com/CrowdDotDev/crowd.dev></a>|[Orbit](https://orbit.love/), [Common Room](https://www.commonroom.io/), [Commsor](https://www.commsor.com/)|
Customer Data Platform|[Jitsu](https://jitsu.com/)|Fully-scriptable data ingestion engine for modern data teams|<a href=https://github.com/jitsucom/jitsu></a>|[Segment](https://segment.com/)
Customer Data Platform|[Rudderstack](https://rudderstack.com/)|Customer data platform for developers|<a href=https://github.com/rudderlabs/rudder-server></a>|[Segment](https://segment.com/)
Customer Data Platform|[Tracardi](http://www.tracardi.com/)|Customer Data Platform with Consumer Journey automation engine|<a href=https://github.com/tracardi/tracardi></a>|[Segment](https://segment.com/), [Zapier](https://zapier.com/)
Customer Engagement|[Chaskiq](https://chaskiq.io/)|Live chat widget|<a href=https://github.com/chaskiq/chaskiq></a>|[Intercom](https://www.intercom.com/), [Zendesk](https://www.zendesk.com/)
Customer Engagement|[Chatwoot](https://www.chatwoot.com/)|Live chat widget|<a href=https://github.com/chatwoot/chatwoot></a>|[Intercom](https://www.intercom.com/), [Zendesk](https://www.zendesk.com/)
Customer Engagement|[Papercups](https://papercups.io/)|Live chat widget|<a href=https://github.com/papercups-io/papercups></a>|[Intercom](https://www.intercom.com/), [Zendesk](https://www.zendesk.com/)
Cybersecurity|[CloudQuery](https://cloudquery.io/)|Assess, audit, and evaluate the configurations of your cloud assets.|<a href=https://github.com/cloudquery/cloudquery></a>|[AWS Config](https://aws.amazon.com/config/), [GCP Cloud Asset Inventory](https://cloud.google.com/asset-inventory), [AWS GuardDuty](https://aws.amazon.com/guardduty/)|
Cybersecurity|[CrowdSec](http://crowdsec.net/)|Collaborative IPS able to analyze visitor behavior and to provide an adapted response to all kinds of attacks.|<a href=https://github.com/crowdsecurity/crowdsec></a>|[GreyNoise](https://www.greynoise.io/)|
Cybersecurity|[Faraday](https://faradaysec.com)|Open Source Vulnerability Management and Orchestration Platform|<a href=https://github.com/infobyte/faraday></a>|[Plextrac](https://plextrac.com//), [Vulcan](https://vulcan.io/)|
Cybersecurity|[Firezone](https://www.firez.one/)|VPN Server & Firewall for teams|<a href=https://github.com/firezone/firezone></a>|[OpenVPN Access Server](https://openvpn.net/access-server/)
Cybersecurity|[Gravitl](https://gravitl.com)|WireGuard virtual networking platform (VPN)|<a href=https://github.com/gravitl/netmaker></a>|[Tailscale](https://tailscale.com/), [OpenVPN](https://openvpn.net/)|
Cybersecurity|[LunaTrace](https://www.lunasec.io/)|Dependency Vulnerability Scanner and SBOM Inventory|<a href=https://github.com/lunasec-io/lunasec></a>|[GitHub Dependabot](https://github.blog/2020-06-01-keep-all-your-packages-up-to-date-with-dependabot/), [Snyk.io](https://snyk.io/), [SonaType Nexus](https://www.sonatype.com/products/vulnerability-scanner)|
Cybersecurity|[Matano](https://www.matano.dev)|Open source cloud-native security lake platform (SIEM alternative) for threat hunting, detection & response, and cybersecurity analytics at petabyte scale on AWS|<a href=https://github.com/matanolabs/matano></a>|[Splunk](https://www.splunk.com/), [Elastic Cloud](https://www.elastic.co/elastic-stack/)|
Cybersecurity|[NetBird](https://netbird.io)|Zero Configuration Mesh VPN for Business|<a href=https://github.com/netbirdio/netbird></a>|[Tailscale](https://tailscale.com/), [OpenVPN](https://openvpn.net/)|
Cybersecurity|[Nuclei](https://nuclei.projectdiscovery.io/)|Vulnerability scanner based on simple YAML based DSL|<a href=https://github.com/projectdiscovery/nuclei></a>|[Tenable Nessus](https://www.tenable.com/products/nessus)|
Design|[Modulz](https://www.modulz.app/)|Code-based tool for designing and prototyping|<a href=https://github.com/radix-ui/primitives></a>|[Figma](https://www.figma.com/)|
Design|[Penpot](https://penpot.app/)|Design & prototyping platform|<a href=https://github.com/penpot/penpot></a>|[Figma](https://www.figma.com/)|
Digital Signature|[Documenso](https://documenso.com)|Digital Signing Infrastructure|<a href=https://github.com/documenso/documenso></a>|[DocuSign](https://www.docusign.com/)|
Digital Signature|[LibreSign](https://libresign.coop/)|Digital document signer|<a href=https://github.com/LibreSign/libresign></a>|[DocuSign](https://www.docusign.com/)
E-commerce|[Bagisto](https://bagisto.com/en/)|Headless e-commerce platform|<a href=https://github.com/bagisto/bagisto></a>|[Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
E-commerce|[Medusa](https://www.medusajs.com/)|Headless e-commerce platform|<a href=https://github.com/medusajs/medusa></a>|[Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
E-commerce|[Saleor](https://saleor.io/)|Headless e-commerce platform|<a href=https://github.com/saleor/saleor></a>|[Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
E-commerce|[Shuup](https://shuup.com)|Headless e-commerce platform|<a href=https://github.com/shuup/shuup></a>|[Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
E-commerce|[Sylius](https://sylius.com/)|Headless e-commerce platform|<a href=https://github.com/sylius/sylius></a>|[Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
E-commerce|[Vendure](https://www.vendure.io/)|Headless e-commerce platform|<a href=https://github.com/vendure-ecommerce/vendure></a>|[Shopify](https://www.shopify.com/), [Ecwid](https://www.ecwid.com/)
E-commerce|[Vue Storefront](https://www.vuestorefront.io/)|Frontend for e-commerce platform|<a href=https://github.com/vuestorefront/vue-storefront></a>|[Shogun](https://getshogun.com/)
ELT / ETL|[Airbyte](https://airbyte.io/)|Data integration platform|<a href=https://github.com/airbytehq/airbyte></a>|[Fivetran](https://fivetran.com/)
ELT / ETL|[Benthos](https://benthos.dev/)|Data streaming processor with yaml-driven pipeline configuration|<a href=https://github.com/benthosdev/benthos></a>|[Fivetran](https://fivetran.com/)
ELT / ETL|[Dagster](https://dagster.io/)|Orchestration platform for data assets|<a href=https://github.com/dagster-io/dagster></a>|[Fivetran](https://fivetran.com/)
ELT / ETL|[Kestra](https://kestra.io/)|orchestration and scheduling platform|<a href=https://github.com/kestra-io/kestra></a>|[Fivetran](https://fivetran.com/)
ELT / ETL|[Orchest](https://www.orchest.io/)|No-code data pipelines builder|<a href=https://github.com/orchest/orchest></a>|[Fivetran](https://fivetran.com/)
ELT / ETL|[Prefect](https://www.prefect.io/)|Data orchestration platform for a modern data stack|<a href=https://github.com/prefecthq/prefect></a>|[Fivetran](https://fivetran.com/)
ELT / ETL|[Selefra](https://www.selefra.io/)|An open-source policy-as-code software that provides analytics for multi-cloud and SaaS.|<a href=https://github.com/selefra/selefra></a>|[Fivetran](https://fivetran.com/)
ERP|[DoliCloud](https://dolicloud.com) | Business management suite (ERP and CRM)|<a href=https://github.com/Dolibarr/dolibarr></a>|[Oracle Fusion ERP Cloud](https://www.oracle.com/erp),[Odoo](https://odoo.com/),[Microsoft Dynamics](https://dynamics.microsoft.com/)
ERP|[ERPNext](https://erpnext.com) | Agile, modern, module based Business management suite|<a href=https://github.com/frappe/erpnext>|[SAP Business One](https://www.sap.com/products/business-one.html), [Odoo](https://odoo.com/)
Email marketing|[Keila](https://www.keila.io/)|Email newsletter tool|<a href=https://github.com/pentacent/keila></a>|[Mailchimp](https://mailchimp.com), [Sendinblue](https://www.sendinblue.com)|
Enterprise Search|[AppBase](https://www.appbase.io/)|Search UI components for React and Vue|<a href=https://github.com/appbaseio/reactivesearch></a>|[Algolia](https://www.algolia.com/)
Enterprise Search|[Jina.ai](https://jina.ai/)|Neural search framework for 𝙖𝙣𝙮 kind of data (including images)|<a href=https://github.com/jina-ai/jina></a>|[Algolia](https://www.algolia.com/)
Enterprise Search|[Manticore Search](https://manticoresearch.com/)|Easy to use open source fast database for search|<a href=https://github.com/manticoresoftware/manticoresearch/></a>|[Elastic Cloud](https://www.elastic.co/elastic-stack/)
Enterprise Search|[Meilisearch](https://www.meilisearch.com/)|Typo tolerant search engine|<a href=https://github.com/meilisearch/meilisearch></a>|[Algolia](https://www.algolia.com/)
Enterprise Search|[Qdrant](https://qdrant.tech/)|Vector similarity search engine with extended filtering support|<a href=https://github.com/qdrant/qdrant></a>|[Google Vertex AI](https://cloud.google.com/vertex-ai), [Algolia](https://www.algolia.com/)|
Enterprise Search|[SeMI](https://www.semi.technology/)'s [Weaviate](https://github.com/semi-technologies/weaviate)|Real-time vector search engine|<a href=https://github.com/semi-technologies/weaviate></a>|[Google Vertex AI](https://cloud.google.com/vertex-ai), [Algolia](https://www.algolia.com/)
Enterprise Search|[TypeSense](https://typesense.org/)|Typo tolerant fuzzy search engine|<a href=https://github.com/typesense/typesense></a>|[Algolia](https://www.algolia.com/)
Enterprise Search|[Zilliz](https://zilliz.com)'s [Milvus](https://milvus.io)|Vector database for AI applications|<a href=https://github.com/milvus-io/milvus></a>|[Google Vertex AI](https://cloud.google.com/vertex-ai)
Enterprise Search|[Zinc Labs](https://www.zinclabs.io)'s [Zinc](https://github.com/prabhatsharma/zinc)|Cloud native full text search|<a href=https://github.com/prabhatsharma/zinc></a>|[Elastic Cloud](https://www.elastic.co/elastic-stack/)
Enterprise Search|[deepset](https://www.deepset.ai/)|NLP platform to build enterprise-grade semantic search|<a href=https://github.com/deepset-ai/haystack></a>|[AWS Kendra](https://aws.amazon.com/kendra/), [QnA Maker](https://www.qnamaker.ai/)|
Feature flag and toggle management|[FlagSmith](https://flagsmith.com/)|Feature Flag & Remote Config Service|<a href=https://github.com/Flagsmith/flagsmith></a>|[LaunchDarkly](https://launchdarkly.com/)
Feature flag and toggle management|[GrowthBook](https://www.growthbook.io/)|Feature flags and A/B testing|<a href=https://github.com/growthbook/growthbook></a>|[LaunchDarkly](https://launchdarkly.com/)
Feature flag and toggle management|[Unleash](https://www.getunleash.io/)|Feature flags platform|<a href=https://github.com/Unleash/unleash></a>|[LaunchDarkly](https://launchdarkly.com/)
File Hosting|[Filestash](https://www.filestash.app/)|A file manager that let you manage your data anywhere it is located|<a href=https://github.com/mickael-kerjean/filestash></a>|[Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)|
File Hosting|[Nextcloud](https://nextcloud.com/)|A personal cloud which runs on your own server|<a href=https://github.com/nextcloud/server></a>|[Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)|
File Hosting|[Owncloud](https://owncloud.com/)|A personal cloud which runs on your own server|<a href=https://github.com/owncloud/core></a>|[Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)
File Hosting|[Spacedrive](https://spacedrive.com/)|Cross-platform file manager, powered by a virtual distributed filesystem (VDFS) written in Rust|<a href=https://github.com/spacedriveapp/spacedrive></a>|[Dropbox](https://www.dropbox.com/), [Google Drive](https://drive.google.com/)|
Financial Service|[Lago](https://www.getlago.com/)|Open Source Billing API|<a href=https://github.com/getlago/lago></a>|[Stripe Billing](https://stripe.com/billing), [Chargebee](https://www.chargebee.com/)|
Financial Service|[OpenBB Terminal](https://github.com/openbb-finance/OpenBBTerminal)|Investment research for everyone|<a href=https://github.com/GamestonkTerminal/GamestonkTerminal></a>|[Bloomberg](https://www.bloomberg.com/)
Form Building|[FormKit](https://formkit.com/)| A software to help build attractive forms|<a href=https://github.com/formkit/formkit></a>|[Vueform](https://vueform.com/),[Typeform](https://www.typeform.com/)
Form Building|[Formbricks](https://formbricks.com/)| Build forms and receive & manage submission data in one platform |<a href=https://github.com/formbricks/formbricks></a>|[Typeform](https://www.typeform.com/), [Google Forms](https://forms.google.com), [React Hook Form](https://react-hook-form.com/)
Form Building|[Formio](https://form.io/)| A Form and Data Management Platform for Progressive Web Applications|<a href=https://github.com/formio/formio></a>|[Vueform](https://vueform.com/),[Typeform](https://www.typeform.com/)
Forum Software|[Discourse](https://www.discourse.org/)|A platform for community discussion|<a href=https://github.com/discourse/discourse></a>|[Tribe](https://tribe.so/), [Circle](https://circle.so/)
Forum Software|[Vanilla](https://vanillaforums.com/)|A platform for community discussion|<a href=https://github.com/vanilla/vanilla></a>|[Tribe](https://tribe.so/), [Circle](https://circle.so/)|
Graph database|[ArangoDB](https://www.arangodb.com/)|Graph database and document store|<a href=https://github.com/arangodb/arangodb></a>|[TigerGraph](https://www.tigergraph.com/), [Amazon Neptune](https://aws.amazon.com/neptune/)
Graph database|[Memgraph](https://memgraph.com/)|In-memory graph database|<a href=https://github.com/memgraph/memgraph></a>|[TigerGraph](https://www.tigergraph.com/), [Amazon Neptune](https://aws.amazon.com/neptune/)
Graph database|[Neo4j](http://neo4j.com/)|Graph database platform|<a href=https://github.com/neo4j/neo4j></a>|[TigerGraph](https://www.tigergraph.com/), [Amazon Neptune](https://aws.amazon.com/neptune/)
Graph database|[TerminusDB](https://terminusdb.com/)|Knowledge graph and document store|<a href=https://github.com/terminusdb/terminusdb></a>|[TigerGraph](https://www.tigergraph.com/), [Amazon Neptune](https://aws.amazon.com/neptune/)
Helpdesk Solution|[Peppermint](https://peppermint.sh)|Ticket Management & Helpdesk system|<a href=https://github.com/Peppermint-Lab/peppermint></a>|[Zendesk](https://www.zendesk.co.uk/)
Helpdesk Solution|[UVDesk](https://www.uvdesk.com/en/)|Ticket Management & Helpdesk system|<a href=https://github.com/uvdesk/community-skeleton></a>|[Zendesk](https://www.zendesk.co.uk/)
Internal Tools|[AppSmith](https://www.appsmith.com/)|Low-code platform for internal tools|<a href=https://github.com/appsmithorg/appsmith></a>|[Retool](https://retool.com/)
Internal Tools|[Budibase](https://budibase.com/)|Low-code platform for internal tools|<a href=https://github.com/Budibase/budibase></a>|[Retool](https://retool.com/)
Internal Tools|[ILLA Cloud](https://www.illacloud.com/)|Low-code platform for developers to build internal tools in minutes.|<a href=https://github.com/illacloud/illa-builder></a>|[Retool](https://retool.com/)
Internal Tools|[Lowdefy](https://lowdefy.com/)|YAML-based low-code platform for internal tools|<a href=https://github.com/lowdefy/lowdefy></a>|[Retool](https://retool.com/)
Internal Tools|[Tooljet](https://tooljet.io/)|Low-code framework for internal tools|<a href=https://github.com/tooljet/tooljet></a>|[Retool](https://retool.com/)
Internal Tools|[Windmill](https://windmill.dev/)|Company-wide apps and automations from minimal python or typescript scripts|<a href=https://github.com/windmill-labs/windmill></a>|[Retool](https://retool.com/)|
Localization (i18n)|[Tolgee](https://tolgee.io)|Developer & translator friendly web-based localization platform|<a href=https://github.com/tolgee/tolgee-platform></a>|[Lokalise](https://www.lokalise.com/), [Transifex](https://www.transifex.com/), [Crowdin](https://crowdin.com/), [POEditor](https://poeditor.com/)
Localization (i18n)|[inlang](https://www.inlang.com/)|Developer-first localization infrastructure built on git|<a href=https://github.com/inlang/inlang></a>|[Lokalise](https://www.lokalise.com/), [Transifex](https://www.transifex.com/), [Crowdin](https://crowdin.com/), [POEditor](https://poeditor.com/)
Log Management|[Graylog](https://www.graylog.org/)|Log management platform|<a href=https://github.com/Graylog2/graylog2-server></a>|[Splunk](https://www.splunk.com/)
Log Management|[Quickwit](https://quickwit.io/)|Cloud-native log management & analytics|<a href=https://github.com/quickwit-oss/quickwit></a>|[Elastic Cloud](https://www.elastic.co/elastic-stack/)
ML Ops|[Cortex](https://www.cortex.dev/)|Production infrastructure for machine learning|<a href=https://github.com/cortexlabs/cortex></a>|[AWS SageMaker](https://aws.amazon.com/sagemaker/)
ML Ops|[Metarank](https://metarank.ai)|AutoML style personalized ranking|<a href=https://github.com/metarank/metarank></a>|[AWS Personalize](https://aws.amazon.com/personalize/), [Tecton](https://www.tecton.ai/)|
ML Ops|[MindsDB](https://mindsdb.com/)|In-database machine learning platform|<a href=https://github.com/mindsdb/mindsdb></a>|[BigQuery ML](https://cloud.google.com/bigquery-ml/docs)|
ML Ops|[Ploomber](https://ploomber.io/)|YAML-based pipeline builder for ML models|<a href=https://github.com/ploomber/ploomber></a>|[AWS SageMaker](https://aws.amazon.com/sagemaker/)|
ML Ops|[Seldon](https://seldon.io/)|Deployment & monitoring for machine learning at scale|<a href=https://github.com/SeldonIO/seldon-core></a>|[AWS SageMaker](https://aws.amazon.com/sagemaker/), [Google Vertex AI](https://cloud.google.com/vertex-ai)|
ML Ops|[Zilliz](https://zilliz.com)'s [Towhee](https://towhee.io)|Platform for generating embedding vectors|<a href=https://github.com/towhee-io/towhee></a>|[AWS SageMaker](https://aws.amazon.com/sagemaker)|
Marketing SaaS|[Dub](https://dub.sh/)|Open-source Bitly Alternative with built-in analytics|<a href=https://github.com/steven-tey/dub></a>|[Bitly](https://bitly.com/)
Messaging|[Element](https://element.io/)|Enterprise communication platform|<a href=https://github.com/vector-im/element-web></a>|[Slack](https://slack.com/)|
Messaging|[Mattermost](https://mattermost.com/)|Enterprise communication platform for developers|<a href=https://github.com/mattermost/mattermost-server></a>|[Slack](https://slack.com/)|
Messaging|[Rocket.chat](https://rocket.chat/)|Enterprise communication platform|<a href=https://github.com/RocketChat/Rocket.Chat></a>|[Slack](https://slack.com/)|
Messaging|[Tinode](https://tinode.co/)|General instant messaging|<a href=https://github.com/tinode/chat></a>|[WhatsApp](https://www.whatsapp.com/), [Telegram](https://www.telegram.org/)|
Messaging|[Zulip](https://zulip.com/)|Team chat|<a href=https://github.com/zulip/zulip></a>|[Slack](https://slack.com/)|
Metrics store|[Cube.js](https://cube.dev/)|Headless business intelligence suite|<a href=https://github.com/cube-js/cube.js></a>|[Looker](https://looker.com/)
Metrics store|[Evidence](https://evidence.dev/)|Lightweight BI using SQL and markdown|<a href=https://github.com/evidence-dev/evidence></a>|[Looker](https://looker.com/)
Metrics store|[LightDash](https://www.lightdash.com/)|Low-code metrics layer, alternative to Looker|<a href=https://github.com/lightdash/lightdash></a>|[Looker](https://looker.com/)
Metrics store|[MLCraft](http://mlcraft.io/)|Low-code metrics layer, alternative to Looker|<a href=https://github.com/mlcraft-io/mlcraft></a>|[Looker](https://looker.com/)
Metrics store|[MetriQL](https://metriql.com/)|Headless business intelligence suite|<a href=https://github.com/metriql/metriql></a>|[Looker](https://looker.com/)
No-code database|[Baserow](https://baserow.io/)|No-code database and Airtable alternative|<a href=https://gitlab.com/bramw/baserow></a>|[AirTable](https://www.airtable.com/)
No-code database|[NocoDB](https://www.nocodb.com/)|No-code database and Airtable alternative|<a href=https://github.com/nocodb/nocodb></a>|[AirTable](https://www.airtable.com/)
No-code database|[Rowy](https://www.rowy.io/)|Extendable Airtable-like spreadsheet UI for databases|<a href=https://github.com/rowyio/rowy></a>|[AirTable](https://www.airtable.com/)|
No-code database|[Totum](https://totum.online/)|Business database for non-programmers|<a href=https://github.com/totumonline/totum-mit></a>|[AirTable](https://www.airtable.com/)|
Notetaking|[AppFlowy](https://www.appflowy.io/)|Open-source alternative to Notion|<a href=https://github.com/AppFlowy-IO/appflowy></a>|[Notion](https://www.notion.so/)
Notetaking|[Athens Research](https://www.athensresearch.org/)|Knowledge graph for research and notetaking|<a href=https://github.com/athensresearch/athens></a>|[Roam Research](https://roamresearch.com/)|
Notetaking|[Bangle.io](https://bangle.io/)|A rich note note taking web app that works on top of your locally saved Markdown files|<a href=https://github.com/bangle-io/bangle-io></a>|[Notion](https://www.notion.so/)|
Notetaking|[Boost Note](https://boostnote.io/)|Collaborative workspace for developer teams|<a href=https://github.com/BoostIO/BoostNote-App></a>|[Notion](https://www.notion.so/)|
Notetaking|[Dendron](https://www.dendron.so/)|Knowledge base plugin for VS Code|<a href=https://github.com/dendronhq/dendron></a>|[Roam Research](https://roamresearch.com/)|
Notetaking|[Joplin](https://joplinapp.org/)|Secure, Cross-platform, Open-Source  Markdown Note Taking App|<a href=https://github.com/laurent22/joplin></a>|[Evernote](https://evernote.com/), [Onenote](hhttps://www.onenote.com/n), [Roam Research](https://roamresearch.com/)|
Notetaking|[Logseq](https://logseq.com/)|Knowledge base manager|<a href=https://github.com/logseq/logseq></a>|[Roam Research](https://roamresearch.com/)|
Notetaking|[Notabase](https://notabase.io)|Powerful and easy-to-use note-taking app for networked thinking|<a href=https://github.com/churichard/notabase></a>|[Notion](https://www.notion.so/), [Roam Research](https://roamresearch.com/)|
Notetaking|[Notesnook](https://notesnook.com/)|A fully open source & end-to-end encrypted note taking alternative to Evernote.|<a href=https://github.com/streetwriters/notesnook></a>|[Evernote](https://evernote.com/), [OneNote](https://www.onenote.com/n)|
Notetaking|[Outline](https://www.getoutline.com/)|Wiki and knowledge base|<a href=https://github.com/outline/outline></a>|[Notion](https://notion.so)|
Notetaking|[Trilium.cc](https://trilium.cc/)|Personal knowledge base|<a href=https://github.com/zadam/trilium></a>|[Evernote](https://evernote.com/), [Onenote](https://www.onenote.com/)
Observability and monitoring|[Chaos Genius](https://www.chaosgenius.io/)|ML powered analytics engine for outlier/anomaly detection and root cause analysis|<a href=https://github.com/chaos-genius/chaos_genius></a>|[AWS Lookout](https://aws.amazon.com/lookout-for-metrics/), [Anodot](https://www.anodot.com/), [Sisu Data](https://sisudata.com/), [Outlier](https://outlier.ai/)
Observability and monitoring|[Grafana](https://grafana.com/)|Observability and data visualization platform|<a href=https://github.com/grafana/grafana></a>|[DataDog](https://www.datadoghq.com/), [NewRelic](https://newrelic.com/)
Observability and monitoring|[Netdata](https://www.netdata.cloud)|Application monitoring and observability platform|<a href=https://github.com/netdata/netdata></a>|[DataDog](https://www.datadoghq.com/), [NewRelic](https://newrelic.com/)
Observability and monitoring|[Sentry](https://sentry.io/)|Application monitoring with a focus on error reporting|<a href=https://github.com/getsentry/sentry></a>|[DataDog](https://www.datadoghq.com/), [NewRelic](https://newrelic.com/)
Observability and monitoring|[Signoz](https://signoz.io/)|Application monitoring and observability platform|<a href=https://github.com/signoz/signoz></a>|[DataDog](https://www.datadoghq.com/), [NewRelic](https://newrelic.com/)
Observability and monitoring|[Uptrace](https://uptrace.dev/)|Application monitoring and observability platform|<a href=https://github.com/uptrace/uptrace></a>|[DataDog](https://www.datadoghq.com/), [NewRelic](https://newrelic.com/)
Observability and monitoring|[VictoriaMetrics](https://victoriametrics.com/)|Application monitoring and observability platform|<a href=https://github.com/VictoriaMetrics/VictoriaMetrics></a>|[DataDog](https://www.datadoghq.com/), [NewRelic](https://newrelic.com/)
Password manager|[BitWarden](https://bitwarden.com/)|Password manager for teams and individuals|<a href=https://github.com/bitwarden/server></a>|[1Password](https://1password.com/)
Password manager|[Padloc](https://padloc.app/)|Password manager for teams and individuals|<a href=https://github.com/padloc/padloc></a>|[1Password](https://1password.com/)|
Password manager|[Passbolt](https://www.passbolt.com/)|Password manager for teams and individuals|<a href=https://github.com/passbolt/passbolt_api></a>|[1Password](https://1password.com/)
Platform as a service|[Coolify](https://coolify.io/)|Self-hostable Heroku alternative|<a href=https://github.com/coollabsio/coolify></a>|[Heroku](https://www.heroku.com/)|
Platform as a service|[Dokku](https://dokku.com/)|An open source PAAS alternative to Heroku|<a href=https://github.com/dokku/dokku></a>|[Heroku](https://www.heroku.com/)|
Platform as a service|[Otomi](https://otomi.io)|Self-hosted PaaS for Kubernetes|<a href=https://github.com/redkubes/otomi-core></a>|[Heroku](https://www.heroku.com/)
Platform as a service|[Porter](https://porter.run/)|Kubernetes powered PaaS that runs in your own cloud|<a href=https://github.com/porter-dev/porter></a>|[Heroku](https://www.heroku.com/)
Platform as a service|[Pulumi](https://www.pulumi.com/)|Universal Infrastructure as Code|<a href=https://github.com/pulumi/pulumi></a>|[Heroku](https://www.heroku.com/)|
Platform as a service|[Qovery](https://www.qovery.com/)|Kubernetes powered PaaS that runs in your own cloud|<a href=https://github.com/Qovery/engine></a>|[Heroku](https://www.heroku.com/)
Platform as a service|[Space Cloud](https://space-cloud.io/)|Serverless cloud deployment platform|<a href=https://github.com/spacecloud-io/space-cloud></a>|[Heroku](https://www.heroku.com/)|
Platform as a service|[dyrector.io](https://dyrector.io)|Simplify container delivery without vendor lock|<a href=https://github.com/dyrector-io/dyrectorio></a>|[Heroku](https://www.heroku.com/)|
Product Analytics|[Objectiv](https://objectiv.io/)|Product analytics infrastructure|<a href=https://github.com/objectiv/objectiv-analytics></a>|[Google Analytics](https://analytics.google.com/analytics/web/), [Amplitude](https://amplitude.com/), [Mixpanel](https://mixpanel.com/)|
Product Analytics|[PostHog](https://posthog.com/)|Product analytics platform|<a href=https://github.com/PostHog/posthog></a>|[Amplitude](https://amplitude.com/), [MixPanel](https://mixpanel.com/)
Project Management|[Focalboard](https://www.focalboard.com/)|Alternative to Trello, Notion, and Asana|<a href=https://github.com/mattermost/focalboard></a>|[Trello](https://trello.com/), [Notion](https://www.notion.so/), [Asana](https://asana.com/)|
Project Management|[OpenProject](https://www.openproject.org/)|Project management software|<a href=https://github.com/opf/openproject></a>|[Asana](https://asana.com/), [Trello](https://trello.com/)|
Project Management|[Plane](https://plane.so/)|Alternative to Linear, JIRA, Trello and Height|<a href=https://github.com/makeplane/plane></a>|[Linear](https://linear.app/), [JIRA](https://www.atlassian.com/software/jira), [Trello](https://trello.com/), [Height](https://height.app/)|
Project Management|[Taiga](https://www.taiga.io/)|Project management software|<a href=https://github.com/kaleidos-ventures/taiga-docker></a>|[Asana](https://asana.com/), [Trello](https://trello.com/), [Jira](https://www.atlassian.com/software/jira)|
Project Management|[Vikunja](https://vikunja.io/)|The to-do app to organize your next project.|<a href=https://github.com/go-vikunja/api></a>|[Todoist](https://todoist.com), [Trello](https://trello.com), [Asana](https://asana.com)|
Relational database|[PingCAP](https://en.pingcap.com/)|NewSQL database that supports HTAP workloads|<a href=https://github.com/pingcap/tidb></a>|[Amazon Aurora](https://aws.amazon.com/rds/aurora/), [Google Cloud Spanner](https://cloud.google.com/spanner/)|
Relational database|[Yugabyte](https://www.yugabyte.com/)|High-performance distributed SQL database|<a href=https://github.com/yugabyte/yugabyte-db></a>|[Amazon Aurora](https://aws.amazon.com/rds/aurora/), [Google Cloud Spanner](https://cloud.google.com/spanner/)|
Remote Desktop Application|[RustDesk](https://rustdesk.com/)|Open source virtual / remote desktop infrastructure for everyone|<a href=https://github.com/rustdesk/rustdesk></a>|[TeamViewer](https://teamviewer.com)|
Reverse ETL|[Castled](https://castled.io/)|Data synchronization framework focused on external apps|<a href=https://github.com/castledio/castled></a>|[Hightouch](https://www.hightouch.io/), [NewRelic](https://newrelic.com/)
Reverse ETL|[Grouparoo](https://www.grouparoo.com/)|Data synchronization framework|<a href=https://github.com/grouparoo/grouparoo></a>|[Hightouch](https://www.hightouch.io/)
Robotic Process Automation (RPA)|[RoboCorp](https://robocorp.com/)|Set of tooling that allows to create automation packages|<a href=https://github.com/robocorp/rcc></a>|[UiPath](https://www.uipath.com/)
Scheduling|[Cal.com](https://cal.com/)|Scheduling infrastructure, alternative to Calendly|<a href=https://github.com/calendso/calendso></a>|[Calendly](https://calendly.com/)
Session replay software|[OpenReplay](https://openreplay.com/)|Session replay stack for developers|<a href=https://github.com/openreplay/openreplay></a>|[LogRocket](https://logrocket.com/), [FullStory](https://www.fullstory.com/)
Streaming|[Glimesh](https://glimesh.tv/)|Live streaming platform|<a href=https://github.com/glimesh/glimesh.tv></a>|[Twitch](https://www.twitch.tv/)
Timeseries database|[CrateDB](https://crate.io/)|Distributed SQL database for real-time analytics of time series data|<a href="https://github.com/crate/crate"></a>|[Kdb+](https://kx.com/developers/)
Timeseries database|[InfluxDB](https://www.influxdata.com/)|Database designed to process time series data|<a href=https://github.com/influxdata/influxdb></a>|[Kdb+](https://kx.com/developers/)
Timeseries database|[QuestDB](https://questdb.io/)|Database designed to process time series data|<a href=https://github.com/questdb/questdb></a>|[Kdb+](https://kx.com/developers/)
Timeseries database|[TDengine](https://tdengine.com/?en)|Database designed to process time series data|<a href=https://github.com/taosdata/TDengine></a>|[Kdb+](https://kx.com/developers/)
Timeseries database|[TimescaleDB](https://www.timescale.com/)|Database designed to process time series data|<a href=https://github.com/timescale/timescaledb></a>|[Kdb+](https://kx.com/developers/)
Tunnelling|[Tunnelmole](https://tunnelmole.com/)|Get a Public URL for your local development enviornment |<a href=https://github.com/robbie-cahill/tunnelmole-client>|</a>[Ngrok](https://ngrok.com)
VPN as a Service|[OmniEdge](https://omniedge.io/)|No-code P2P layer-2 mesh VPN for enterprise with zero config |<a href=https://github.com/omniedgeio/omniedge></a>|[OpenVPN](https://openvpn.net), [Ngrok](https://ngrok.com), [Oray](https://www.oray.com), [AWS VPC](https://aws.amazon.com/vpc/)|
Video Conferencing|[Jitsi](https://jitsi.org/meet)|Video conferences platform and SDK|<a href=https://github.com/jitsi/jitsi-meet></a>|[Zoom](https://zoom.us/)|
Video Conferencing|[LiveKit](https://livekit.io/)|SFU and SDKs for high-performance, scalable WebRTC|<a href=https://github.com/livekit/livekit-server></a>|[Twilio](https://www.twilio.com/), [Agora](https://agora.io/)|
Video Conferencing|[OpenVidu](https://openvidu.io/)|Platform and SDKs to build on-premises WebRTC video conferences|<a href=https://github.com/OpenVidu/openvidu></a>|[Twilio](https://www.twilio.com/)|
Webhooks|[Svix](https://www.svix.com/)|Webhooks as a Service|<a href=https://github.com/svix/svix-webhooks></a>|[Pusher](https://pusher.com/)|
Website analytics|[GoatCounter](https://www.goatcounter.com/)|Google Analytics alternative|<a href=https://github.com/arp242/goatcounter></a>|[Google Analytics](https://analytics.google.com/)
Website analytics|[Matomo](https://matomo.org/)|Google Analytics alternative|<a href=https://github.com/matomo-org/matomo></a>|[Google Analytics](https://analytics.google.com/)
Website analytics|[Plausible](https://plausible.io/)|Google Analytics alternative|<a href=https://github.com/plausible/analytics></a>|[Google Analytics](https://analytics.google.com/)
Website analytics|[Swetrix](https://swetrix.com)|Google Analytics alternative|<a href=https://github.com/swetrix/swetrix-js></a>|[Google Analytics](https://analytics.google.com/)|
Website analytics|[Umami](https://umami.is)|Google Analytics alternative|<a href=https://github.com/mikecao/umami></a>|[Google Analytics](https://analytics.google.com/)
Workflow automation| [Activepieces](https://www.activepieces.com) | No-code business automation tool |<a href=https://github.com/activepieces/activepieces></a> |[Zapier](https://www.zapier.com/), [Tray](https://tray.io/)
Workflow automation|[N8N](https://n8n.io/)|Node-based workflow automation tool for developers|<a href=https://github.com/n8n-io/n8n></a>|[Zapier](https://zapier.com/)
Workflow automation|[Pipedream](https://pipedream.com/)|Workflow automation and API integration platform|<a href=https://github.com/PipedreamHQ/pipedream></a>|[Zapier](https://zapier.com/), [Integromat](https://www.integromat.com/)|
Workflow automation|[Temporal](https://temporal.io/)|Workflows as code platform|<a href=https://github.com/temporalio/temporal></a>|[Zapier](https://zapier.com/)

<!-- END STARTUP LIST -->

## Useful Links
- Great [article](https://rajko-rad.medium.com/the-rise-of-open-source-challengers-4a3d93932425) on open-source challengers by Rajko Radovanovic
