<p align="center">
  <a href="https://www.cypress.io">
    <picture>
      <source media="(prefers-color-scheme: dark)"  srcset="./assets/cypress-logo-dark.png">
      <source media="(prefers-color-scheme: light)" srcset="./assets/cypress-logo-light.png">
      
    </picture>
  </a>
</p>
<p align="center">
  <a href="https://on.cypress.io">Documentation</a> |
  <a href="https://on.cypress.io/changelog">Changelog</a> |
  <a href="https://on.cypress.io/roadmap">Roadmap</a>
</p>

<h3 align="center">
  The web has evolved. Finally, testing has too.
</h3>

<p align="center">
  Fast, easy and reliable testing for anything that runs in a browser.
</p>
<p align="center">
  Join us, we're <a href="https://cypress.io/jobs">hiring</a>.
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/cypress">
    
  </a>
  <a href="https://on.cypress.io/discord">
    
  </a>
    <a href="https://stackshare.io/cypress">
    
  </a><br />
</p>

## What is Cypress?

<p align="center">
  <a href="https://player.vimeo.com/video/237527670">
    
  </a>
</p>

## Installing

[](https://badge.fury.io/js/cypress)

Install Cypress for Mac, Linux, or Windows, then [get started](https://on.cypress.io/install).

```bash
npm install cypress --save-dev
```
or
```bash
yarn add cypress --dev
```
or
```bash
pnpm add cypress --save-dev
```




## Contributing

[](https://cloud.cypress.io/projects/ypt4pf/runs)
[](https://circleci.com/gh/cypress-io/cypress/tree/develop) -  `develop` branch

Please see our [Contributing Guideline](./CONTRIBUTING.md) which explains repo organization, linting, testing, and other steps.

## How we work

At Cypress we value our community and strive to be as open and transparent with them as possible.  Check out [our guide](./cypress-prioritization-and-triage.md) on how we prioritize community issues.

## License

[](https://github.com/cypress-io/cypress/blob/develop/LICENSE)

This project is licensed under the terms of the [MIT license](/LICENSE).

## Badges

Configure a badge for your project's README to show your test status or test count in the [Cypress Cloud](https://www.cypress.io/cloud).

[](https://cloud.cypress.io/projects/ypt4pf/runs)

[](https://cloud.cypress.io/projects/ypt4pf/runs)

Or let the world know your project is using Cypress with the badge below.

[](https://www.cypress.io/)

```
[](https://www.cypress.io/)
```
