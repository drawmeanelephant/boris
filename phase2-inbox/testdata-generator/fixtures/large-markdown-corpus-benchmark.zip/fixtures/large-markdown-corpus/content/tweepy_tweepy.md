Tweepy: Twitter for Python!
======

[](https://pypi.org/project/tweepy/)
[](https://pypi.org/project/tweepy/)
[](https://zenodo.org/badge/latestdoi/244025)

[](https://tweepy.readthedocs.io/en/latest/)
[](https://github.com/tweepy/tweepy/actions?query=workflow%3ATest)
[](https://coveralls.io/github/tweepy/tweepy?branch=master)

[](https://discord.gg/bJvqnhg)

Installation
------------

The easiest way to install the latest version from PyPI is by using
[pip](https://pip.pypa.io/):

    pip install tweepy

To use the `tweepy.asynchronous` subpackage, be sure to install with the
`async` extra:

    pip install tweepy[async]

You can also use Git to clone the repository from GitHub to install the latest
development version:

    git clone https://github.com/tweepy/tweepy.git
    cd tweepy
    pip install .

Alternatively, install directly from the GitHub repository:

    pip install git+https://github.com/tweepy/tweepy.git

Python 3.7 - 3.11 are supported.

Links
-----

- [Documentation](https://tweepy.readthedocs.io/en/latest/)
- [Official Discord Server](https://discord.gg/bJvqnhg)
- [Twitter API Documentation](https://developer.twitter.com/en/docs/twitter-api)

