# Mirage JS

[](https://badge.fury.io/js/miragejs)


A client-side server to develop, test and prototype your JavaScript app.

## Documentation

Visit [miragejs.com](https://miragejs.com) to read the docs.
