# &lt;css-doodle /&gt;





A web component for drawing patterns with CSS.

<a href="https://css-doodle.com/">
  
</a>

## Example

```css
<css-doodle>
  @grid: 5 / 200px;
  background: @p(#000, #fff);
  margin: 1px;
</css-doodle>
```

## Docs
[https://css-doodle.com](http://css-doodle.com)


## Design tools

* [Tabbied](https://tabbied.com) -- Doodle with generated patterns
* [Shapes](https://css-doodle.com/shapes) -- Discover new CSS polygon shapes
* [SVG playground](https://css-doodle.com/svg) -- Generate SVG code with new syntax


## Resources

* [How to Draw Patterns with CSS Using CSS Doodle](https://webdesign.tutsplus.com/tutorials/how-to-draw-patterns-with-css-using-css-doodle--cms-33110), by Adi Purdila
* [Arte generativo con CSS](https://www.youtube.com/watch?v=KKg6Uo1pVLU), by Sonia Ruiz


## Build

```bash
# build css-doodle.js
npm run build

# generate css-doodle.min.js
npm run minify

# or just use make
make
```

## Support

Thank you for your support! 🙏

<a href="https://opencollective.com/css-doodle#backers" target="_blank"></a>
<a href="https://opencollective.com/css-doodle#sponsors" target="_blank"></a>
