<p align="center">
  <a href="https://nestjs.com/" target="blank"></a>
</p>

[circleci-image]: https://img.shields.io/circleci/build/github/nestjs/nest/master?token=abc123def456
[circleci-url]: https://circleci.com/gh/nestjs/nest

  <p align="center">A progressive <a href="https://nodejs.org" target="_blank">Node.js</a> framework for building efficient and scalable server-side applications.</p>
    <p align="center">
<a href="https://www.npmjs.com/~nestjscore" target="_blank"></a>
<a href="https://www.npmjs.com/~nestjscore" target="_blank"></a>
<a href="https://www.npmjs.com/~nestjscore" target="_blank"></a>
<a href="https://circleci.com/gh/nestjs/nest" target="_blank"></a>
<a href="https://discord.gg/G7Qnnhy" target="_blank"></a>
<a href="https://opencollective.com/nest#backer" target="_blank"></a>
<a href="https://opencollective.com/nest#sponsor" target="_blank"></a>
  <a href="https://paypal.me/kamilmysliwiec" target="_blank"></a>
    <a href="https://opencollective.com/nest#sponsor"  target="_blank"></a>
  <a href="https://twitter.com/nestframework" target="_blank"></a>
</p>
  <!--[](https://opencollective.com/nest#backer)
  [](https://opencollective.com/nest#sponsor)-->

## Description

Nest is a framework for building efficient, scalable <a href="https://nodejs.org" target="_blank">Node.js</a> server-side applications. It uses modern JavaScript, is built with <a href="https://www.typescriptlang.org" target="_blank">TypeScript</a> (preserves compatibility with pure JavaScript) and combines elements of OOP (Object Oriented Programming), FP (Functional Programming), and FRP (Functional Reactive Programming).

<p>Under the hood, Nest makes use of <a href="https://expressjs.com/" target="_blank">Express</a>, but also, provides compatibility with a wide range of other libraries, like e.g. <a href="https://github.com/fastify/fastify" target="_blank">Fastify</a>, allowing for easy use of the myriad third-party plugins which are available.</p>

## Philosophy

<p>In recent years, thanks to Node.js, JavaScript has become the “lingua franca” of the web for both front and backend applications, giving rise to awesome projects like <a href="https://angular.io/" target="_blank">Angular</a>, <a href="https://github.com/facebook/react" target="_blank">React</a> and <a href="https://github.com/vuejs/vue" target="_blank">Vue</a> which improve developer productivity and enable the construction of fast, testable, extensible frontend applications. However, on the server-side, while there are a lot of superb libraries, helpers and tools for Node, none of them effectively solve the main problem - the architecture.</p>
<p>Nest aims to provide an application architecture out of the box which allows for effortless creation of highly testable, scalable, loosely coupled and easily maintainable applications. The architecture is heavily inspired by Angular.</p>

## Getting started

- To check out the [guide](https://docs.nestjs.com), visit [docs.nestjs.com](https://docs.nestjs.com). :books:
- 要查看中文 [指南](readme_zh.md), 请访问 [docs.nestjs.cn](https://docs.nestjs.cn). :books:
- [가이드](readme_kr.md) 문서는 [docs.nestjs.com](https://docs.nestjs.com)에서 확인하실 수 있습니다. :books:
- [ガイド](readme_jp.md)は [docs.nestjs.com](https://docs.nestjs.com)でご確認ください。 :books:

## Questions

For questions and support please use the official [Discord channel](https://discord.gg/G7Qnnhy). The issue list of this repo is **exclusively** for bug reports and feature requests.

## Issues

Please make sure to read the [Issue Reporting Checklist](https://github.com/nestjs/nest/blob/master/CONTRIBUTING.md#-submitting-an-issue) before opening an issue. Issues not conforming to the guidelines may be closed immediately.

## Consulting

With official support, you can get expert help straight from Nest core team. We provide dedicated technical support, migration strategies, advice on best practices (and design decisions), PR reviews, and team augmentation. Read more about [support here](https://enterprise.nestjs.com).

## Support

Nest is an MIT-licensed open source project. It can grow thanks to the sponsors and support from the amazing backers. If you'd like to join them, please [read more here](https://docs.nestjs.com/support).

#### Principal Sponsors

<table style="text-align:center;"><tr>
  <td><a href="https://trilon.io" target="_blank"></a></td>
    <td>
<a href="https://valor-software.com/" target="_blank"></a></td>
<td>
<a href="https://amplication.com/" target="_blank"></a></td>
</tr></table>

#### Gold Sponsors

<table style="text-align:center;"><tr>
  <td><a href="https://www.redhat.com" target="_blank"></a></td>
<td>
<a href="https://github.com/Sanofi-IADC" target="_blank"></a></td>
<td>
<a href="https://nx.dev" target="_blank"></a></td>
  <td>
<a href="https://weld.app/" target="_blank"></a></td>
<td>
<a href="https://intrinsic.ventures/" target="_blank"></a></td></tr><tr>
 <td>
<a href="https://jetbrains.com/" target="_blank"></a></td><td>
<a href="https://snyk.co/nestjs" target="_blank"></a></td><td>
<a href="https://fuseautotech.com/" target="_blank"></a></td>
<td>
<a href="https://ridicorp.com/career/" target="_blank"></a></td><td>
<a href="https://www.movavi.com/imovie-for-windows.html" target="_blank"></a></td>
</tr><tr><td>
<a href="https://skunk.team" target="_blank"></a></td>
 </tr></table>

#### Silver Sponsors

<table style="text-align:center;"><tr>
<td><a href="https://n.inc" target="_blank"></td>
<td><a href="https://twistag.com/" target="_blank"></td>
<td><a href="https://immediateedgeapp.org/" target="_blank"></td>
</tr>
</table>

#### Sponsors

<table><tr><td align="center" valign="middle">
<a href="https://www.swingdev.io" target="_blank"> </a></td><td align="center" valign="middle">
<a href="https://www.novologic.com/" target="_blank"></a> </td><td align="center" valign="middle">
  <a href="https://mantro.net/" target="_blank"></a> </td><td align="center" valign="middle">
  <a href="https://triplebyte.com/" target="_blank"></a> </td><td align="center" valign="middle">
<a href="https://nearpod.com/" target="_blank"></a> </td>
  <td align="center" valign="middle">
  <a href="https://genuinebee.com/" target="_blank"></a> </td></tr><tr>
<td align="center" valign="middle"><a href="https://sanyodigital.com/" target="_blank"></a></td><td align="center" valign="middle"><a href="https://vpn-review.com/vpn-for-torrenting" target="_blank"></a></td><td align="center" valign="middle"><a href="https://lambda-it.ch/" target="_blank"></a></td>
  <td align="center" valign="middle"><a href="https://www.najlepszeplatformyforex.pl/blog/broker-xtb/" target="_blank"></a></td>
<td align="center" valign="middle"><a href="https://rocketech.it/cases/?utm_source=google&utm_medium=badge&utm_campaign=nestjs" target="_blank"></a></td>
  <td align="center" valign="middle"><a href="https://www.anonymistic.com/" target="_blank"></a></td></tr><tr>
<td align="center" valign="middle"><a href="https://www.naologic.com/" target="_blank"></a></td>
  <td align="center" valign="middle"><a href="https://triplecore.io" target="_blank"></a></td>
   <td align="center" valign="middle"><a href="https://thecasinowizard.com/bonuses/no-deposit-bonuses/" target="_blank"></a></td>
     <td align="center" valign="middle"><a href="https://polygon-software.ch/" target="_blank"></a></td>
     <td align="center" valign="middle"><a href="https://boringowl.io/" target="_blank"></a></td>
 <td align="center" valign="middle"><a href="https://nordbot.app/" target="_blank"></a></td></tr><tr>
 <td align="center" valign="middle"><a href="https://doppio.sh/" target="_blank"></a></td>
   <td align="center" valign="middle"><a href="https://www.hingehealth.com/" target="_blank"></a></td>
   <td align="center" valign="middle"><a href="https://julienferand.dev/" target="_blank"></a></td>
   <td align="center" valign="middle"><a href="https://www.tripoffice.com/" target="_blank"></a></td>
   <td align="center" valign="middle"><a href="https://solcellsforetag.se/" target="_blank"></a></td>
  </tr></table>

## Backers

<a href="https://opencollective.com/nest" target="_blank"></a>

## Stay in touch

- Author - [Kamil Myśliwiec](https://x.com/kammysliwiec)
- Website - [https://nestjs.com](https://nestjs.com/)
- X - [@nestframework](https://x.com/nestframework)

## License

Nest is [MIT licensed](LICENSE).
