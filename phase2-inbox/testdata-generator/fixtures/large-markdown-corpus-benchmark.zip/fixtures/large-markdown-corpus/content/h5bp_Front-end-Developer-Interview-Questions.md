# Front-end Developer Interview Questions

This repository contains a number of front-end interview questions that can be used when vetting potential candidates. It is by no means recommended to use every single question here on the same candidate (that would take hours). Choosing a few items from this list should help you vet the intended skills you require.

**Note:** Keep in mind that many of these questions are open-ended and could lead to interesting discussions that tell you more about the person's capabilities than a straight answer would.

You can read more about this project & its history [here](https://h5bp.org/Front-end-Developer-Interview-Questions/about/).

## Table of Contents

  1. [General Questions](src/questions/general-questions.md)
  2. [HTML Questions](src/questions/html-questions.md)
  3. [CSS Questions](src/questions/css-questions.md)
  4. [JS Questions](src/questions/javascript-questions.md)
  5. [Accessibility Questions](https://scottaohara.github.io/accessibility_interview_questions/) (external link)
  6. [Testing Questions](src/questions/testing-questions.md)
  7. [Performance Questions](src/questions/performance-questions.md)
  8. [Network Questions](src/questions/network-questions.md)
  9. [Coding Questions](src/questions/coding-questions.md)
  10. [Fun Questions](src/questions/fun-questions.md)

## Getting Involved

  1. [Contributors](#contributors)
  2. [How to Contribute](https://github.com/h5bp/Front-end-Developer-Interview-Questions/blob/master/.github/CONTRIBUTING.md)
  3. [License](https://github.com/h5bp/Front-end-Developer-Interview-Questions/blob/master/LICENSE.md)


The project is currently maintained by:

- [@roblarsen](https://github.com/roblarsen)

## Contributors

Feeling inspired? Check our [Contributing guide](https://github.com/h5bp/Front-end-Developer-Interview-Questions/blob/master/.github/CONTRIBUTING.md) to get started!

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tbody>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://darcyclarke.me/"><br /><sub><b>Darcy Clarke</b></sub></a><br /><a href="#ideas-darcyclarke" title="Ideas, Planning, & Feedback">🤔</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=darcyclarke" title="Documentation">📖</a> <a href="#infra-darcyclarke" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Adarcyclarke" title="Reviewed Pull Requests">👀</a> <a href="#question-darcyclarke" title="Answering Questions">💬</a> <a href="#talk-darcyclarke" title="Talks">📢</a> <a href="#maintenance-darcyclarke" title="Maintenance">🚧</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://about.me/appleboy"><br /><sub><b>Bo-Yi Wu</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=appleboy" title="Documentation">📖</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Aappleboy" title="Reviewed Pull Requests">👀</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://nikolay.it"><br /><sub><b>Nikolay Kostov</b></sub></a><br /><a href="#translation-NikolayIT" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://hancic.info"><br /><sub><b>Jan Hancic</b></sub></a><br /><a href="#translation-janhancic" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://twitter.com/richgilbank"><br /><sub><b>Rich Gilbank</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=richgilbank" title="Documentation">📖</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Arichgilbank" title="Reviewed Pull Requests">👀</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/mattiasw"><br /><sub><b>Mattias Wallander</b></sub></a><br /><a href="#translation-mattiasw" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://gplus.to/songhun"><br /><sub><b>Songhun</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=Songhun" title="Documentation">📖</a> <a href="#translation-Songhun" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://giugee.com/portfolio"><br /><sub><b>Giulia Alfonsi</b></sub></a><br /><a href="#translation-electricg" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://mmhan.net"><br /><sub><b>Mike Myat Min Han</b></sub></a><br /><a href="#translation-mmhan" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.zhihu.com/people/deng-chen-hua"><br /><sub><b>SunLn</b></sub></a><br /><a href="#translation-SunLn" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://javarouka.github.com"><br /><sub><b>Yi, Hangehee</b></sub></a><br /><a href="#translation-javarouka" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/shawnqiang"><br /><sub><b>shawnqiang</b></sub></a><br /><a href="#translation-shawnqiang" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://guilhermepontes.com"><br /><sub><b>Guilherme Pontes</b></sub></a><br /><a href="#translation-guilhermepontes" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/lufeihaidao"><br /><sub><b>lufeihaidao</b></sub></a><br /><a href="#translation-lufeihaidao" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://about.me/DonaldZhan"><br /><sub><b>Donald Zhan</b></sub></a><br /><a href="#translation-dz1984" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://mina.codes"><br /><sub><b>Mina Markham</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=minamarkham" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://paulirish.com"><br /><sub><b>Paul Irish</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=paulirish" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://mathieuhays.co.uk"><br /><sub><b>Mathieu Hays</b></sub></a><br /><a href="#translation-mathieuhays" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://yanni4night.github.io"><br /><sub><b>Yong Yin</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=yanni4night" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://dalesande.com"><br /><sub><b>Dale Sande / @anotheruiguy</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=blackfalcon" title="Documentation">📖</a> <a href="#infra-blackfalcon" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Ablackfalcon" title="Reviewed Pull Requests">👀</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://www.marcobiedermann.com"><br /><sub><b>Marco Biedermann</b></sub></a><br /><a href="#infra-marcobiedermann" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://victorcoulon.com"><br /><sub><b>Victor Coulon</b></sub></a><br /><a href="#translation-Victa" title="Translation">🌍</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3AVicta" title="Reviewed Pull Requests">👀</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/demoive"><br /><sub><b>Paulo Ávila</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=demoive" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/ekremkaraca"><br /><sub><b>Ekrem Karaca</b></sub></a><br /><a href="#translation-ekremkaraca" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://achalv.com"><br /><sub><b>Achal Varma</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=achalv" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://www.audero.it"><br /><sub><b>Aurelio De Rosa</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=AurelioDeRosa" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/d-i-b"><br /><sub><b>Min Zhao</b></sub></a><br /><a href="#translation-d-i-b" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://twitter.com/alrra"><br /><sub><b>Cătălin Mariș</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=alrra" title="Documentation">📖</a> <a href="#translation-alrra" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://s10wen.com"><br /><sub><b>Simon Owen</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=s10wen" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/MaximKhlobystov"><br /><sub><b>Maxim Khlobystov</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=MaximKhlobystov" title="Documentation">📖</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3AMaximKhlobystov" title="Reviewed Pull Requests">👀</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/dermatobia"><br /><sub><b>Sara</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=dermatobia" title="Documentation">📖</a> <a href="#translation-dermatobia" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/jhummel"><br /><sub><b>Jason Hummel</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=jhummel" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/kunsachdeva"><br /><sub><b>Kunal Sachdeva</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=kunsachdeva" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://strugee.net"><br /><sub><b>AJ Jordan</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=strugee" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/paulalexandru"><br /><sub><b>paulalexandru</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=paulalexandru" title="Documentation">📖</a> <a href="#translation-paulalexandru" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/rozehan"><br /><sub><b>dot</b></sub></a><br /><a href="#infra-rozehan" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="#translation-rozehan" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://twitter.com/billowblut"><br /><sub><b>Everardo Medina</b></sub></a><br /><a href="#translation-everblut" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/gauravmuk"><br /><sub><b>Gaurav Nanda</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=gauravmuk" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/malaman"><br /><sub><b>Andrii Malaman</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=malaman" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.betterpixels.co.uk"><br /><sub><b>Daniele Zanni</b></sub></a><br /><a href="#translation-syymza" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://fernandofreitasalves.com"><br /><sub><b>Fernando Freitas Alves</b></sub></a><br /><a href="#translation-ffreitasalves" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/tjwudi"><br /><sub><b>John Wu</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=tjwudi" title="Documentation">📖</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/pnevares"><br /><sub><b>Pablo Nevares</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=pnevares" title="Documentation">📖</a> <a href="#translation-pnevares" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/f3liperamos"><br /><sub><b>Felipe Ramos</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=f3liperamos" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://twitter.com/arthur_versch"><br /><sub><b>Arthur Verschaeve</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=arthurvr" title="Documentation">📖</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Aarthurvr" title="Reviewed Pull Requests">👀</a> <a href="#translation-arthurvr" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/isdampe"><br /><sub><b>Richard Denton</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=isdampe" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/kubum"><br /><sub><b>Andrey Fadeyev</b></sub></a><br /><a href="#translation-kubum" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/rimager"><br /><sub><b>rimager</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=rimager" title="Documentation">📖</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/rjain11"><br /><sub><b>Rishabh Jain</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=rjain11" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/Kaijun"><br /><sub><b>Kaijun Chen</b></sub></a><br /><a href="#translation-Kaijun" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/NkS90"><br /><sub><b>Nithya</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=NkS90" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.erwanjegouzo.com"><br /><sub><b>Erwan Jegouzo</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=erwanjegouzo" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://www.linkedin.com/in/tiemevanveen"><br /><sub><b>Tieme van Veen</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=teameh" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/linkgod"><br /><sub><b>Hsun</b></sub></a><br /><a href="#translation-linkgod" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/adrienchretien"><br /><sub><b>Adrien CHRETIEN</b></sub></a><br /><a href="#translation-adrienchretien" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/shnere"><br /><sub><b>Alan Rodríguez</b></sub></a><br /><a href="#translation-shnere" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://harisadam.com"><br /><sub><b>Adam Haris</b></sub></a><br /><a href="#translation-harisadam" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://toshimaru.net/"><br /><sub><b>Toshimaru</b></sub></a><br /><a href="#translation-toshimaru" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://shankarcabus.com.br"><br /><sub><b>Shankar Cabus</b></sub></a><br /><a href="#translation-shankarcabus" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/lukasz-jakub-adamczuk"><br /><sub><b>Ash</b></sub></a><br /><a href="#translation-lukasz-jakub-adamczuk" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/hanksudo"><br /><sub><b>Hank Wang</b></sub></a><br /><a href="#translation-hanksudo" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://graybobo.github.io/"><br /><sub><b>KILLHAPPY.</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=Graybobo" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://msvaljek.blogspot.com"><br /><sub><b>Marko Švaljek</b></sub></a><br /><a href="#translation-msval" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://www.funcion13.com"><br /><sub><b>Antonio Laguna</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=Antonio-Laguna" title="Documentation">📖</a> <a href="#translation-Antonio-Laguna" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.mi2oon.com"><br /><sub><b>Mithun Dhiman</b></sub></a><br /><a href="#translation-mi2oon" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://darklg.me"><br /><sub><b>Kévin Rocher / @Darklg</b></sub></a><br /><a href="#translation-Darklg" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://dpashk.com"><br /><sub><b>Dmitry Pashkevich</b></sub></a><br /><a href="#translation-dpashkevich" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/karmeljuk"><br /><sub><b>karmeljuk</b></sub></a><br /><a href="#translation-karmeljuk" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://decaf.de"><br /><sub><b>Dirk Schürjohann</b></sub></a><br /><a href="#translation-schuer" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/cybear"><br /><sub><b>Björn Söderqvist</b></sub></a><br /><a href="#translation-cybear" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.nitinh.com"><br /><sub><b>Nitin Hayaran</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=nitinhayaran" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://poetro.hu/"><br /><sub><b>Peter Galiba</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=Poetro" title="Documentation">📖</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://neilheinrich.com"><br /><sub><b>Neil Heinrich</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=nheinrich" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://ohgyun.com"><br /><sub><b>Ohgyun Ahn</b></sub></a><br /><a href="#translation-ohgyun" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/nerdog"><br /><sub><b>nerdog</b></sub></a><br /><a href="#translation-nerdog" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://leo.cr"><br /><sub><b>Leo Picado</b></sub></a><br /><a href="#translation-leopic" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://refine.hull.io"><br /><sub><b>Romain Dardour</b></sub></a><br /><a href="#translation-unity" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://blog.alexanderseville.com/"><br /><sub><b>Alex Seville</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=alex-seville" title="Documentation">📖</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://hooray.cnblogs.com"><br /><sub><b>胡尐睿丶</b></sub></a><br /><a href="#translation-hooray" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://petrychuk.com"><br /><sub><b>Vitalii Petrychuk</b></sub></a><br /><a href="#translation-vermilion1" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://tairraos.github.io"><br /><sub><b>Tairraos</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=Tairraos" title="Documentation">📖</a> <a href="#translation-Tairraos" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/draev"><br /><sub><b>Dmitrii Raev</b></sub></a><br /><a href="#translation-draev" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/bpu"><br /><sub><b>Bartek</b></sub></a><br /><a href="#translation-bpu" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://twitter.com/vitorbal"><br /><sub><b>Vitor Balocco</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=vitorbal" title="Documentation">📖</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://jonathantneal.com"><br /><sub><b>Jonathan Neal</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=jonathantneal" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/Muqito"><br /><sub><b>Christoffer Lans</b></sub></a><br /><a href="#translation-Muqito" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.felipefialho.com/"><br /><sub><b>Felipe Fialho</b></sub></a><br /><a href="#translation-LFeh" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://piotrek.co"><br /><sub><b>Piotrek Mierzejewski</b></sub></a><br /><a href="#translation-pim" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://patrikwibron.se/"><br /><sub><b>Patrik Wibron</b></sub></a><br /><a href="#translation-wibron" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://vdv73.ru"><br /><sub><b>Dmitry Vislov</b></sub></a><br /><a href="#translation-vdv73rus" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://krzysztofromanowski.pl"><br /><sub><b>Krzysztof Romanowski</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=castus" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://www.very-geek.com"><br /><sub><b>Albert Yu</b></sub></a><br /><a href="#translation-nightire" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://twitter.com/slaramen"><br /><sub><b>Sebastian Lara Menares</b></sub></a><br /><a href="#translation-slara" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://sunnylost.com/"><br /><sub><b>sunnylost</b></sub></a><br /><a href="#translation-sunnylost" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/miniflycn"><br /><sub><b>Daniel Yang</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=miniflycn" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://contains.me/"><br /><sub><b>Michael P. Pfeiffer</b></sub></a><br /><a href="#translation-frontdevde" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://craft-interactive.de/"><br /><sub><b>Tyll Weiß</b></sub></a><br /><a href="#translation-Inkdpixels" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://andreime.com"><br /><sub><b>Andrei Sebastian Cîmpean</b></sub></a><br /><a href="#translation-andreisebastianc" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://sokolov.cc/"><br /><sub><b>Denis Sokolov</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=denis-sokolov" title="Documentation">📖</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/arcanous"><br /><sub><b>Harijs Deksnis</b></sub></a><br /><a href="#translation-arcanous" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="http://htmlcssjavascript.com/"><br /><sub><b>Rob Larsen</b></sub></a><br /><a href="#ideas-roblarsen" title="Ideas, Planning, & Feedback">🤔</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=roblarsen" title="Documentation">📖</a> <a href="#infra-roblarsen" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Aroblarsen" title="Reviewed Pull Requests">👀</a> <a href="#question-roblarsen" title="Answering Questions">💬</a> <a href="#talk-roblarsen" title="Talks">📢</a> <a href="#maintenance-roblarsen" title="Maintenance">🚧</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://cezaraugusto.net/"><br /><sub><b>Cezar Augusto</b></sub></a><br /><a href="#ideas-cezaraugusto" title="Ideas, Planning, & Feedback">🤔</a> <a href="#infra-cezaraugusto" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Acezaraugusto" title="Reviewed Pull Requests">👀</a> <a href="#maintenance-cezaraugusto" title="Maintenance">🚧</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://www.linkedin.com/in/vvanchuk/"><br /><sub><b>Vasiliy Vanchuk</b></sub></a><br /><a href="#ideas-vvscode" title="Ideas, Planning, & Feedback">🤔</a> <a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/pulls?q=is%3Apr+reviewed-by%3Avvscode" title="Reviewed Pull Requests">👀</a> <a href="#maintenance-vvscode" title="Maintenance">🚧</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/veronvynguyen"><br /><sub><b>Vy Nguyen</b></sub></a><br /><a href="#content-veronvynguyen" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://pchaparro.netlify.app/"><br /><sub><b>Pedro Chaparro</b></sub></a><br /><a href="#translation-PChaparro" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/WildxHV"><br /><sub><b>Harshvardhan Singh Sisodia</b></sub></a><br /><a href="#translation-WildxHV" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/gabrielrbarbosa"><br /><sub><b>Gabriel R. Barbosa</b></sub></a><br /><a href="#translation-gabrielrbarbosa" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/talhatahir"><br /><sub><b>Talha Tahir</b></sub></a><br /><a href="#content-talhatahir" title="Content">🖋</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="http://www.subashcs.com.np/"><br /><sub><b>Subash Chandra Sapkota</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=subashcs" title="Code">💻</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/sarahesbie"><br /><sub><b>Sarah Brown</b></sub></a><br /><a href="#content-sarahesbie" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://christianoliff.com/"><br /><sub><b>Christian Oliff</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=coliff" title="Code">💻</a> <a href="#infra-coliff" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="#maintenance-coliff" title="Maintenance">🚧</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/andershagbard"><br /><sub><b>Anders Søgaard</b></sub></a><br /><a href="#content-andershagbard" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://segredo.dev/"><br /><sub><b>Italo A.</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=iaurg" title="Code">💻</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/cpvalente"><br /><sub><b>Carlos Valente</b></sub></a><br /><a href="#translation-cpvalente" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://baumannzone.dev/"><br /><sub><b>Jorge Baumann</b></sub></a><br /><a href="#translation-baumannzone" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://satyamsundaram.tech/"><br /><sub><b>Satyam Sundaram</b></sub></a><br /><a href="#content-satyamsundaram" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/NegiAkash890"><br /><sub><b>Akash Negi</b></sub></a><br /><a href="#content-NegiAkash890" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://www.tn76.com/"><br /><sub><b>Ilyes Tounsi</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=tounsils" title="Code">💻</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://swati-gwc.github.io/"><br /><sub><b>Swati Tripathi</b></sub></a><br /><a href="#translation-swati-gwc" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/dafaputra00"><br /><sub><b>Aziz Dafa Putra</b></sub></a><br /><a href="#translation-dafaputra00" title="Translation">🌍</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/Abg4real"><br /><sub><b>Abg4real</b></sub></a><br /><a href="#content-Abg4real" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/nataliepina"><br /><sub><b>Natalie Pina</b></sub></a><br /><a href="#content-nataliepina" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/bt-dot"><br /><sub><b>Bruce Tang</b></sub></a><br /><a href="#content-bt-dot" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/vltansky"><br /><sub><b>Vlad Tansky</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=vltansky" title="Code">💻</a> <a href="#design-vltansky" title="Design">🎨</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/voy"><br /><sub><b>Vojtech Jasny</b></sub></a><br /><a href="#content-voy" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://codewithlinda.com/"><br /><sub><b>Linda Ikechukwu</b></sub></a><br /><a href="#content-Linda-Ikechukwu" title="Content">🖋</a></td>
    </tr>
    <tr>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/iownthegame"><br /><sub><b>Hui-Yu Lee</b></sub></a><br /><a href="#translation-iownthegame" title="Translation">🌍</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/aej11a"><br /><sub><b>Andrew Jones</b></sub></a><br /><a href="#content-aej11a" title="Content">🖋</a></td>
      <td align="center" valign="top" width="16.66%"><a href="https://github.com/Teesy99"><br /><sub><b>Teesta Koch</b></sub></a><br /><a href="https://github.com/h5bp/Front-end-Developer-Interview-Questions/commits?author=Teesy99" title="Documentation">📖</a></td>
    </tr>
  </tbody>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

## License

[Copyright (c) Contributors of the Front-end Developer Interview Questions](https://github.com/h5bp/Front-end-Developer-Interview-Questions/blob/master/LICENSE.md)
