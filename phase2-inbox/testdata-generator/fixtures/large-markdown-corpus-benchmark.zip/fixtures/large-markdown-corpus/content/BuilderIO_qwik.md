<br>
<p align="center">
  
</p>
<br>
<p align="center">
   <a href="https://github.com/BuilderIO/qwik/actions/workflows/ci.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/azure.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/cloudflare.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/netlify.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/node.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/vercel.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/cli.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/deno.yml"></a>
   <a href="https://github.com/BuilderIO/qwik-city-e2e/actions/workflows/aws.yml"></a>
</p>
<br>
<br>

<h1 align="center">Instant-loading web apps, without effort</h1>

Qwik offers the fastest possible page load times - regardless of the complexity of your website. Qwik is so fast because it allows fully interactive sites to load with almost no JavaScript and [pickup from where the server left off](https://qwik.builder.io/docs/concepts/resumable/).

As users interact with the site, only the necessary parts of the site load on-demand. This [precision lazy-loading](https://qwik.builder.io/docs/concepts/progressive/) is what makes Qwik so quick.

## Getting Started

```sh
npm create qwik@latest
# or
pnpm create qwik@latest
# or
yarn create qwik@latest
# or
bun create qwik@latest
```

- Understand the difference between [resumable and replayable](https://qwik.builder.io/docs/concepts/resumable/) applications.
- Learn about Qwik's high level [mental model](https://qwik.builder.io/docs/concepts/think-qwik/).

## Resources

- [Docs](https://qwik.builder.io/)
- [Examples](https://qwik.builder.io/examples/introduction/hello-world/)
- [Tutorials](https://qwik.builder.io/tutorial/welcome/overview/)
- [Videos](https://qwik.builder.io/media/#videos)
- [Podcasts](https://qwik.builder.io/media/#podcasts)
- [Presentations](https://qwik.builder.io/media/#presentations)
- [Blogs](https://qwik.builder.io/media/#blogs)

## Community

- Ping us at [@QwikDev](https://twitter.com/QwikDev)
- Join our [Discord](https://qwik.builder.io/chat) community
- Join all the [other community groups](https://qwikcommunity.com)

## Development

- See [Contributing.md](https://github.com/BuilderIO/qwik/blob/main/CONTRIBUTING.md) for more information on how to build Qwik from the source and contribute!

## Related

- [Partytown](https://partytown.builder.io/): Relocate resource intensive third-party scripts off of the main thread and into a web worker 🎉.
- [Mitosis](https://github.com/BuilderIO/mitosis): Write components once, run everywhere. Compiles to Vue, React, Solid, Angular, Svelte, and more.
- [Builder](https://github.com/BuilderIO/builder): Drag and drop page builder and CMS for React, Vue, Angular, and more.

<br>
<br>

<p align="center">
   <a href="https://www.builder.io/m/developers">
      <picture>
         <source media="(prefers-color-scheme: dark)" srcset="https://user-images.githubusercontent.com/844291/230786554-eb225eeb-2f6b-4286-b8c2-535b1131744a.png">
         
       </picture>
   </a>
</p>
