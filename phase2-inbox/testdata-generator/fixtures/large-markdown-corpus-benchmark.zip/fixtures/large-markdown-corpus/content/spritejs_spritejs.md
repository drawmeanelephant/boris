<p align="center">
  <a href="http://spritejs.com"></a>
</p>

<a href="http://spritejs.com"><h1 align="center">spritejs.com</h1></a>

[](https://www.npmjs.org/package/spritejs)
[](https://travis-ci.org/spritejs/spritejs)
[](http://packagequality.com/#?package=spritejs)
[](https://codeclimate.com/github/spritejs/spritejs/maintainability)
[](LICENSE)

Spritejs is a cross platform high-performance graphics system, which can render graphics on web, node, desktop applications and mini-programs.

Spritejs<sup>Next</sup> is the new version of spritejs. It is renderer agnostic enabling the same api to render in multiple contexts: webgl2, webgl, and canvas2d.

Manipulate the **sprites** in canvas as you do with the DOM elements.

## Features

- Manipulate the sprites element as you do with the DOM elements.
- Rendering by **WebGL2** context.
- Multiple layers.
- DOM Events.
- Object Oriented Programmed Development with ES6+.
- OffscreenCanvas and [Web Worker](https://spritejs.com/#/en/guide/worker).
- Work with [d3](https://github.com/d3/d3).
- [Server-side rendering](https://spritejs.com/#/en/guide/platforms).
- [Vue](http://vue.spritejs.com).

## Quick Start

**SpriteJS** - spritejs.com

```html
<script src="https://unpkg.com/spritejs@3/dist/spritejs.min.js"></script>
<div id="container" style="width:400px;height:400px"></div>
<script>
    const imgUrl = 'https://s5.ssl.qhres2.com/static/ec9f373a383d7664.svg'
    const {Scene, Sprite} = spritejs;
    const container = document.getElementById('container');
    const paper = new Scene({
      container,
      width: 400,
      height: 400,
    })

    const sprite = new Sprite(imgUrl)
    sprite.attr({
      bgcolor: '#fff',
      pos: [0, 0],
      size: [400, 400],
      borderRadius: '200'
    })

    paper.layer().appendChild(sprite)
</script>
```

<div style="font-size: 1.5rem">Learn more at <strong style="font-size: 2.5rem"><a href="http://spritejs.com/"><font size="36">spritejs.com</font></a></strong> </div>

## Usage

In browser:

```html
<script src="https://unpkg.com/spritejs@3/dist/spritejs.min.js"></script>
```

With Node.js:

```bash
npm install spritejs --save
```

```js
import * as spritejs from 'spritejs';
```

## 3D

SpriteJS<sup>Next</sup> can render 3D elements through [3D extension library](https://github.com/spritejs/sprite-extend-3d).

```html
<script src="https://unpkg.com/spritejs@3/dist/spritejs.es.min.js"></script>
<script src="https://unpkg.com/sprite-extend-3d/dist/sprite-extend-3d.js"></script>
```

Or from NPM


```js
import {Scene} from 'spritejs';
import {Cube, shaders} from 'sprite-extend-3d';
```

## Examples

### Basic

- [Overview](http://spritejs.com/demo/)
- [Sprites](http://spritejs.com/demo/#basic_sprites)
- [Path & Group](http://spritejs.com/demo/#path_groups)
- [Labels](http://spritejs.com/demo/#labels)
- [Button](http://spritejs.com/demo/#button)
- [Transforms](http://spritejs.com/demo/#transforms)
- [Events](http://spritejs.com/demo/#events)
- [Filters](http://spritejs.com/demo/#filters)
- [Animations](http://spritejs.com/demo/#animations)
- [SVG Paths](http://spritejs.com/demo/#svg_path)
- [Offset API](http://spritejs.com/demo/#offset_api)

### With D3

Compatible with [d3.js](https://github.com/d3/d3).

- [Bar Graph](http://spritejs.com/demo/#/d3/bar)
- [Hierarchy](http://spritejs.com/demo/#/d3/hierarchy)
- [Map](http://spritejs.com/demo/#/d3/map)
- [Force Links](http://spritejs.com/demo/#/d3/links)

### 3D Extension

- [3D Cube](http://spritejs.com/demo/#/3d/basic)
- [Camera](http://spritejs.com/demo/#/3d/camera2)
- [Cube Map](http://spritejs.com/demo/#/3d/cubemap)
- [Physically Based Rendering](http://spritejs.com/demo/#/3d/pbr)
- [Geometry](http://spritejs.com/demo/#/3d/geometry)
- [Geometry Model](http://spritejs.com/demo/#/3d/geometry3)
- [Model & Texture](http://spritejs.com/demo/#/3d/model_texture)
- [Groups](http://spritejs.com/demo/#/3d/group3)
- [Skydom](http://spritejs.com/demo/#/3d/skydom)
- [Video](http://spritejs.com/demo/#/3d/video)
- [Shadow](http://spritejs.com/demo/#/3d/shadow)
- [Post channel](http://spritejs.com/demo/#/3d/post)
- [GPGPU](http://spritejs.com/demo/#/3d/gpgpu)

### [Q-Charts](https://github.com/spritejs/q-charts)

A visulization library based on spritejs.

- [QCharts basic](https://www.qcharts.cn/#/demo/line/default)
- [Lines](https://www.qcharts.cn/#/demo/line/multi)
- [Smooth Lines](https://www.qcharts.cn/#/demo/line/smooth)
- [Lines & Bars](https://www.qcharts.cn/#/more/line-mixLineAndBar)
- [Area Chart](https://www.qcharts.cn/#/demo/area/stack)
- [Pie Chart](https://www.qcharts.cn/#/demo/pie/default)
- [Rose Chart](https://www.qcharts.cn/#/demo/polarBar/group)
- [Radar Chart](https://www.qcharts.cn/#/demo/radar/default)
- [Bubble Chart](https://www.qcharts.cn/#/demo/scatter/bubble)

<!-- ### With Proton

[Proton](https://github.com/a-jie/Proton) is a lightweight and powerful javascript particle engine. 

- [Big Fire](http://spritejs.com/demo/#/proton/fire)
- [Background Particles](http://spritejs.com/demo/#/proton/position)
- [Custom Behavior](http://spritejs.com/demo/#/proton/behavior)

### With Matter-js

[Matter.js]((https://github.com/liabru/matter-js)) is a JavaScript 2D rigid body physics engine.

- [Mixed shapes](http://spritejs.com/demo/#/matterjs/mixed_shapes)

-->

### Ecosystem & Extensions

| **Project**                         | **Description**                           |
| ------------------------------- | ----------------------------------- |
| [sprite-vue](https://github.com/spritejs/sprite-vue)| SpriteJS for Vue.js. |
| [sprite-react](https://github.com/spritejs/sprite-react)| Rendering spritejs elements with React. |
| [q-charts](https://github.com/spritejs/q-charts) | A visulization library based on spritejs |
| [cat-charts-vue](https://github.com/spritejs/cat-charts-vue)| A visulization library based on spritejs , qcharts and Vue. |

## Architecture

Spritejs<sup>Next</sup> provides several kinds of basic sprite elements, which can be operated on the layer like DOM elements.



### Build

Build with NPM

```bash
npm run build
```

Build Doc

```bash
npm run build-doc
```

### Tests

```bash
npm test
```

# V2

[SpriteJS v2.0](https://github.com/spritejs/spritejs/tree/v2)

# Compatibility

Compatible for most modern browsers.

You should import [babel-polyfill](https://cdn.baomitu.com/babel-polyfill) for early browers(i.e. iOS 8).

## Contributors

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore -->

| | | | | | | |
| :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| [<br /><sub><b>betseyliu</b></sub>](https://github.com/betseyliu)<br />[💻](https://github.com/spritejs/spritejs/commits?author=betseyliu "Code") [📖](https://github.com/spritejs/spritejs/commits?author=betseyliu "Documentation") | [<br /><sub><b>Shero0311</b></sub>](https://github.com/Shero0311)<br />[📖](https://github.com/spritejs/spritejs/commits?author=Shero0311 "Documentation") | [<br /><sub><b>有马</b></sub>](https://github.com/makeco)<br />[📖](https://github.com/spritejs/spritejs/commits?author=makeco "Documentation") [💻](https://github.com/spritejs/spritejs/commit/e2ef39bafd81ee09494f5ebbaf0f8319dbd85122 "Code")| [<br /><sub><b>文蔺</b></sub>](https://github.com/AngusFu)<br />[💻](https://github.com/spritejs/spritejs/commits?author=AngusFu "Code") [🐛](https://github.com/spritejs/spritejs/issues/30 "Bug reports") | [<br /><sub><b>蔡斯杰</b></sub>](https://github.com/SijieCai)<br />[💻](https://github.com/spritejs/sprite-core/commits?author=SijieCai "Code") [📖](https://github.com/spritejs/spritejs/commits?author=SijieCai "Documentation") | [<br /><sub><b>Shaofei Cheng</b></sub>](https://github.com/wintercn)<br />[💻](https://github.com/spritejs/sprite-core/commits?author=wintercn "Code") [📖](https://github.com/spritejs/spritejs/commits?author=wintercn "Documentation") | [<br /><sub><b>摇太阳</b></sub>](https://github.com/yaotaiyang)<br />[📖](https://github.com/spritejs/spritejs/commits?author=yaotaiyang "Documentation")  
| [<br /><sub><b>公子</b></sub>](https://github.com/lizheming)<br />[💻](https://github.com/spritejs/sprite-core/commits?author=lizheming "Code") |  [<br /><sub><b>justemit</b></sub>](https://github.com/justemit)<br />[💻](https://github.com/spritejs/sprite-extend-shapes/commits?author=justemit "Code")  [📖](https://github.com/spritejs/sprite-extend-shapes/commits?author=justemit "Documentation") [🐛](https://github.com/spritejs/sprite-core/issues/34 "Bug reports") | [<br /><sub><b>Welefen Lee</b></sub>](https://github.com/welefen)<br />[💻](https://github.com/spritejs/sprite-flex-layout "Code")   | [<br /><sub><b>YUPENG12138</b></sub>](https://github.com/YUPENG12138)<br />[📖](https://github.com/spritejs/spritejs/issues/52 "Documentation")| [<br /><sub><b>xinde</b></sub>](https://github.com/xinde)<br />[🐛](https://github.com/spritejs/spritejs/issues/59 "Bug reports")| [<br /><sub><b>ggvswild</b></sub>](https://github.com/ggvswild)<br />[🐛](https://github.com/spritejs/spritejs/issues/70 "Bug reports")| [<br /><sub><b>liulinboyi</b></sub>](https://github.com/liulinboyi)<br />[💻](https://github.com/spritejs/spritejs/commits?author=liulinboyi "Code")|
| [<br /><sub><b>Lulzx</b></sub>](https://github.com/Lulzx)<br />[💻](https://github.com/spritejs/sprite-core/commits?author=Lulzx "Code") |  [<br /><sub><b>asidar</b></sub>](https://github.com/asidar)<br />[💻](https://github.com/spritejs/sprite-extend-shapes/commits?author=asidar "Code")  | [<br /><sub><b>alphatr</b></sub>](https://github.com/alphatr)<br />[💻](https://github.com/spritejs/sprite-extend-shapes/commits?author=alphatr "Code")   | [<br /><sub><b>W-Qing</b></sub>](https://github.com/W-Qing)<br />[📖](https://github.com/spritejs/spritejs/commits?author=W-Qing "Documentation") |


<!-- ALL-CONTRIBUTORS-LIST:END -->

## Credits and Acknowledgements

- [svg-path-contours](https://github.com/mattdesl/svg-path-contours) Approximates an SVG path into a discrete list of 2D contours (polylines). 

- [extrude-polyline](https://github.com/mattdesl/extrude-polyline) Extrudes a 2D polyline with a given line thickness and the desired join/cap types. 

- [triangulate-contours](https://github.com/mattdesl/triangulate-contours) Triangulates a series of contours using Tess2.js. 

- [OGL](https://github.com/oframe/ogl) OGL is a small, effective WebGL library aimed at developers who like minimal layers of abstraction, and are comfortable creating their own shaders.

## License

[MIT](LICENSE)
