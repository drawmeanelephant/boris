<p align="center">
  <a href="https://squidfunk.github.io/mkdocs-material/">
    
  </a>
</p>

<p align="center">
  <strong>
    A powerful documentation framework on top of
    <a href="https://www.mkdocs.org/">MkDocs</a>
  </strong>
</p>

<p align="center">
  <a href="https://github.com/squidfunk/mkdocs-material/actions"></a>
  <a href="https://pypistats.org/packages/mkdocs-material"></a>
  <a href="https://pypi.org/project/mkdocs-material"></a>
  <a href="https://hub.docker.com/r/squidfunk/mkdocs-material/"></a>
  <a href="https://github.com/sponsors/squidfunk"></a>
</p>

<p align="center">
  Write your documentation in Markdown and create a professional static site for
  your Open Source or commercial project in minutes – searchable, customizable,
  more than 60 languages, for all devices.
</p>

<p align="center">
  <a href="https://squidfunk.github.io/mkdocs-material/getting-started/">
    
  </a>
</p>

<p align="center">
  <em>
    Check out the demo –
    <a
      href="https://squidfunk.github.io/mkdocs-material/"
    >squidfunk.github.io/mkdocs-material</a>.
  </em>
</p>

<h2></h2>
<p id="premium-sponsors">&nbsp;</p>
<p align="center"><strong>Silver sponsors</strong></p>
<p align="center">
  <a href="https://fastapi.tiangolo.com/" target=_blank></a>
  <a href="https://www.trendpop.com/" target=_blank></a>
</p>
<p>&nbsp;</p>
<p align="center"><strong>Bronze sponsors</strong></p>
<p align="center">
  <a href="https://cirrus-ci.org/" target=_blank></a>
  <a href="https://docs.baslerweb.com/" target=_blank></a>
  <a href="https://kx.com/" target=_blank></a>
  <a href="https://orion-docs.prefect.io/" target=_blank></a>
  <a href="https://www.zenoss.com/" target=_blank></a>
  <a href="https://docs.posit.co" target=_blank></a>
  <a href="https://n8n.io" target=_blank></a>
  <a href="https://www.dogado.de" target=_blank></a>
  <a href="https://wwt.com" target=_blank></a>
  <a href="https://coda.io" target=_blank></a>
  <a href="https://elastic.co" target=_blank></a>
  <a href="https://ipfabric.io/" target=_blank></a>
  <a href="https://www.apex.ai/" target=_blank></a>
  <a href="https://jitterbit.com/" target=_blank></a>
  <a href="https://sparkfun.com/" target=_blank></a>
  <a href="https://eccenca.com/" target=_blank></a>
  <a href="https://neptune.ai/" target=_blank></a>
  <!-- <a href="https://cash.app/" target=_blank></a> -->
  <a href="https://rackn.com/" target=_blank></a>
  <a href="https://civicactions.com/" target=_blank></a>
  <a href="https://bitcrowd.net/" target=_blank></a>
  <a href="https://getscreen.me/" target=_blank></a>
  <a href="https://botcity.dev/" target=_blank></a>
  <a href="https://www.springernature.com/gp" target=_blank></a>
  <a href="https://kolena.io/" target=_blank></a>
  <a href="https://www.evergiving.com/" target=_blank></a>
  <a href="https://koor.tech/" target=_blank></a>
  <a href="https://astral.sh/" target=_blank></a>
  <a href="https://oikolab.com/" target=_blank></a>
  <a href="https://www.buhlergroup.com/" target=_blank></a>
  <a href="https://transformationflow.io/" target=_blank></a>
  <a href="https://3dr.com/" target=_blank></a>
  <a href="https://spotware.com/" target=_blank></a>
  <a href="https://milfordasset.com/" target=_blank></a>
</p>
<p>&nbsp;</p>

## Everything you would expect

### It's just Markdown

Focus on the content of your documentation and create a professional static site
in minutes. No need to know HTML, CSS or JavaScript – let Material for MkDocs do
the heavy lifting for you.

### Works on all devices

Serve your documentation with confidence – Material for MkDocs automatically
adapts to perfectly fit the available screen estate, no matter the type or size
of the viewing device. Desktop. Tablet. Mobile. All great.

### Made to measure

Make it yours – change the colors, fonts, language, icons, logo, and more with
a few lines of configuration. Material for MkDocs can be easily extended and
provides many options to alter appearance and behavior.

### Fast and lightweight

Don't let your users wait – get incredible value with a small footprint by using
one of the fastest themes available with excellent performance, yielding optimal
search engine rankings and happy users that return.

### Built for everyone

Make accessibility a priority – users can navigate your documentation with touch
devices, keyboards, and screen readers. Semantic markup ensures that your
documentation works for everyone.

### Open Source

Trust 20,000+ users – choose a mature and actively maintained solution built
with state-of-the-art Open Source technologies. Keep ownership of your content
without fear of vendor lock-in. Licensed under MIT.

## Quick start

Material for MkDocs can be installed with `pip`:

``` sh
pip install mkdocs-material
```

Add the following lines to `mkdocs.yml`:

``` yaml
theme:
  name: material
```

For detailed installation instructions, configuration options, and a demo, visit
[squidfunk.github.io/mkdocs-material][Material for MkDocs]

  [Material for MkDocs]: https://squidfunk.github.io/mkdocs-material/

## Trusted by ...

### ... industry leaders

[ArXiv](https://info.arxiv.org),
[Atlassian](https://atlassian.github.io/data-center-helm-charts/),
[AWS](https://aws.github.io/copilot-cli/),
[Bloomberg](https://bloomberg.github.io/selekt/),
[CERN](http://abpcomputing.web.cern.ch/),
[CloudFlare](https://cloudflare.github.io/itty-router-openapi/),
[Datadog](https://datadoghq.dev/integrations-core/),
[Google](https://google.github.io/accompanist/),
[Hewlett Packard](https://hewlettpackard.github.io/squest/),
[ING](https://ing-bank.github.io/baker/),
[Intel](https://open-amt-cloud-toolkit.github.io/docs/),
[JetBrains](https://jetbrains.github.io/projector-client/mkdocs/),
[LinkedIn](https://linkedin.github.io/school-of-sre/),
[Microsoft](https://microsoft.github.io/code-with-engineering-playbook/),
[Mozilla](https://mozillafoundation.github.io/engineering-handbook/),
[Netflix](https://netflix.github.io/titus/),
[Red Hat](https://ansible.readthedocs.io/projects/lint/),
[Salesforce](https://policy-sentry.readthedocs.io/en/latest/),
[SIEMENS](https://opensource.siemens.com/),
[Slack](https://slackhq.github.io/circuit/),
[Square](https://square.github.io/okhttp/),
[Zalando](https://opensource.zalando.com/skipper/)

### ... and successful Open Source projects

[Arduino](https://arduino.github.io/arduino-cli/),
[Auto-GPT](https://docs.agpt.co/),
[AutoKeras](https://autokeras.com/),
[BFE](https://www.bfe-networks.net/),
[CentOS](https://docs.infra.centos.org/),
[Crystal](https://crystal-lang.org/reference/),
[Electron](https://www.electron.build/),
[FastAPI](https://fastapi.tiangolo.com/),
[GoReleaser](https://goreleaser.com/),
[Knative](https://knative.dev/docs/),
[Kubernetes](https://kops.sigs.k8s.io/),
[kSQL](https://docs.ksqldb.io/),
[Nokogiri](https://nokogiri.org/),
[OpenFaaS](https://docs.openfaas.com/),
[Percona](https://docs.percona.com/percona-monitoring-and-management/),
[Pi-Hole](https://docs.pi-hole.net/),
[Pydantic](https://pydantic-docs.helpmanual.io/),
[PyPI](https://docs.pypi.org/),
[Renovate](https://docs.renovatebot.com/),
[Traefik](https://docs.traefik.io/),
[Trivy](https://aquasecurity.github.io/trivy/),
[Vapor](https://docs.vapor.codes/),
[ZeroNet](https://zeronet.io/docs/),
[WebKit](https://docs.webkit.org/),
[WTF](https://wtfutil.com/)

## License

**MIT License**

Copyright (c) 2016-2024 Martin Donath

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to
deal in the Software without restriction, including without limitation the
rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
IN THE SOFTWARE.
