[](https://radix-ui.com/primitives)

# Radix Primitives

**An open-source UI component library for building high-quality, accessible design systems and web apps.**

Radix Primitives is a low-level UI component library with a focus on accessibility, customization and developer experience. You can use these components either as the base layer of your design system, or adopt them incrementally.

---

## Documentation

For full documentation, visit [radix-ui.com/docs/primitives](https://radix-ui.com/docs/primitives).

## Releases

For changelog, visit [radix-ui.com/docs/primitives/overview/releases](https://radix-ui.com/docs/primitives/overview/releases).

## Contributing

Please follow our [contributing guidelines](./.github/CONTRIBUTING.md).

## Authors

- Benoit Grelard ([@benoitgrelard](https://twitter.com/benoitgrelard)) - [WorkOS](https://workos.com)
- Jenna Smith ([@jjenzz](https://twitter.com/jjenzz))
- Andy Hook ([@Andy_Hook](https://twitter.com/Andy_Hook)) - [WorkOS](https://workos.com)
- Pedro Duarte ([@peduarte](https://twitter.com/peduarte))
- Chance Strickland ([@chancethedev](https://twitter.com/chancethedev))

## Contributors

- Ar Nazeh ([@Nazeh](https://github.com/Nazeh))
- Fabio Capucci ([@cappuc](https://github.com/cappuc))

---

## Community

- Pedro Duarte ([@peduarte](https://twitter.com/peduarte))
- Colm Tuite ([@colmtuite](https://twitter.com/colmtuite)) - [WorkOS](https://workos.com)

- [Discord](https://discord.com/invite/7Xb99uG) - To get involved with the Radix community, ask questions and share tips.
- [Twitter](https://twitter.com/radix_ui) - To receive updates, announcements, blog posts, and general Radix tips.

## Thanks

<a href="https://www.chromatic.com/"></a>

Thanks to [Chromatic](https://www.chromatic.com/) for providing the visual testing platform that helps us review UI changes and catch visual regressions.

---

## License

Licensed under the MIT License, Copyright © 2022-present [WorkOS](https://workos.com).

See [LICENSE](./LICENSE) for more information.
