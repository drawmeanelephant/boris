<p align="center">

</p>
<h1 align="center">RSSHub</h1>

> 🍰 Everything is RSSible

[](https://rsshub.app)
[](https://hub.docker.com/r/diygod/rsshub)
[](https://www.npmjs.com/package/rsshub)
[](https://github.com/DIYgod/RSSHub/actions/workflows/test.yml?query=event%3Apush+branch%3Amaster)
[](https://app.codecov.io/gh/DIYgod/RSSHub/branch/master)
[](https://www.codefactor.io/repository/github/diygod/rsshub)
[](https://deepscan.io/dashboard#view=project&tid=6244&pid=8135&bid=92448)

[](https://t.me/rsshub) [](https://t.me/awesomeRSSHub)

## Introduction

RSSHub is an open source, easy to use, and extensible RSS feed generator. It's capable of generating RSS feeds from pretty much everything.

RSSHub delivers millions of contents aggregated from all kinds of sources, our vibrant open source community is ensuring the deliver of RSSHub's new routes, new features and bug fixes.

RSSHub can be used with browser extension [RSSHub Radar](https://github.com/DIYgod/RSSHub-Radar) and mobile auxiliary app [RSSBud](https://github.com/Cay-Zhang/RSSBud) (iOS) and [RSSAid](https://github.com/LeetaoGoooo/RSSAid) (Android)

[English docs](https://docs.rsshub.app) | [Telegram Group](https://t.me/rsshub) | [Telegram Channel](https://t.me/awesomeRSSHub)

[中文文档](https://docs.rsshub.app/zh/) | [Telegram 群](https://t.me/rsshub) | [Telegram 频道](https://t.me/awesomeRSSHub)

## Special Thanks

### Special Sponsors

<p>
<a href="https://rss3.io" target="_blank"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://xlog.app/" target="_blank"></a>
</p>

[](https://docs.rsshub.app/support/)

### Contributors

[](https://github.com/DIYgod/RSSHub/graphs/contributors)

Logo designer [sheldonrrr](https://dribbble.com/sheldonrrr)

### Backers

<a href="https://www.cloudflare.com" target="_blank"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://www.netlify.com" target="_blank"></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="https://1password.com" target="_blank"></a>

## Related Projects

-   [RSSHub Radar](https://github.com/DIYgod/RSSHub-Radar) | A browser extension that can help you quickly discover and subscribe to the RSS and RSSHub of current websites.
-   [RSSBud](https://github.com/Cay-Zhang/RSSBud) | RSSHub Radar for iOS platform, designed specifically for mobile ecosystem optimization.
-   [RSSAid](https://github.com/LeetaoGoooo/RSSAid) | RSSHub Radar for Android platform built with Flutter.
-   [DocSearch](https://github.com/Fatpandac/DocSearch) | Link RSSHub DocSearch into Raycast

## Join Us

We welcome all pull requests. Suggestions and feedback are also welcomed [here](https://github.com/DIYgod/RSSHub/issues).

Refer to [Join Us](https://docs.rsshub.app/joinus/quick-start)

## Deployment

Refer to [Deployment](https://docs.rsshub.app/install/)

## Support RSSHub

Refer to [Support RSSHub](https://docs.rsshub.app/support/)

RSSHub is open source and completely free under the MIT license. However, just like any other open source project, as the project grows, the hosting, development and maintenance requires funding support.

You can support RSSHub via donations.

### Recurring Donation

Recurring donors will be rewarded via express issue response, or even have your name displayed on our GitHub page and website.

-   Become a Sponser on [GitHub](https://github.com/sponsors/DIYgod)
-   Become a Sponser on [Patreon](https://www.patreon.com/DIYgod)
-   Become a Sponser on [Open Collective](https://opencollective.com/RSSHub)
-   Become a Sponser on [爱发电](https://afdian.net/@diygod)
-   Contact us directly: <i@diygod.me>

### One-time Donation

We accept donations via the following ways:

-   [WeChat Pay](https://archive.diygod.me/images/wx.jpg)
-   [Alipay](https://archive.diygod.me/images/zfb.jpg)
-   [Paypal](https://www.paypal.me/DIYgod)

## Author

**RSSHub** © [DIYgod](https://github.com/DIYgod), Released under the [MIT](./LICENSE) License.<br>
Authored and maintained by DIYgod with help from contributors ([list](https://github.com/DIYgod/RSSHub/contributors)).

> Blog [@DIYgod](https://diygod.cc) · GitHub [@DIYgod](https://github.com/DIYgod) · Twitter [@DIYgod](https://twitter.com/DIYgod) · Telegram Channel [@awesomeDIYgod](https://t.me/awesomeDIYgod)
