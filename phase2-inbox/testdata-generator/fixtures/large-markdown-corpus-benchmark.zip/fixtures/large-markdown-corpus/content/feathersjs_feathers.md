<a href="https://feathersjs.com" title="FeathersJS">
  
</a>

---

[](https://github.com/feathersjs/feathers/actions?query=workflow%3ACI)
[](https://codeclimate.com/github/feathersjs/feathers/maintainability)
[](https://codeclimate.com/github/feathersjs/feathers/test_coverage)
[](https://www.npmjs.com/package/@feathersjs/feathers)
[](https://discord.gg/qa8kez8QBx)

Feathers is a full-stack framework for creating web APIs and real-time applications with TypeScript or JavaScript.

Feathers can interact with any backend technology, supports many databases out of the box and works with any frontend like React, VueJS, Angular, React Native, Android or iOS.

# Getting started

Get started with just three commands:

```bash
$ npm create feathers my-new-app
$ cd my-new-app
$ npm run dev
```

To learn more about Feathers visit the website at [feathersjs.com](http://feathersjs.com) or jump right into [the Feathers guides](https://feathersjs.com/guides/).

# Contributing

To start developing, clone this repository, then run:

```
cd feathers
npm install
```

To run all tests run

```
npm test
```

Individual tests can be run in the module you are working on:

```
cd packages/feathers
npm test
```

# License

Copyright (c) 2023 [Feathers contributors](https://github.com/feathersjs/feathers/graphs/contributors)

Licensed under the [MIT license](LICENSE).
