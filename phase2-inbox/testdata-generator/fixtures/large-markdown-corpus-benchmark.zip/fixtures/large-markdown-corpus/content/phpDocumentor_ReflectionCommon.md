[](https://opensource.org/licenses/MIT)

[](https://coveralls.io/github/phpDocumentor/ReflectionCommon?branch=master)
[](https://scrutinizer-ci.com/g/phpDocumentor/ReflectionCommon/?branch=master)
[](https://scrutinizer-ci.com/g/phpDocumentor/ReflectionCommon/?branch=master)
[](https://packagist.org/packages/phpDocumentor/Reflection-Common)
[](https://packagist.org/packages/phpDocumentor/Reflection-Common)


ReflectionCommon
================
