# Machine Learning cheatsheets for Stanford's CS 229

Available in [العربية](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/ar) -  [English](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/en) -  [Español](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/es) -  [فارسی](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/fa) -  [Français](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/fr) -  [한국어](https://stanford.edu/~shervine/l/ko/teaching/cs-229/cheatsheet-machine-learning-tips-and-tricks) -  [Português](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/pt) -  [Türkçe](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/tr) - [Tiếng Việt](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/vi) -  [简中](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/zh) -  [繁中](https://github.com/afshinea/stanford-cs-229-machine-learning/tree/master/zh-tw)

## Goal
This repository aims at summing up in the same place all the important notions that are covered in Stanford's CS 229 Machine Learning course, and include:
- **Refreshers** in related topics that highlight the key points of the **prerequisites of the course**.
- **Cheatsheets for each machine learning field**, as well as another dedicated to tips and tricks to have in mind when training a model.
- All elements of the above combined in an **ultimate compilation of concepts**, to have with you at all times!

## Content
#### VIP Cheatsheets
|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/cheatsheet-supervised-learning.pdf"></a>|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/cheatsheet-unsupervised-learning.pdf"></a>|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/cheatsheet-deep-learning.pdf"></a>|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/cheatsheet-machine-learning-tips-and-tricks.pdf"></a>|
|:--:|:--:|:--:|:--:|
|Supervised Learning|Unsupervised Learning|Deep Learning|Tips and tricks|

#### VIP Refreshers
|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/refresher-probabilities-statistics.pdf"></a>|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/refresher-algebra-calculus.pdf"></a>|
|:--:|:--:|
|Probabilities and Statistics|Algebra and Calculus|


#### Super VIP Cheatsheet
|<a href="https://github.com/afshinea/stanford-cs-229-machine-learning/blob/master/en/super-cheatsheet-machine-learning.pdf"></a>|
|:--:|
|All the above gathered in one place|

## Website
This material is also available on a dedicated [website](https://stanford.edu/~shervine/teaching/cs-229), so that you can enjoy reading it from any device.

## Translation
Would you like to see these cheatsheets in your native language? You can help us translating them on [this dedicated repo](https://github.com/shervinea/cheatsheet-translation)!

## Authors
[Afshine Amidi](https://twitter.com/afshinea) (Ecole Centrale Paris, MIT) and [Shervine Amidi](https://twitter.com/shervinea) (Ecole Centrale Paris, Stanford University)
