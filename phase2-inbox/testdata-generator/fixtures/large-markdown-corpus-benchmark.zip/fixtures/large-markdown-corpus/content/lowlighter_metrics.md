# 📊 Metrics [](https://www.producthunt.com/posts/github-metrics?utm_source=badge-featured&utm_medium=badge&utm_source=badge-github-metrics)

[](https://github.com/lowlighter/metrics/actions/workflows/ci.yml)

Generate metrics that can be embedded everywhere, including your GitHub profile readme! Supports users, organizations, and even repositories!

<table>
  <tr>
    <th align="center">For user accounts</th>
    <th align="center">For organization accounts</th>
  </tr>
  <tr>
    <td align="center">
</img>
</td>
<td align="center">
</img>
</td>
  </tr>
  <tr>
    <th colspan="2" align="center">
      <h3><a href="/README.md#-plugins">🧩 Customizable with 47 plugins and 335 options!</a></h3>
    </th>
  </tr>
  <tr>
    <th><a href="source/plugins/isocalendar/README.md">📅 Isometric commit calendar</a></th>
    <th><a href="source/plugins/languages/README.md">🈷️ Languages activity</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Full year calendar</summary></img></details>
        <details><summary>Half year calendar</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>Indepth analysis (clone and analyze repositories)</summary></img></details>
        <details open><summary>Recently used (analyze recent activity events)</summary></img></details>
        <details><summary>Default algorithm</summary></img></details>
        <details><summary>Default algorithm (with details)</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/stargazers/README.md">✨ Stargazers</a></th>
    <th><a href="source/plugins/lines/README.md">👨‍💻 Lines of code changed</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Classic charts</summary></img></details>
        <details><summary>Graph charts</summary></img></details>
        <details open><summary>Worldmap</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>Repositories and diff history</summary></img></details>
        <details><summary>Compact display in base plugin</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/topics/README.md">📌 Starred topics</a></th>
    <th><a href="source/plugins/stars/README.md">🌟 Recently starred repositories</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>With icons</summary></img></details>
        <details open><summary>With labels</summary></img></details>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/licenses/README.md">📜 Repository licenses</a></th>
    <th><a href="source/plugins/habits/README.md">💡 Coding habits and activity</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Permissions, limitations and conditions</summary></img></details>
        <details open><summary>Licenses overview</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>Recent activity charts</summary></img></details>
        <details open><summary>Mildly interesting facts</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/contributors/README.md">🏅 Repository contributors</a></th>
    <th><a href="source/plugins/followup/README.md">🎟️ Follow-up of issues and pull requests</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>By contribution types</summary></img></details>
        <details><summary>By number of contributions</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>Indepth analysis</summary></img></details>
        <details><summary>Created on a user's repositories</summary></img></details>
        <details><summary>Created by a user</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/reactions/README.md">🎭 Comment reactions</a></th>
    <th><a href="source/plugins/people/README.md">🧑‍🤝‍🧑 People</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        <details open><summary>Related to a user</summary></img></details>
        <details><summary>Related to a repository</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/sponsorships/README.md">💝 GitHub Sponsorships</a></th>
    <th><a href="source/plugins/sponsors/README.md">💕 GitHub Sponsors</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        <details open><summary>GitHub sponsors card</summary></img></details>
        <details><summary>GitHub sponsors full introduction</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/repositories/README.md">📓 Featured repositories</a></th>
    <th><a href="source/plugins/discussions/README.md">💬 Discussions</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Featured</summary></img></details>
        <details><summary>Pinned</summary></img></details>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/starlists/README.md">💫 Star lists</a></th>
    <th><a href="source/plugins/calendar/README.md">📆 Commit calendar</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Repositories from star lists</summary></img></details>
        <details open><summary>Languages from star lists</summary></img></details>
        
      </td>
        <td  align="center">
        <details><summary>Current year</summary></img></details>
        <details open><summary>Full history</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/achievements/README.md">🏆 Achievements</a></th>
    <th><a href="source/plugins/notable/README.md">🎩 Notable contributions</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Compact display</summary></img></details>
        <details><summary>Detailed display</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>Indepth analysis</summary></img></details>
        <details><summary>Contributions in organizations only</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/activity/README.md">📰 Recent activity</a></th>
    <th><a href="source/plugins/traffic/README.md">🧮 Repositories traffic</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/code/README.md">♐ Random code snippet</a></th>
    <th><a href="source/plugins/gists/README.md">🎫 Gists</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/projects/README.md">🗂️ GitHub projects</a></th>
    <th><a href="source/plugins/introduction/README.md">🙋 Introduction</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        <details open><summary>For a user or an organization</summary></img></details>
        <details><summary>For a repository</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/skyline/README.md">🌇 GitHub Skyline</a></th>
    <th><a href="source/plugins/pagespeed/README.md">⏱️ Google PageSpeed</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>GitHub Skyline</summary></img></details>
        <details><summary>GitHub City</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>PageSpeed scores</summary></img></details>
        <details><summary>PageSpeed scores with detailed report</summary></img></details>
        <details><summary>PageSpeed scores with a website screenshot</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/stackoverflow/README.md">🗨️ Stack Overflow</a></th>
    <th><a href="source/plugins/anilist/README.md">🌸 Anilist watch list and reading list</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        <details open><summary>For anime watchers</summary></img></details>
        <details><summary>For manga readers</summary></img></details>
        <details open><summary>For waifus simp</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/music/README.md">🎼 Music activity and suggestions</a></th>
    <th><a href="source/plugins/posts/README.md">✒️ Recent posts</a></th>
  </tr>
  <tr>
        <td  align="center">
        <details open><summary>Random tracks from a playlist</summary></img></details>
        <details open><summary>Recently listened</summary></img></details>
        
      </td>
        <td  align="center">
        <details open><summary>Latest posts width description and cover image</summary></img></details>
        <details><summary>Latest posts</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/rss/README.md">🗼 Rss feed</a></th>
    <th><a href="source/plugins/wakatime/README.md">⏰ WakaTime</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th><a href="source/plugins/leetcode/README.md">🗳️ Leetcode</a></th>
    <th><a href="source/plugins/steam/README.md">🕹️ Steam</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        <details open><summary>Recently played games</summary></img></details>
        <details><summary>Profile and detailed game history</summary></img></details>
        
      </td>
  </tr>
  <tr>
    <th colspan="2" align="center">
      <a href="/source/plugins/community/README.md">🎲 See also community plugins</a>
    </th>
  </tr>
  <tr>
    <th><a href="source/plugins/community/16personalities/README.md">🧠 16personalities</a><br><sup>by <a href="https://github.com/lowlighter">@lowlighter</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
    <th><a href="source/plugins/community/chess/README.md">♟️ Chess</a><br><sup>by <a href="https://github.com/lowlighter">@lowlighter</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
  </tr>
  <tr>
    <th><a href="source/plugins/community/crypto/README.md">🪙 Crypto</a><br><sup>by <a href="https://github.com/dajneem23">@dajneem23</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
    <th><a href="source/plugins/community/fortune/README.md">🥠 Fortune</a><br><sup>by <a href="https://github.com/lowlighter">@lowlighter</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
  </tr>
  <tr>
    <th><a href="source/plugins/community/nightscout/README.md">💉 Nightscout</a><br><sup>by <a href="https://github.com/legoandmars">@legoandmars</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
    <th><a href="source/plugins/community/poopmap/README.md">💩 PoopMap plugin</a><br><sup>by <a href="https://github.com/matievisthekat">@matievisthekat</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
  </tr>
  <tr>
    <th><a href="source/plugins/community/screenshot/README.md">📸 Website screenshot</a><br><sup>by <a href="https://github.com/lowlighter">@lowlighter</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
    <th><a href="source/plugins/community/splatoon/README.md">🦑 Splatoon</a><br><sup>by <a href="https://github.com/lowlighter">@lowlighter</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
  </tr>
  <tr>
    <th><a href="source/plugins/community/stock/README.md">💹 Stock prices</a><br><sup>by <a href="https://github.com/lowlighter">@lowlighter</a></sup>
      <details><summary>Render example</summary>
        </img>
        
      </details>
    </th>
    <th>
    </th>
  </tr>
  <tr>
    <th colspan="2" align="center">
      <h3><a href="/README.md#%EF%B8%8F-templates">🖼️ And even more with 4+ templates!</a></h3>
    </th>
  </tr>
  <tr>
    <th><a href="/source/templates/classic/README.md">📗 Classic template</a></th>
    <th><a href="/source/templates/repository/README.md">📘 Repository template</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th><a href="/source/templates/terminal/README.md">📙 Terminal template</a></th>
    <th><a href="/source/templates/markdown/README.md">📒 Markdown template</a></th>
  </tr>
  <tr>
        <td  align="center">
        </img>
        
      </td>
        <td  align="center">
        </img>
        
      </td>
  </tr>
  <tr>
    <th colspan="2"><a href="/source/templates/community/README.md">📕 See also community templates</a></th>
  </tr>
  <tr>
    <th colspan="2"><h2>🦑 Try it now!</h2></th>
  </tr>
  <tr>
    <th><a href="https://metrics.lecoq.io/embed">📊 Metrics embed</a></th>
    <th><a href="https://metrics.lecoq.io/insights">✨ Metrics insights</a></th>
  </tr>
  <tr>
    <td align="center">
      Embed metrics images on your profile or blog!<br>
      Use <a href="https://github.com/marketplace/actions/metrics-embed">GitHub actions</a> for even more features!<br>
      
    </td>
    <td align="center">
      Share your metrics with friends and on social medias!<br>
      No configuration needed!<br>
      
    </td>
  </tr>
  <tr>
    <td align="center" colspan="2">
      Test latest features and patches on <code><a href="https://beta-metrics.lecoq.io">🧪 Metrics beta</a></code>!
    </td>
  </tr>
  <tr>
    <td align="center" colspan="2">
      <b>Power user?</b><br>
      <a href="https://github.com/lowlighter/metrics/fork">Fork this repository</a> and edit HTML, CSS, JS and <a href="https://github.com/mde/ejs">EJS</a> for even more customization!
    </td>
  </tr>
</table>


# 📚 Documentation


> <sup>*⚠️ This is the documentation of **v3.35-beta** (`@master`/`@main` branches) which includes [unreleased features](https://github.com/lowlighter/metrics/compare/latest...master) planned for next release. See documentation for current released version [**v3.34** (`@latest` branch) here](https://github.com/lowlighter/metrics/blob/latest/README.md).* </sup>



## 🦮 Setup

There are several ways to setup metrics, each having its advantages and disadvantages:

* [⚙️ Using GitHub Action on a profile repository *(~10 min)*](/.github/readme/partials/documentation/setup/action.md)
  * ✔️ All features
  * ✔️ High availability (no downtimes)
  * ➖ Configuration can be a bit time-consuming
* [💕 Using the shared instance *(~1 min)*](/.github/readme/partials/documentation/setup/shared.md)
  * ✔️ Easily configurable and previewable
  * ➖ Limited features *(compute-intensive features are disabled)*
* [🏗️ Deploying a web instance *(~20 min)*](/.github/readme/partials/documentation/setup/web.md)
  * ✔️ Create another shared instance
  * ➖ Requires some sysadmin knowledge
* [🐳 Using command line with docker *(~2 min)*](/.github/readme/partials/documentation/setup/docker.md)
  * ✔️ Suited for one-time rendering
* [🔧 Local setup for development *(~20 min)*](/.github/readme/partials/documentation/setup/local.md)

Additional resources for setup:
* [🏦 Configure metrics for organizations](/.github/readme/partials/documentation/organizations.md)
* [🏠 Run metrics on self-hosted runners](/.github/readme/partials/documentation/selfhosted.md)
* [🧰 Template/Plugin compatibility matrix](/.github/readme/partials/documentation/compatibility.md)
## 🖼️ Templates

Templates lets you change general appearance of rendered metrics.


* [📗 Classic template <sub>`classic`</sub>](/source/templates/classic/README.md)
* [📘 Repository template <sub>`repository`</sub>](/source/templates/repository/README.md)
* [📙 Terminal template <sub>`terminal`</sub>](/source/templates/terminal/README.md)
* [📒 Markdown template <sub>`markdown`</sub>](/source/templates/markdown/README.md)
* [📕 Community templates <sub>`community`</sub>](/source/templates/community/README.md)

## 🧩 Plugins

Plugins provide additional content and lets you customize rendered metrics.

**📦 Maintained by core team**

* **Core plugins**
  * [🗃️ Base content <sub>`base`</sub>](/source/plugins/base/README.md)
  * [🧱 Core <sub>`core`</sub>](/source/plugins/core/README.md)
* **GitHub plugins**
  * [🏆 Achievements <sub>`achievements`</sub>](/source/plugins/achievements/README.md)
  * [📰 Recent activity <sub>`activity`</sub>](/source/plugins/activity/README.md)
  * [📆 Commit calendar <sub>`calendar`</sub>](/source/plugins/calendar/README.md)
  * [♐ Random code snippet <sub>`code`</sub>](/source/plugins/code/README.md)
  * [🏅 Repository contributors <sub>`contributors`</sub>](/source/plugins/contributors/README.md)
  * [💬 Discussions <sub>`discussions`</sub>](/source/plugins/discussions/README.md)
  * [🎟️ Follow-up of issues and pull requests <sub>`followup`</sub>](/source/plugins/followup/README.md)
  * [🎫 Gists <sub>`gists`</sub>](/source/plugins/gists/README.md)
  * [💡 Coding habits and activity <sub>`habits`</sub>](/source/plugins/habits/README.md)
  * [🙋 Introduction <sub>`introduction`</sub>](/source/plugins/introduction/README.md)
  * [📅 Isometric commit calendar <sub>`isocalendar`</sub>](/source/plugins/isocalendar/README.md)
  * [🈷️ Languages activity <sub>`languages`</sub>](/source/plugins/languages/README.md)
  * [📜 Repository licenses <sub>`licenses`</sub>](/source/plugins/licenses/README.md)
  * [👨‍💻 Lines of code changed <sub>`lines`</sub>](/source/plugins/lines/README.md)
  * [🎩 Notable contributions <sub>`notable`</sub>](/source/plugins/notable/README.md)
  * [🧑‍🤝‍🧑 People <sub>`people`</sub>](/source/plugins/people/README.md)
  * [🗂️ GitHub projects <sub>`projects`</sub>](/source/plugins/projects/README.md)
  * [🎭 Comment reactions <sub>`reactions`</sub>](/source/plugins/reactions/README.md)
  * [📓 Featured repositories <sub>`repositories`</sub>](/source/plugins/repositories/README.md)
  * [🌇 GitHub Skyline <sub>`skyline`</sub>](/source/plugins/skyline/README.md)
  * [💕 GitHub Sponsors <sub>`sponsors`</sub>](/source/plugins/sponsors/README.md)
  * [💝 GitHub Sponsorships <sub>`sponsorships`</sub>](/source/plugins/sponsorships/README.md)
  * [✨ Stargazers <sub>`stargazers`</sub>](/source/plugins/stargazers/README.md)
  * [💫 Star lists <sub>`starlists`</sub>](/source/plugins/starlists/README.md)
  * [🌟 Recently starred repositories <sub>`stars`</sub>](/source/plugins/stars/README.md)
  * [💭 GitHub Community Support <sub>`support`</sub>](/source/plugins/support/README.md) <sub>`⚠️ deprecated`</sub>
  * [📌 Starred topics <sub>`topics`</sub>](/source/plugins/topics/README.md)
  * [🧮 Repositories traffic <sub>`traffic`</sub>](/source/plugins/traffic/README.md)
* **Social plugins**
  * [🌸 Anilist watch list and reading list <sub>`anilist`</sub>](/source/plugins/anilist/README.md)
  * [🗳️ Leetcode <sub>`leetcode`</sub>](/source/plugins/leetcode/README.md)
  * [🎼 Music activity and suggestions <sub>`music`</sub>](/source/plugins/music/README.md)
  * [⏱️ Google PageSpeed <sub>`pagespeed`</sub>](/source/plugins/pagespeed/README.md)
  * [✒️ Recent posts <sub>`posts`</sub>](/source/plugins/posts/README.md)
  * [🗼 Rss feed <sub>`rss`</sub>](/source/plugins/rss/README.md)
  * [🗨️ Stack Overflow <sub>`stackoverflow`</sub>](/source/plugins/stackoverflow/README.md)
  * [🕹️ Steam <sub>`steam`</sub>](/source/plugins/steam/README.md)
  * [🐤 Latest tweets <sub>`tweets`</sub>](/source/plugins/tweets/README.md) <sub>`⚠️ deprecated`</sub>
  * [⏰ WakaTime <sub>`wakatime`</sub>](/source/plugins/wakatime/README.md)

**🎲 Maintained by community**
* **[Community plugins](/source/plugins/community/README.md)**
  * [🧠 16personalities <sub>`16personalities`</sub>](/source/plugins/community/16personalities/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [♟️ Chess <sub>`chess`</sub>](/source/plugins/community/chess/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [🪙 Crypto <sub>`crypto`</sub>](/source/plugins/community/crypto/README.md) by [@dajneem23](https://github.com/dajneem23)
  * [🥠 Fortune <sub>`fortune`</sub>](/source/plugins/community/fortune/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [💉 Nightscout <sub>`nightscout`</sub>](/source/plugins/community/nightscout/README.md) by [@legoandmars](https://github.com/legoandmars)
  * [💩 PoopMap plugin <sub>`poopmap`</sub>](/source/plugins/community/poopmap/README.md) by [@matievisthekat](https://github.com/matievisthekat)
  * [📸 Website screenshot <sub>`screenshot`</sub>](/source/plugins/community/screenshot/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [🦑 Splatoon <sub>`splatoon`</sub>](/source/plugins/community/splatoon/README.md) by [@lowlighter](https://github.com/lowlighter)
  * [💹 Stock prices <sub>`stock`</sub>](/source/plugins/community/stock/README.md) by [@lowlighter](https://github.com/lowlighter)


## 💪 Contributing

If you are interested in contributing, the following resources may interest you:

* [💪 Contribution guide](/CONTRIBUTING.md)
* [🧬 Architecture](/ARCHITECTURE.md)
* [📜 License](/LICENSE)
* **:octocat: GitHub resources**
  * [📖 GitHub GraphQL API](https://docs.github.com/en/graphql)
  * [📖 GitHub GraphQL Explorer](https://docs.github.com/en/free-pro-team@latest/graphql/overview/explorer)
  * [📖 GitHub Rest API](https://docs.github.com/en/rest)
  * [📖 GitHub Octicons](https://github.com/primer/octicons)

Use [`💬 discussions`](https://github.com/lowlighter/metrics/discussions) for feedback, new features suggestions, bugs reports or to request help for installation.


## 📜 License

```
MIT License
Copyright (c) 2020-present lowlighter
```




