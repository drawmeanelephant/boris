[](https://getuikit.com/)

# UIkit

[](https://discord.gg/NEt4Pv7)
[](https://circleci.com/gh/uikit/uikit)
[](https://www.jsdelivr.com/package/npm/uikit)

UIkit is a lightweight and modular front-end framework for developing fast and powerful web interfaces.

* [Homepage](https://getuikit.com) - Learn more about UIkit
* [@getuikit](https://twitter.com/getuikit) - Get the latest buzz on Twitter
* [Discord Chat](https://discord.gg/NEt4Pv7) - Join our developer chat on Discord.

---

<p align="center">
  <b>UIkit is an Open Source project developed by YOOtheme.</b>
  <br><br>
  <a href="https://yootheme.com" align="center">
      
  </a>
</p>

---

## Getting started

You have the following options to get UIkit:

- Download the [latest release](https://github.com/uikit/uikit/releases/latest) with pre-built CSS and JS.
- Install with [npm](https://npmjs.com) to get all source files as they are available on GitHub: ```npm install uikit```
- Install with [yarn](https://yarnpkg.com/) to get all source files as they are available on GitHub: ```yarn add uikit```
- Install with [pnpm](https://pnpm.io/) to get all source files as they are available on GitHub: ```pnpm add uikit```
- Directly load UIkit from [jsDelivr](https://www.jsdelivr.com): https://www.jsdelivr.com/package/npm/uikit
- Clone the repo to get all source files including build scripts: `git clone git@github.com:uikit/uikit.git`

## Developers

To always have the latest development version of UIkit, even before a release, you may want to use npm or yarn with the `dev` tag.

- Using npm: ```npm install uikit@dev```
- Using yarn: ```yarn add uikit@dev```
- Using pnpm: ```pnpm add uikit@dev```
- Using [cdn](cdn.jsdelivr.net): https://cdn.jsdelivr.net/npm/uikit@dev

## Contributing

Finding bugs, sending pull requests or improving our docs - any contribution is welcome and highly appreciated. To get started, head over to our [contribution guidelines](CONTRIBUTING.md). Thanks!

## Versioning

UIkit is maintained by using the [Semantic Versioning Specification (SemVer)](https://semver.org).

## Browser Support

|  |  |  |  |  |
|-------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------|----------------------------------------------------------------------------------|-------------------------------------------------------------------------------------|
| Latest ✔                                                                                  | Latest ✔                                                                               | Latest ✔                                                                               | Latest ✔                                                                         | Latest ✔                                                                            |

Tested With<br>[](https://www.browserstack.com)

## Copyright and License

Copyright [YOOtheme](https://yootheme.com) GmbH under the [MIT license](LICENSE.md).
