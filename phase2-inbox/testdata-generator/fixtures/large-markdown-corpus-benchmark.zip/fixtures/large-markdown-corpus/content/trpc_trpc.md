<a href="https://trpc.io/" target="_blank" rel="noopener">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://assets.trpc.io/www/trpc-readme-dark.png" />
    
  </picture>
</a>

<div align="center">
  <h1>tRPC</h1>
  <h3>Move fast and break nothing.<br />End-to-end typesafe APIs made easy.</h3>
  <a href="https://codecov.io/gh/trpc/trpc">
    
  </a>
  <a href="https://npmcharts.com/compare/@trpc/server?interval=30">
    
  </a>
  <a href="https://github.com/trpc/trpc/blob/main/LICENSE">
    
  </a>
  <a href="https://trpc.io/discord">
    
  </a>
  <br />
  <a href="https://twitter.com/trpcio">
    
  </a>
  <br />
  <br />
  <figure>
    
    <figcaption>
      <p align="center">
        The client above is <strong>not</strong> importing any code from the server, only its type declarations.
      </p>
    </figcaption>
  </figure>
</div>

<br />

> [!NOTE]
>
> You are looking at the `next`-branch of tRPC which is the current work in progress representing **version 11**.
>
> - The functionality is **stable and can be used in production**, but we may do small breaking API-changes between patches until we reach `11.0.0`
> - The packages are published with the `next`-tag on npm
> - For the list of changes made, see https://trpc.io/docs/v11/migrate-from-v10-to-v11

## Intro

tRPC allows you to easily build & consume fully typesafe APIs without schemas or code generation.

### Features

- ✅&nbsp; Well-tested and production ready.
- 🧙‍♂️&nbsp; Full static typesafety & autocompletion on the client, for inputs, outputs, and errors.
- 🐎&nbsp; Snappy DX - No code generation, run-time bloat, or build pipeline.
- 🍃&nbsp; Light - tRPC has zero deps and a tiny client-side footprint.
- 🐻&nbsp; Easy to add to your existing brownfield project.
- 🔋&nbsp; Batteries included - React.js/Next.js/Express.js/Fastify adapters. _(But tRPC is not tied to React, and there are many [community adapters](https://trpc.io/docs/awesome-trpc#-extensions--community-add-ons) for other libraries)_
- 🥃&nbsp; Subscriptions support.
- ⚡️&nbsp; Request batching - requests made at the same time can be automatically combined into one
- 👀&nbsp; Quite a few examples in the [./examples](./examples)-folder

## Quickstart

There are a few [examples](https://trpc.io/docs/example-apps) that you can use for playing out with tRPC or bootstrapping your new project. For example, if you want a Next.js app, you can use the full-stack Next.js example:

**Quick start with a full-stack Next.js example:**

```sh
# yarn
yarn create next-app --example https://github.com/trpc/trpc --example-path examples/next-prisma-starter trpc-prisma-starter

# npm
npx create-next-app --example https://github.com/trpc/trpc --example-path examples/next-prisma-starter trpc-prisma-starter

# pnpm
pnpm create next-app --example https://github.com/trpc/trpc --example-path examples/next-prisma-starter trpc-prisma-starter

# bun
bunx create-next-app --example https://github.com/trpc/trpc --example-path examples/next-prisma-starter trpc-prisma-starter
```

**👉 See full documentation on [tRPC.io](https://trpc.io/docs). 👈**

## Star History

<a href="https://star-history.com/#trpc/trpc"></a>

## Core Team

> Do you want to contribute? First, read the <a href="https://github.com/trpc/trpc/blob/main/CONTRIBUTING.md">Contributing Guidelines</a> before opening an issue or PR so you understand the branching strategy and local development environment. If you need any more guidance or want to ask more questions, feel free to write to us on <a href="https://trpc.io/discord">Discord</a>!

<table>
  <tr>
    <td align="center"><a href="https://twitter.com/alexdotjs"><br /><sub><b>Alex / KATT</b></sub></a></td>
    <td>👋 Hi, I'm Alex and I am the creator of tRPC, don't hesitate to contact me on <a href="https://twitter.com/alexdotjs">Twitter</a> or <a href="mailto:alex@trpc.io">email</a> if you are curious about tRPC in any way.</td>
  </tr>
</table>

### Project leads

> The people who lead the API-design decisions and have the most active role in the development

<table>
  <tbody>
    <tr>
      <td align="center"><a href="http://www.jumr.dev"><br /><sub><b>Julius Marminge</b></sub></a></td>
      <td align="center"><a href="https://twitter.com/alexdotjs"><br /><sub><b>Alex / KATT</b></sub></a></td>
    </tr>
  </tbody>
</table>

### Active contributors

> People who actively help out improving the codebase by making PRs and reviewing code

<table>
  <tbody>
    <tr>
      <td align="center"><a href="https://github.com/Nick-Lucas"><br /><sub><b>Nick Lucas</b></sub></a></td>
      <td align="center"><a href="https://github.com/Sheraff"><br /><sub><b>Flo</b></sub></a></td>
      <td align="center"><a href="https://twitter.com/s4chinraja"><br /><sub><b>Sachin Raja</b></sub></a></td>
    </tr>
  </tbody>
</table>

### Special shout-outs

<table>
  <tbody>
    <tr>
      <td align="center"><a href="https://twitter.com/trashh_dev"><br /><sub><b>Chris Bautista</b></sub></a></td>
      <td align="center"><a href="http://t3.gg"><br /><sub><b>Theo Browne</b></sub></a></td>
      <td align="center"><a href="https://elsakaan.dev"><br /><sub><b>Ahmed Elsakaan</b></sub></a></td>
      <td align="center"><a href="https://twitter.com/jlalmes"><br /><sub><b>James Berry</b></sub></a></td>
      <td align="center"><a href="https://github.com/kamilogorek"><br /><sub><b>Kamil Ogórek</b></sub></a></td>
    </tr>
  </tbody>
</table>

## Sponsors

If you enjoy working with tRPC and want to support me consider giving a token appreciation by [GitHub Sponsors](https://trpc.io/sponsor)!

Also, if your company using tRPC and want to support long-term maintenance of tRPC, have a look at the [sponsorship tiers](https://trpc.io/sponsor) or [get in touch](mailto:alex@trpc.io) to discuss potential partnerships.

<!-- SPONSORS:LIST:START -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->

### 🥇 Gold Sponsors

<table>
  <tr>
   <td align="center"><a href="https://tolahq.com/?ref=trpc"><br />Tola</a></td>
  </tr>
</table>

### 🥈 Silver Sponsors

<table>
  <tr>
   <td align="center"><a href="https://cal.com/?ref=trpc"><br />Cal.com, Inc.</a></td>
  </tr>
</table>

### 🥉 Bronze Sponsors

<table>
  <tr>
   <td align="center"><a href="http://echobind.com/?ref=trpc"><br />Echobind</a></td>
   <td align="center"><a href="https://github.com/hidrb"><br />Dr. B</a></td>
   <td align="center"><a href="http://flylance.com/?ref=trpc"><br />Flylance</a></td>
  </tr>
</table>

### 😻 Smaller Backers

<table>
  <tr>
   <td align="center"><a href="https://faraday.dev/?ref=trpc"><br />Ahoy Labs</a></td>
   <td align="center"><a href="http://brooke.me/?ref=trpc"><br />Brooke</a></td>
   <td align="center"><a href="https://maxgreenwald.me/?ref=trpc"><br />Max Greenwald</a></td>
   <td align="center"><a href="http://ballingt.com/?ref=trpc"><br />Tom Ballinger</a></td>
   <td align="center"><a href="https://farazpatankar.com/?ref=trpc"><br />Faraz Patankar</a></td>
   <td align="center"><a href="https://github.com/aslaker"><br />Adam Slaker</a></td>
  </tr>
  <tr>
   <td align="center"><a href="https://github.com/dmaykov"><br />Dmitry Maykov</a></td>
   <td align="center"><a href="https://chrisbradley.dev/?ref=trpc"><br />Chris Bradley</a></td>
   <td align="center"><a href="https://elsakaan.dev/?ref=trpc"><br />Ahmed Elsakaan</a></td>
   <td align="center"><a href="https://hampuskraft.com/?ref=trpc"><br />Hampus Kraft</a></td>
   <td align="center"><a href="https://www.illarionvk.com/?ref=trpc"><br />Illarion Koperski</a></td>
   <td align="center"><a href="https://iamkhan.io/?ref=trpc"><br />SchlagerKhan</a></td>
  </tr>
  <tr>
   <td align="center"><a href="http://jwyce.gg/?ref=trpc"><br />Jared Wyce</a></td>
   <td align="center"><a href="https://www.fanvue.com/?ref=trpc"><br />fanvue</a></td>
   <td align="center"><a href="https://github.com/andrew-werdna"><br />Andrew Brown</a></td>
   <td align="center"><a href="https://github.com/AscentFactory"><br />Ascent Factory</a></td>
   <td align="center"><a href="https://jonas-strassel.de/?ref=trpc"><br />Jonas Strassel</a></td>
   <td align="center"><a href="https://frontj.com/?ref=trpc"><br />Jordy</a></td>
  </tr>
  <tr>
   <td align="center"><a href="http://danielburger.online/?ref=trpc"><br />Daniel Burger</a></td>
   <td align="center"><a href="https://www.scaleleap.com/?ref=trpc"><br />Scale Leap</a></td>
   <td align="center"><a href="https://github.com/drwpwrs"><br />Drew Powers</a></td>
   <td align="center"><a href="https://drizzle.team/?ref=trpc"><br />Drizzle Team</a></td>
   <td align="center"><a href="https://github.com/ZionLG"><br />Liran Goldman</a></td>
   <td align="center"><a href="https://www.spencermckenney.com/?ref=trpc"><br />Spencer McKenney</a></td>
  </tr>
  <tr>
   <td align="center"><a href="https://github.com/mcmaterassi"><br />mcmaterassi</a></td>
   <td align="center"><a href="https://github.com/oskarhertzman"><br />Oskar Hertzman</a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- SPONSORS:LIST:END -->

## All contributors ✨

> tRPC is developed by [KATT](https://twitter.com/alexdotjs), originally based on a proof-of-concept by [colinhacks](https://github.com/colinhacks).

<a href="https://github.com/trpc/trpc/graphs/contributors">
  <p align="center">
    
  </p>
</a>

---

<a href="https://vercel.com/?utm_source=trpc&utm_campaign=oss">
  <p align="center">
    
  </p>
</a>
