# VitePress 📝💨

[](https://github.com/vuejs/vitepress/actions)
[](https://www.npmjs.com/package/vitepress)
[](https://chat.vuejs.org)

---

VitePress is a Vue-powered static site generator and a spiritual successor to [VuePress](https://vuepress.vuejs.org), built on top of [Vite](https://github.com/vitejs/vite).

## Documentation

To check out docs, visit [vitepress.dev](https://vitepress.dev).

## Changelog

Detailed changes for each release are documented in the [CHANGELOG](https://github.com/vuejs/vitepress/blob/main/CHANGELOG.md).

## Contribution

Please make sure to read the [Contributing Guide](https://github.com/vuejs/vitepress/blob/main/.github/contributing.md) before making a pull request.

## License

[MIT](https://github.com/vuejs/vitepress/blob/main/LICENSE)

Copyright (c) 2019-present, Yuxi (Evan) You
