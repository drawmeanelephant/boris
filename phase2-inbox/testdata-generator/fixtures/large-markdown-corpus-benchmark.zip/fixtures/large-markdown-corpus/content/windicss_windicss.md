<p align="center" style="background-color: #FFFF99; padding: 15px; border-radius: 5px;">
  <strong>⚠️ Windi CSS is Sunsetting ⚠️</strong><br>
  We are sunsetting Windi CSS and we recommend new projects to seek for alternatives. Read the <a href="https://windicss.org/posts/sunsetting.html">full blog post</a>.
</p>

<hr>

<h1 align="center">
<a href="https://github.com/windicss/windicss/wiki">
  <br>
</a>
  Windi CSS
</h1>

<p align="center">
  <a href="https://www.npmjs.com/package/windicss"></a>
  <a href="https://www.npmjs.com/package/windicss"></a>
  <a href="https://github.com/windicss/windicss/actions"></a>
  <a href="https://codecov.io/gh/windicss/windicss"></a>
  <br>
  <a href="https://discord.gg/aRYWm8r8Eq"></a>
  <br>
</p>

<p align="center">Next generation utility-first CSS framework.</p>

[windi css]: https://windicss.org
[website]: https://windicss.org
[video comparison]: https://twitter.com/antfu7/status/1361398324587163648

## Why Windi CSS? 🤔

A quote from the author should illustrate his motivation to create [Windi CSS]:

> When my project became larger and there were about dozens of components, the initial compilation time reached 3s, and hot updates took more than 1s with Tailwind CSS. - [@voorjaar](https://github.com/voorjaar)

By scanning your HTML and CSS and generating utilities on demand, [Windi CSS] is able to provide [faster load times][video comparison] and a speedy HMR in development, and does not require purging in production.

Read more about it in the [Introduction](https://windicss.org/guide/).

## Integrations

Windi CSS provides first-class integrations for your favorite tools, select yours and get started.

| Frameworks | Package | Version |
| :-- | :-- | :-- |
| CLI | [Built-in](https://windicss.org/guide/cli) |  |
| VSCode Extension | [windicss-intellisense](https://github.com/windicss/windicss-intellisense) |  |
| Vite | [vite-plugin-windicss](https://github.com/windicss/vite-plugin-windicss) |  |
| Rollup | [rollup-plugin-windicss](https://github.com/windicss/vite-plugin-windicss/tree/main/packages/rollup-plugin-windicss) |  |
| Webpack | [windicss-webpack-plugin](https://github.com/windicss/windicss-webpack-plugin) |  |
| Nuxt | [nuxt-windicss](https://github.com/windicss/nuxt-windicss-module) |  |
| Svelte | [svelte-windicss-preprocess](https://github.com/windicss/svelte-windicss-preprocess) |  |
| StencilJS | [stencil-windicss](https://github.com/codeperate/stencil-windicss)<sup>Community</sup> |  |

## Plugins 🛠

Check out [plugins available for windicss](https://github.com/windicss/plugins).

## Documentation 📖

Check [the documentation website][website].

## Discussions

We’re using [GitHub Discussions](https://github.com/windicss/windicss/discussions) as a place to connect with other members of our community. You are free to ask questions and share ideas, so enjoy yourself.

## Contributing

If you're interested in contributing to windicss, please read our [contributing docs](https://github.com/windicss/windicss/blob/main/CONTRIBUTING.md) **before submitting a pull request**.

## Sponsors

<a href="https://opencollective.com/windicss" target="_blank">
    
</a>

## Backers
<a href="https://opencollective.com/windicss" target="_blank">
    
</a>

## License

Distributed under the [MIT License](https://github.com/windicss/windicss/blob/main/LICENSE).
