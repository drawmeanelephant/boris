<div align="center">
<!-- Title: -->


<h1><a href="https://github.com/TheAlgorithms/">The Algorithms</a> - Rust</h1>

<!-- Labels: -->
<a href="https://gitpod.io/#https://github.com/TheAlgorithms/Rust">
    
</a>
<a href="https://github.com/TheAlgorithms/Rust/actions/workflows/build.yml">
  
</a>
<a href="https://codecov.io/gh/TheAlgorithms/Rust" > 
   
</a>
<a href="https://the-algorithms.com/discord">
  
</a>
<a href="https://matrix.to/#/#TheAlgorithms_community:gitter.im">
  
</a>

<!-- Short description: -->
  <h3>All algorithms implemented in Rust - for education</h3>
</div>

### List of Algorithms
See our [directory](DIRECTORY.md) for easier navigation and a better overview of the project.

### Contributing
Read through our [Contribution Guidelines](CONTRIBUTING.md) before you contribute.
