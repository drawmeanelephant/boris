[](https://www.npmjs.com/package/react-dnd)
[](https://www.npmjs.com/package/react-dnd)
[](https://actions-badge.atrox.dev/react-dnd/react-dnd/goto?ref=main)
[](https://codecov.io/gh/react-dnd/react-dnd)
[](https://dependabot.com)

# React _DnD_

Drag and Drop for React.

See the docs, tutorials and examples on the website:

http://react-dnd.github.io/react-dnd/

See the changelog on the Releases page:

https://github.com/react-dnd/react-dnd/releases

Questions? Find us on the Reactiflux Discord Server (**#need-help**)

https://www.reactiflux.com/

### Shoutouts 🙏



Big thanks to [BrowserStack](https://www.browserstack.com) for letting the maintainers use their service to debug browser issues.
