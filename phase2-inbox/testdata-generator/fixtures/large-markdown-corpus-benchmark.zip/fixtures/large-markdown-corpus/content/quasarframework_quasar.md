

# Quasar Framework

> Build high-performance VueJS user interfaces in record time: responsive Single Page Apps, SSR Apps, PWAs, Browser extensions, Hybrid Mobile Apps and Electron Apps. If you want, all using the same codebase!

      

[](https://chat.quasar.dev)
<a href="https://forum.quasar.dev" target="_blank"></a>
[](https://good-labs.github.io/greater-good-affirmation)

[](https://github.com/quasarframework/quasar/actions/workflows/tests-on-pr.yml)

Please submit a PR to https://github.com/quasarframework/quasar-awesome with your website/app/Quasar tutorial/video etc. Thank you!

## Supporting Quasar
Quasar Framework is an MIT-licensed open source project. Its ongoing development is made possible thanks to the support by these awesome [backers](https://github.com/rstoenescu/quasar-framework/blob/dev/backers.md).

**Please read our manifest on [Why donations are important](https://quasar.dev/why-donate)**. If you'd like to become a donator, check out [Quasar Framework's Donator campaign](https://donate.quasar.dev).

### Proudly sponsored by:

<table>
  <tbody>
    <tr>
      <td align="center" valign="middle">
        <a href="https://mio.se/" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://dreamonkey.com/" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.hapag-lloyd.com/en/landingpage/quasar.html" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="http://campuscloudservices.com" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://platformpurple.com" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://irewind.com" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://truelogic.com" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://www.jugglestreet.com" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://digitalocean.com" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="http://comcomservices.com" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="http://www.kalisio.com" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://www.letsbutterfly.com/" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.projectfinance.io/" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://ib-langenthal.ch/" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://debricked.com/" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://qintil.com/" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://synestia.pl" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
        <a href="https://www.nodesol.com" target="_blank">
          
        </a>
      </td>
    </tr>
    <tr></tr>
    <tr>
      <td align="center" valign="middle">
        <a href="https://www.certible.com" target="_blank">
          
        </a>
      </td>
      <td align="center" valign="middle">
      </td>
    </tr>
  </tbody>
</table>

## Documentation

Head on to the Quasar Framework official website: [https://quasar.dev](https://quasar.dev)

## Stay in Touch

For latest releases and announcements, follow us on our Twitter account: [@quasarframework](https://twitter.com/quasarframework)

## Chat Support

Ask questions at the official community Discord server: [https://chat.quasar.dev](https://chat.quasar.dev)

## Community Forum

Ask questions at the official community forum: [https://forum.quasar.dev](https://forum.quasar.dev)

## Contributing

Please make sure to read the [Contributing Guide](./CONTRIBUTING.md) before making a pull request. If you have a Quasar-related project/component/tool, add it with a pull request to [this curated list](https://github.com/quasarframework/quasar-awesome)!

Thank you to all the people who already [contributed to Quasar](https://github.com/quasarframework/quasar/graphs/contributors)!

## Semver
Quasar is following [Semantic Versioning 2.0](https://semver.org/).

## License

Copyright (c) 2015-present Razvan Stoenescu

[MIT License](http://en.wikipedia.org/wiki/MIT_License)
