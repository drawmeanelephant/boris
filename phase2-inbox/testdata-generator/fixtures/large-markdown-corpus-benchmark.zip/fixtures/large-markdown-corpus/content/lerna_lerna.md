> **Important note: this project [recently changed stewardship to Nrwl](https://github.com/lerna/lerna/issues/3121)!**
>
> **Your favorite tool is alive and well: https://blog.nrwl.io/lerna-5-1-new-website-new-guides-new-lerna-example-repo-distributed-caching-support-and-speed-64d66410bec7**

<br />

<p align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="https://user-images.githubusercontent.com/900523/173044458-fd0b57f6-6374-4265-98b5-eb8f55fe1fb3.svg">
    
  </picture>
</p>

<p align="center">
Lerna is a fast, modern build system for managing and publishing multiple JavaScript/TypeScript packages from the same repository.
</p>

<br />

<p align="center">
    <a href="">
      
    </a>
    <a href="https://www.npmjs.com/package/lerna">
      
    </a>
    <a href="https://github.com/lerna/lerna/actions?query=branch%3Amain+workflow%3Aci">
      
    </a>
    <a href="">
      
    </a>
    <a href="https://commitizen.github.io/cz-cli/">
      
    </a>
    <a href="http://go.nx.dev/community">
      
    </a>
</p>

<hr />

<br />

A few links to help you get started:

- [lerna.js.org: Documentation, Guides, Interactive Tutorials](https://lerna.js.org)
- [Getting Started](https://lerna.js.org/docs/getting-started)
- [Features](https://lerna.js.org/docs/features)
- [Official Nx and Lerna YouTube Channel](https://www.youtube.com/@nxdevtools)
- [Blog Posts About Lerna and Nx](https://blog.nrwl.io/nx/home)

<br />

## Engage with the Core Team and the Community

- [Follow Lerna on Twitter](https://twitter.com/lernajs)
- [Community Discord, #forum channel](https://go.nx.dev/community)

### Want to help?

If you want to file a bug or submit a PR, read up on
our [guidelines for contributing](https://github.com/lerna/lerna/blob/master/CONTRIBUTING.md)

<br />

### Core Team

| Victor Savkin                                                          | James Henry                                                           | Austin Fahsl                                                            |
| ---------------------------------------------------------------------- | --------------------------------------------------------------------- | ----------------------------------------------------------------------- |
|  |  |  |
| [vsavkin](https://github.com/vsavkin)                                  | [JamesHenry](https://github.com/JamesHenry)                           | [fahslaj](https://github.com/fahslaj)                                   |

| Benjamin Cabanes                                                            | Juri Strumpflohner                                                           |
| --------------------------------------------------------------------------- | ---------------------------------------------------------------------------- |
|  |  |
| [bcabanes](https://github.com/bcabanes)                                     | [juristr](https://github.com/juristr)                                        |

<br />

### Contributors ✨

Thanks goes to these wonderful people ([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tr>
    <td align="center"><a href="https://github.com/jeffbcross"><br /><sub><b>Jeff Cross</b></sub></a><br /><a href="#business-jeffbcross" title="Business development">💼</a></td>
    <td align="center"><a href="http://evocateur.org/"><br /><sub><b>Daniel Stockman</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=evocateur" title="Code">💻</a> <a href="https://github.com/lerna/lerna/commits?author=evocateur" title="Documentation">📖</a> <a href="#infra-evocateur" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="#maintenance-evocateur" title="Maintenance">🚧</a></td>
    <td align="center"><a href="https://jamie.build/"><br /><sub><b>Jamie Kyle</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=jamiebuilds" title="Code">💻</a> <a href="https://github.com/lerna/lerna/commits?author=jamiebuilds" title="Documentation">📖</a> <a href="#infra-jamiebuilds" title="Infrastructure (Hosting, Build-Tools, etc)">🚇</a> <a href="#maintenance-jamiebuilds" title="Maintenance">🚧</a></td>
    <td align="center"><a href="https://henryzoo.com/"><br /><sub><b>Henry Zhu</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=hzoo" title="Code">💻</a> <a href="https://github.com/lerna/lerna/commits?author=hzoo" title="Documentation">📖</a> <a href="#maintenance-hzoo" title="Maintenance">🚧</a></td>
    <td align="center"><a href="http://maonoodle.com/"><br /><sub><b>Bo Borgerson</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=gigabo" title="Code">💻</a> <a href="#maintenance-gigabo" title="Maintenance">🚧</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/sebmck"><br /><sub><b>Sebastian</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=sebmck" title="Code">💻</a></td>
    <td align="center"><a href="http://www.feth.com/"><br /><sub><b>Joscha Feth</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=joscha" title="Code">💻</a> <a href="https://github.com/lerna/lerna/issues?q=author%3Ajoscha" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/noherczeg"><br /><sub><b>Norbert Csaba Herczeg</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=noherczeg" title="Code">💻</a></td>
    <td align="center"><a href="http://dougwade.io/"><br /><sub><b>Douglas Wade</b></sub></a><br /><a href="https://github.com/lerna/lerna/commits?author=doug-wade" title="Code">💻</a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the [all-contributors](https://github.com/all-contributors/all-contributors) specification. Contributions of any kind welcome!
