<p align="center">
  
  
</p>

<h1 align="center">Theme UI</h1>

<p align="center">
  <strong>The Design Graph Framework</strong>
</p>

&nbsp;

<p align="center">
  <a href="https://github.com/system-ui/theme-ui">
    
  </a>
  <a href="https://github.com/system-ui/theme-ui/stargazers">
    
  </a>
  <a>
    
  </a>
  <a>
    
  </a>
  <br />
  <a href="https://github.com/system-ui/theme-ui/graphs/contributors">
    
  </a>
  <br />
  <a href="https://badgen.net/bundlephobia/minzip/theme-ui">
    
  </a>
  <a href="https://bundlephobia.com/result?p=theme-ui">
    
  </a>
  <a href="https://github.com/system-ui/theme-ui/blob/stable/LICENSE.md">
    
  </a>
  <a href="https://discord.gg/theme-ui">
    
  </a>
  <br />
  <a href="https://dashboard.cypress.io/projects/fmfid1/runs">
    
  </a>
  <a href="https://percy.io/95212972/theme-ui">
    
  </a>
</p>

\
Theme UI is a library for creating themeable user interfaces based on constraint-based
design principles. Build custom component libraries, design systems, web applications,
Gatsby themes, and more with a flexible API for best-in-class developer ergonomics.

**[stable] docs**: https://theme-ui.com \
**[develop] (prerelease) docs**: https://dev.theme-ui.com

[stable]: https://github.com/system-ui/theme-ui/tree/stable
[develop]: https://github.com/system-ui/theme-ui/tree/develop

---

Built for design systems, white-labels, themes, and other applications where
customizing colors, typography, and layout are treated as first-class citizens
and based on a standard [Theme Specification][], Theme UI is intended to work in
a variety of applications, libraries, and other UI components. Colors,
typography, and layout styles derived from customizable theme-based design
scales help you build UI rooted in constraint-based design principles.

- The next evolution of Styled System
- From the creators of utility-based, atomic CSS methodologies
- Theme-based styling with the `sx` prop
- Compatible with virtually any UI component library
- Works with existing [Styled System][] components
- Quick mobile-first responsive styles
- Built-in support for dark modes
- Primitive page layout components
- Completely customizable with robust theming
- Built with a standard [Theme Specification][] for interoperability
- Built with [Emotion][] for scoped styles
- Plugin for use in [Gatsby][] sites and themes
- Style [MDX][] content with a simple, expressive API
- Works with [Typography.js][] themes

[emotion]: https://emotion.sh
[mdx]: https://mdxjs.com
[styled system]: https://styled-system.com
[gatsby]: https://gatsbyjs.org
[theme specification]: https://system-ui.com/theme
[typography.js]: https://github.com/KyleAMathews/typography.js

## Getting Started

```sh
npm install theme-ui @emotion/react
```

_If you don't need color modes or components you can install
[**@theme-ui/core**](https://github.com/system-ui/theme-ui/tree/develop/packages/core)_.

Any styles in your app can reference values from the global `theme` object. To
provide the theme in context, wrap your application with the `ThemeUIProvider`
component and pass in a custom `theme` object.

```jsx
// basic usage
import { ThemeUIProvider } from 'theme-ui'
import theme from './theme'

export default (props) => (
  <ThemeUIProvider theme={theme}>{props.children}</ThemeUIProvider>
)
```

The `theme` object follows the System UI
[Theme Specification](https://theme-ui.com/theme-spec/), which lets you define
custom color palettes, typographic scales, fonts, and more. Read more about
[theming](https://theme-ui.com/theming).

```js
// example theme.js
export default {
  fonts: {
    body: 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", sans-serif',
    heading: '"Avenir Next", sans-serif',
    monospace: 'Menlo, monospace',
  },
  colors: {
    text: '#000',
    background: '#fff',
    primary: '#33e',
  },
}
```

## `sx` prop

The `sx` prop works similarly to Emotion's `css` prop, accepting style objects
to add CSS directly to an element in JSX, but includes extra theme-aware
functionality. Using the `sx` prop for styles means that certain properties can
reference values defined in your `theme` object. This is intended to make
keeping styles consistent throughout your app the easy thing to do.

The `sx` prop only works in modules that have defined a custom pragma at the top
of the file, which replaces the default React JSX functions. This means you can
control which modules in your application opt into this feature without the need
for a Babel plugin or additional configuration.

```jsx
/** @jsxImportSource theme-ui */

export default (props) => (
  <div
    sx={{
      fontWeight: 'bold',
      fontSize: 4, // picks up value from `theme.fontSizes[4]`
      color: 'primary', // picks up value from `theme.colors.primary`
    }}
  >
    Hello
  </div>
)
```

Read more about
[how the custom pragma works](https://theme-ui.com/guides/how-it-works/#jsx-pragma).

## Responsive styles

The `sx` prop also supports using arrays as values to change properties
responsively with a mobile-first approach. This API originated in [Styled
System][] and is intended as
[a terser syntax for applying responsive styles](https://styled-system.com/guides/array-props)
across a singular dimension.

```jsx
/** @jsxImportSource theme-ui */

export default (props) => (
  <div
    sx={{
      // applies width 100% to all viewport widths,
      // width 50% above the first breakpoint,
      // and 25% above the next breakpoint
      width: ['100%', '50%', '25%'],
    }}
  />
)
```

---

## Documentation

- [Theming](https://theme-ui.com/theming)
- [The `sx` Prop](https://theme-ui.com/sx-prop)
- [Layout](https://theme-ui.com/layout)
- [Color Modes](https://theme-ui.com/color-modes)
- [Theme Spec](https://theme-ui.com/theme-spec)
- [Themed](https://theme-ui.com/themed)
- [MDX Components](https://theme-ui.com/mdx-components)
- [Gatsby Plugin](https://theme-ui.com/packages/gatsby-plugin)
- [API](https://theme-ui.com/api)

MIT License

## Contributors ✨

Thanks goes to these wonderful people
([emoji key](https://allcontributors.org/docs/en/emoji-key)):

<!-- ALL-CONTRIBUTORS-LIST:START - Do not remove or modify this section -->
<!-- prettier-ignore-start -->
<!-- markdownlint-disable -->
<table>
  <tr>
    <td align="center"><a href="https://jxnblk.com/"><br /><sub><b>Brent Jackson</b></sub></a><br /><a href="#ideas-jxnblk" title="Ideas, Planning, & Feedback">🤔</a> <a href="https://github.com/system-ui/theme-ui/commits?author=jxnblk" title="Code">💻</a> <a href="#design-jxnblk" title="Design">🎨</a> <a href="https://github.com/system-ui/theme-ui/commits?author=jxnblk" title="Documentation">📖</a> <a href="#example-jxnblk" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=jxnblk" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/pulls?q=is%3Apr+reviewed-by%3Ajxnblk" title="Reviewed Pull Requests">👀</a></td>
    <td align="center"><a href="https://haspar.us/"><br /><sub><b>Piotr Monwid-Olechnowicz</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=hasparus" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=hasparus" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=hasparus" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/pulls?q=is%3Apr+reviewed-by%3Ahasparus" title="Reviewed Pull Requests">👀</a> <a href="#example-hasparus" title="Examples">💡</a></td>
    <td align="center"><a href="https://github.com/dcastil"><br /><sub><b>Dany Castillo</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=dcastil" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=dcastil" title="Documentation">📖</a> <a href="#example-dcastil" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=dcastil" title="Tests">⚠️</a></td>
    <td align="center"><a href="https://jordanoverbye.com/"><br /><sub><b>Jordan Overbye</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=jordanoverbye" title="Code">💻</a> <a href="#example-jordanoverbye" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=jordanoverbye" title="Tests">⚠️</a></td>
    <td align="center"><a href="https://lachlanjc.com/"><br /><sub><b>Lachlan Campbell</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=lachlanjc" title="Code">💻</a> <a href="#example-lachlanjc" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=lachlanjc" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/pulls?q=is%3Apr+reviewed-by%3Alachlanjc" title="Reviewed Pull Requests">👀</a> <a href="https://github.com/system-ui/theme-ui/commits?author=lachlanjc" title="Documentation">📖</a> <a href="#question-lachlanjc" title="Answering Questions">💬</a></td>
    <td align="center"><a href="https://johno.com/"><br /><sub><b>John Otander</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=johno" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/pulls?q=is%3Apr+reviewed-by%3Ajohno" title="Reviewed Pull Requests">👀</a> <a href="https://github.com/system-ui/theme-ui/commits?author=johno" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=johno" title="Tests">⚠️</a> <a href="#ideas-johno" title="Ideas, Planning, & Feedback">🤔</a></td>
    <td align="center"><a href="http://twitter.com/dburles"><br /><sub><b>David Burles</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=dburles" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/pulls?q=is%3Apr+reviewed-by%3Adburles" title="Reviewed Pull Requests">👀</a> <a href="https://github.com/system-ui/theme-ui/commits?author=dburles" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/commits?author=dburles" title="Documentation">📖</a></td>
    <td align="center"><a href="https://mxstbr.com/"><br /><sub><b>Max Stoiber</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=mxstbr" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/pulls?q=is%3Apr+reviewed-by%3Amxstbr" title="Reviewed Pull Requests">👀</a> <a href="https://github.com/system-ui/theme-ui/commits?author=mxstbr" title="Tests">⚠️</a> <a href="#example-mxstbr" title="Examples">💡</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/atanasster"><br /><sub><b>Atanas Stoyanov</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=atanasster" title="Code">💻</a> <a href="#question-atanasster" title="Answering Questions">💬</a> <a href="https://github.com/system-ui/theme-ui/commits?author=atanasster" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Aatanasster" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=atanasster" title="Documentation">📖</a></td>
    <td align="center"><a href="https://www.lekoarts.de/"><br /><sub><b>Lennart</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=LekoArts" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3ALekoArts" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=LekoArts" title="Documentation">📖</a> <a href="#example-LekoArts" title="Examples">💡</a></td>
    <td align="center"><a href="https://github.com/beerose"><br /><sub><b>Aleksandra Sikora</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=beerose" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/laurieontech"><br /><sub><b>LB</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=laurieontech" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=laurieontech" title="Tests">⚠️</a></td>
    <td align="center"><a href="https://github.com/fcisio"><br /><sub><b>Francis Champagne</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=fcisio" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Afcisio" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=fcisio" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/commits?author=fcisio" title="Documentation">📖</a></td>
    <td align="center"><a href="https://alexpage.com.au/"><br /><sub><b>Alex Page</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=alex-page" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=alex-page" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/hoobdeebla"><br /><sub><b>Adam Schay</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=hoobdeebla" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/alexpermiakov"><br /><sub><b>Alex</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=alexpermiakov" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=alexpermiakov" title="Documentation">📖</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://deckchairlabs.com/"><br /><sub><b>James Edmonds</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=deckchairlabs" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=deckchairlabs" title="Documentation">📖</a></td>
    <td align="center"><a href="https://floschild.me/"><br /><sub><b>Florent SCHILDKNECHT</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=flo-sch" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=flo-sch" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/colebemis"><br /><sub><b>Cole Bemis</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=colebemis" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=colebemis" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/commits?author=colebemis" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/jletey"><br /><sub><b>John Letey</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=jletey" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/yurm04"><br /><sub><b>Yuraima Estevez</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=yurm04" title="Code">💻</a></td>
    <td align="center"><a href="http://codepen.io/allanpope/"><br /><sub><b>Allan Pope</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=allanpope" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=allanpope" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/epilande"><br /><sub><b>Emmanuel Pilande</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=epilande" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/wKovacs64"><br /><sub><b>Justin Hall</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=wKovacs64" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/marekzelinka"><br /><sub><b>Marek</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=marekzelinka" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Amarekzelinka" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://linkedin.com/in/bjoern-clees/en"><br /><sub><b>Björn Clees</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=Pyrax" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=Pyrax" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/yuyokk"><br /><sub><b>Iurii Kucherov</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=yuyokk" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/joestrouth1"><br /><sub><b>Joe Strouth</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=joestrouth1" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Ajoestrouth1" title="Bug reports">🐛</a></td>
    <td align="center"><a href="http://sjmeverett.uk/"><br /><sub><b>Stewart Everett</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=sjmeverett" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/souporserious"><br /><sub><b>Travis Arnold</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=souporserious" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=souporserious" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/ivoreis"><br /><sub><b>Ivo Reis</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=ivoreis" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/axe312ger"><br /><sub><b>Benedikt Rötsch</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/issues?q=author%3Aaxe312ger" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=axe312ger" title="Documentation">📖</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://jcofman.de/"><br /><sub><b>Jacob Cofman</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=JCofman" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/johnletey"><br /><sub><b>John Letey</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=johnletey" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/gosseti"><br /><sub><b>Lawrence Gosset</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=gosseti" title="Documentation">📖</a></td>
    <td align="center"><a href="https://markoskon.com/"><br /><sub><b>Markos Konstantopoulos</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=MarkosKon" title="Documentation">📖</a></td>
    <td align="center"><a href="https://mastodon.fedi.quebec/@waglo"><br /><sub><b>Robin Millette</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=millette" title="Code">💻</a></td>
    <td align="center"><a href="http://www.rodneyfolz.com/"><br /><sub><b>Rodney Folz</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=folz" title="Code">💻</a></td>
    <td align="center"><a href="https://pomb.us/"><br /><sub><b>Rodrigo Pombo</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=pomber" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=pomber" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/commits?author=pomber" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/mergebandit"><br /><sub><b>Scott Silvi</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=mergebandit" title="Documentation">📖</a></td>
  </tr>
  <tr>
    <td align="center"><a href="http://secularproducts.com/work/"><br /><sub><b>Shawn Allen</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=shawnbot" title="Documentation">📖</a></td>
    <td align="center"><a href="https://caurea.org/"><br /><sub><b>Tomas Carnecky</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=wereHamster" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3AwereHamster" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://johnpolacek.com/"><br /><sub><b>John Polacek</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=johnpolacek" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Ajohnpolacek" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://mackie.world/"><br /><sub><b>mackie</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=macklinu" title="Code">💻</a></td>
    <td align="center"><a href="https://www.linkedin.com/in/aaronadamsca/"><br /><sub><b>Aaron Adams</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=aaronadamsCA" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3AaaronadamsCA" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=aaronadamsCA" title="Documentation">📖</a></td>
    <td align="center"><a href="https://amberley.dev/"><br /><sub><b>Amberley</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=amberleyromo" title="Code">💻</a></td>
    <td align="center"><a href="http://andreea.xyz/"><br /><sub><b>Andreea Năstase</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=diemkay" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/ansonlowzf"><br /><sub><b>Anson Low Z.F</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/issues?q=author%3Aansonlowzf" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=ansonlowzf" title="Documentation">📖</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://bernhard.gschwantner.org/"><br /><sub><b>Bernhard Gschwantner</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=bernharduw" title="Code">💻</a></td>
    <td align="center"><a href="https://bhanu.dev/"><br /><sub><b>Bhanu Prakash Korthiwada</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=BhanuKorthiwada" title="Documentation">📖</a></td>
    <td align="center"><a href="https://twitter.com/brunolemos"><br /><sub><b>Bruno Lemos</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=brunolemos" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/vbfischer"><br /><sub><b>Bryce Fischer</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=vbfischer" title="Code">💻</a></td>
    <td align="center"><a href="http://valtism.com/"><br /><sub><b>Dan Wood</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=valtism" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/DebsDee"><br /><sub><b>Debs</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=DebsDee" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/ed0wolf"><br /><sub><b>Edward O'Reilly</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=ed0wolf" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Aed0wolf" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://eric-schaefer.com/"><br /><sub><b>Eric Schaefer</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=eschaefer" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/felixakiragreen"><br /><sub><b>Felix Green</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=felixakiragreen" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/bldng"><br /><sub><b>Gerhard Bliedung</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=bldng" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Abldng" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/guayom"><br /><sub><b>Guayo Mena</b></sub></a><br /><a href="#example-guayom" title="Examples">💡</a></td>
    <td align="center"><a href="https://github.com/guilhermelimak"><br /><sub><b>Guilherme Lima</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=guilhermelimak" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/HerbCaudill"><br /><sub><b>Herb Caudill</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=HerbCaudill" title="Documentation">📖</a></td>
    <td align="center"><a href="http://www.jacobbolda.com/"><br /><sub><b>Jacob Bolda</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=jbolda" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Ajbolda" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://learnwithjason.dev/"><br /><sub><b>Jason Lengstorf</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/issues?q=author%3Ajlengstorf" title="Bug reports">🐛</a> <a href="https://github.com/system-ui/theme-ui/commits?author=jlengstorf" title="Documentation">📖</a></td>
    <td align="center"><a href="https://jasonrundell.com/"><br /><sub><b>Jason Rundell (he/him)</b></sub></a><br /><a href="#example-jasonrundell" title="Examples">💡</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://joerace.uk/"><br /><sub><b>Joe Race</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=josephrace" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/mrkosima"><br /><sub><b>Kanstantsin Klimashevich</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=mrkosima" title="Documentation">📖</a></td>
    <td align="center"><a href="https://dev.to/@ekafyi"><br /><sub><b>Eka</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=ekafyi" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Aekafyi" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/keirwilliams"><br /><sub><b>Keir Williams</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=keirwilliams" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/kripod"><br /><sub><b>Kristóf Poduszló</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=kripod" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Akripod" title="Bug reports">🐛</a> <a href="#ideas-kripod" title="Ideas, Planning, & Feedback">🤔</a></td>
    <td align="center"><a href="https://kylegill.com/"><br /><sub><b>Kyle Gill</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=gillkyle" title="Documentation">📖</a></td>
    <td align="center"><a href="https://kylemh.com/"><br /><sub><b>Kyle Holmberg</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=kylemh" title="Documentation">📖</a></td>
    <td align="center"><a href="http://jaylaiche.com/"><br /><sub><b>Jay Laiche</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=LA1CH3" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://marcwiest.com/"><br /><sub><b>Marc Wiest</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=marcwiest" title="Code">💻</a></td>
    <td align="center"><a href="https://mteixeira.dev/"><br /><sub><b>Matheus Teixeira</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=mtxr" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/matt-cratebind"><br /><sub><b>matt-cratebind</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=matt-cratebind" title="Documentation">📖</a></td>
    <td align="center"><a href="http://twitter.com/mzabriskie"><br /><sub><b>Matt Zabriskie</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=mzabriskie" title="Code">💻</a></td>
    <td align="center"><a href="https://humble.dev/"><br /><sub><b>Maxime Khoy</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=windkomo" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/michaelfriedman"><br /><sub><b>Michael Friedman</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=michaelfriedman" title="Documentation">📖</a></td>
    <td align="center"><a href="https://weahead.se/"><br /><sub><b>Michael Zetterberg fd. Lopez</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=michaellopez" title="Code">💻</a></td>
    <td align="center"><a href="https://knowlerkno.ws/"><br /><sub><b>Nathan Knowler</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=knowler" title="Code">💻</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://flashblaze.xyz/"><br /><sub><b>Neeraj Lagwankar</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=FlashBlaze" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/theowenyoung"><br /><sub><b>Owen Young</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=theowenyoung" title="Code">💻</a></td>
    <td align="center"><a href="https://patrick.wtf/"><br /><sub><b>Patrick Arminio</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=patrick91" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Apatrick91" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://ped.ro/"><br /><sub><b>Pedro Duarte</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=peduarte" title="Code">💻</a></td>
    <td align="center"><a href="https://noutc.com/"><br /><sub><b>Ray Clanan</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=rclanan" title="Code">💻</a></td>
    <td align="center"><a href="http://www.richwerden.com/"><br /><sub><b>Rich Werden</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=r-i-c-h" title="Documentation">📖</a></td>
    <td align="center"><a href="https://www.robphoenix.com/"><br /><sub><b>Rob Phoenix</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=robphoenix" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Arobphoenix" title="Bug reports">🐛</a></td>
    <td align="center"><a href="http://moggach.com/"><br /><sub><b>Robert Moggach</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=robmoggach" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Arobmoggach" title="Bug reports">🐛</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/sanandnarayan"><br /><sub><b>Anand Narayan</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=sanandnarayan" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Asanandnarayan" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/sampoder"><br /><sub><b>Sam Poder</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=sampoder" title="Documentation">📖</a></td>
    <td align="center"><a href="https://samrose.me/"><br /><sub><b>Sam Rose</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=samrose3" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/sohrab-"><br /><sub><b>Sohrab</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=sohrab-" title="Code">💻</a></td>
    <td align="center"><a href="http://overthemonkey.com/"><br /><sub><b>Spencer Rinehart</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=nubs" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/intelligentandroid"><br /><sub><b>Steve</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=intelligentandroid" title="Documentation">📖</a></td>
    <td align="center"><a href="https://www.steve-barton.com/"><br /><sub><b>Steve Barton</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=Bevets87" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/timReynolds"><br /><sub><b>Tim Reynolds</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=timReynolds" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3AtimReynolds" title="Bug reports">🐛</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/lemes"><br /><sub><b>Vinícius Lemes</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=lemes" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/Yihwan"><br /><sub><b>Yihwan Kim</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=Yihwan" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3AYihwan" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/yuriy636"><br /><sub><b>Yuriy Burychka</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=yuriy636" title="Documentation">📖</a></td>
    <td align="center"><a href="https://github.com/Zolwiastyl"><br /><sub><b>Zolwiastyl</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=Zolwiastyl" title="Code">💻</a></td>
    <td align="center"><a href="https://isamrish.com/"><br /><sub><b>Amrish Kushwaha</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=IsAmrish" title="Code">💻</a></td>
    <td align="center"><a href="https://joebell.co.uk/"><br /><sub><b>Joe Bell</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=joe-bell" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Ajoe-bell" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/kenny-loveholidays"><br /><sub><b>kenny-loveholidays</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=kenny-loveholidays" title="Code">💻</a></td>
    <td align="center"><a href="https://lxynox.netlify.com/"><br /><sub><b>⦇⦀∙ˇ∎ˇ∙⦀⦈</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=lxynox" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Alxynox" title="Bug reports">🐛</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://github.com/navsgh"><br /><sub><b>navsgh</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=navsgh" title="Documentation">📖</a></td>
    <td align="center"><a href="https://zeevo.io/"><br /><sub><b>Shane O'Neill</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=zeevo" title="Documentation">📖</a></td>
    <td align="center"><a href="https://zce.me/"><br /><sub><b>汪磊</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=zce" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/issues?q=author%3Azce" title="Bug reports">🐛</a></td>
    <td align="center"><a href="https://github.com/carolinmaisenbacher"><br /><sub><b>Carolin Maisenbacher</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=carolinmaisenbacher" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=carolinmaisenbacher" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=carolinmaisenbacher" title="Tests">⚠️</a></td>
    <td align="center"><a href="https://twitter.com/alexandermchan"><br /><sub><b>Alex Chan</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=alexanderchan" title="Documentation">📖</a> <a href="#example-alexanderchan" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=alexanderchan" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/commits?author=alexanderchan" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/kenny-f"><br /><sub><b>Kenny</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=kenny-f" title="Code">💻</a></td>
    <td align="center"><a href="https://www.jordie.net/"><br /><sub><b>Jordie Bodlay</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=jordie23" title="Documentation">📖</a></td>
    <td align="center"><a href="https://mattglei.ch/"><br /><sub><b>Matt Gleich</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=gleich" title="Documentation">📖</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://www.wpei.me/"><br /><sub><b>William Pei</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=draekien" title="Documentation">📖</a> <a href="#example-draekien" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=draekien" title="Code">💻</a> <a href="https://github.com/system-ui/theme-ui/commits?author=draekien" title="Tests">⚠️</a></td>
    <td align="center"><a href="https://twitter.com/gpoole_is_taken"><br /><sub><b>Greg Poole</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=gpoole" title="Documentation">📖</a></td>
    <td align="center"><a href="http://www.appsparkler.com/"><br /><sub><b>Akash</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=appsparkler" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=appsparkler" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/CannonLock"><br /><sub><b>Cannon Lock</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=CannonLock" title="Documentation">📖</a></td>
    <td align="center"><a href="https://kamatte.me/"><br /><sub><b>kamatte</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=kamatte-me" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=kamatte-me" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/cobraz"><br /><sub><b>Simen A. W. Olsen</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=cobraz" title="Documentation">📖</a> <a href="#example-cobraz" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=cobraz" title="Tests">⚠️</a> <a href="https://github.com/system-ui/theme-ui/commits?author=cobraz" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/wahidrahim"><br /><sub><b>Wahid Rahim</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=wahidrahim" title="Documentation">📖</a> <a href="#example-wahidrahim" title="Examples">💡</a> <a href="https://github.com/system-ui/theme-ui/commits?author=wahidrahim" title="Code">💻</a></td>
    <td align="center"><a href="https://github.com/JustinotherGitter"><br /><sub><b>Justin Cooper</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=JustinotherGitter" title="Documentation">📖</a></td>
  </tr>
  <tr>
    <td align="center"><a href="https://devcj.in/"><br /><sub><b>CJ</b></sub></a><br /><a href="https://github.com/system-ui/theme-ui/commits?author=dev-cj" title="Documentation">📖</a> <a href="https://github.com/system-ui/theme-ui/commits?author=dev-cj" title="Code">💻</a></td>
  </tr>
</table>

<!-- markdownlint-restore -->
<!-- prettier-ignore-end -->

<!-- ALL-CONTRIBUTORS-LIST:END -->

This project follows the
[all-contributors](https://github.com/all-contributors/all-contributors)
specification. Contributions of any kind welcome!
