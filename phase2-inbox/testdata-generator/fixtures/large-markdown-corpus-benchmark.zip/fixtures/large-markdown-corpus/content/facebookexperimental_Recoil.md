# Recoil &middot; [](https://www.npmjs.com/package/recoil) [](https://github.com/facebookexperimental/Recoil/actions) [](https://github.com/facebookexperimental/Recoil/blob/main/LICENSE) [](https://twitter.com/recoiljs)

Recoil is an experimental state management framework for React.

Website: https://recoiljs.org

## Documentation

Documentation: https://recoiljs.org/docs/introduction/core-concepts


API Reference: https://recoiljs.org/docs/api-reference/core/RecoilRoot


Tutorials: https://recoiljs.org/resources

## Installation

The Recoil package lives in [npm](https://www.npmjs.com/get-npm).  Please see the [installation guide](https://recoiljs.org/docs/introduction/installation)


To install the latest stable version, run the following command:

```shell
npm install recoil
```

Or if you're using [yarn](https://classic.yarnpkg.com/en/docs/install/):

```shell
yarn add recoil
```

Or if you're using [bower](https://bower.io/#install-bower):

```shell
bower install --save recoil
```

## Contributing

Development of Recoil happens in the open on GitHub, and we are grateful to the community for contributing bugfixes and improvements. Read below to learn how you can take part in improving Recoil.

- [Code of Conduct](./CODE_OF_CONDUCT.md)
- [Contributing Guide](./CONTRIBUTING.md)

### License

Recoil is [MIT licensed](./LICENSE).
