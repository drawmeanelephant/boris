

# Markdown Badges
Add badges to your Profile and Projects.

# Table of contents
- [Markdown Badges](#markdown-badges)
- [Table of contents](#table-of-contents)
- [Usage](#usage)
- [Tips](#tips)
- [Contribution](#contribution)
- [License](#license)
- [Badges](#badges)
  - <details> <summary>List of badges</summary>
 
     - [Artificial Intelligence and Bots](#-artificial-intelligence-and-bots)
     - [Blog](#-blog)
     - [Blockchain](#-blockchain)
     - [Browsers](#-browsers)
     - [CD](#-cd)
     - [CI](#-ci)
     - [Cloud Storage](#-cloud-storage)
     - [Cryptocurrency](#-cryptocurrency)
     - [Databases](#-databases)
     - [Design](#-design)
     - [Developer/Forums](#-developerforums)
     - [Documentation Platforms](#-documentation-platforms)
     - [Education](#-education)
     - [Funding](#-funding)
     - [Frameworks, Platforms and Libraries](#-frameworks-platforms-and-libraries)
     - [Gaming](#-gaming)
     - [Game Consoles](#%EF%B8%8F-game-consoles)
     - [Hosting/SaaS](#-hostingsaas)
     - [IDEs/Editors](#-ideseditors)
     - [Languages](#-languages)
     - [ML/DL](#%EF%B8%8F-mldl)
     - [Music](#-music)
     - [Office](#-office)
     - [Operating System](#%EF%B8%8F-operating-system)
     - [ORM](#-orm)
     - [Other](#-other)
     - [Quantum Programming Frameworks and Libraries](#quantum-programming-frameworks-and-libraries)
     - [Search Engines](#search-engines)
     - [Servers](#servers)
     - [Smartphone Brands](#smartphone-brands)
     - [Social](#social)
     - [Store](#store)
     - [Streaming](#streaming)
     - [Testing](#testing)
     - [Version Control](#version-control)
     - [Wearables](#wearables)
     - [Work/Jobs](#workjobs)
   </details>


# Usage
To use a badge:
- Via GitHub
    1. Press `Ctrl` + `f` on your keyboard, to bring out the search modal.
    2. Enter the name of the badge you need.
    3. Copy the appropriate `` element and paste it in your Markdown file (e.g. README.md)
- You could also visit the live site at [ileriayo.github.io/markdown-badges/](https://ileriayo.github.io/markdown-badges/)

# Tips

<details> 
<summary>👇 How to use a different badge style</summary>
<hr>

> <strong>Note:</strong> `for-the-badge` is the style that we chose for appearance purposes. Other styles are available at [https://shields.io/#styles](https://shields.io/#styles) and can be used with the badges here. Thanks, @kingthorin for mentioning this!


Shields.io offers 5 styles, which are:
| S/N | Types         | Styles                                                                                                    |
| :-: | :------------ | :-------------------------------------------------------------------------------------------------------- |
| 1   | Plastic       |                      |
| 2   | Flat-square   |         |
| 3   | Flat          |                               |
| 4   | Social        |                         |
| 5   | For-the-badge |  |



💡 To use a different style: Replace `for-the-badge` in the markdown link with any of the styles above.
```
Example.

🧷  For plastic
https://shields.io/badge/style-plastic-green?logo=appveyor&style=plastic

🤏🏽  For Flat
https://shields.io/badge/style-flat-green?logo=appveyor&style=flat
```

</details>

<details> 
<summary>👇 Use Ctrl + F or CMD + F to search</summary>
 <hr>

 > <strong>Tip:</strong> Since there are a lot of badges, to search for the particular badge you are looking for, use Ctrl + F and type the name you want. Thanks, @JakyeRU for mentioning this!
</details>


## Contribution

The project has a separate contribution file. Please adhere to the steps listed in the separate contributions [file](./CONTRIBUTING.md)

## Contact

You can reach me on [Twitter @ileriayooo](https://twitter.com/Ileriayooo)

## License

[](./LICENSE)
<hr>
<hr>

# Badges

### 🤖 Artificial Intelligence and Bots

| Name             | Badge                                                                                                                                   | Markdown                                                                                                                                  |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| Amazon Alexa     |              | ``             |
| ChatGPT       |                        | ``                       |
| Dependabot       |                        | ``                       |
| Google Assistant |  | `` |


[(Back to top)](#table-of-contents)

### 🔗 Blockchain

| Name        | Badge                                                                                                                | Markdown                                                                                                               |
| ----------- | -------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| Hyperledger |  | `` |

[(Back to top)](#table-of-contents)

### 📝 Blog

| Name       | Badge                                                                                                             | Markdown                                                                                                            |
| ---------- | ----------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------- |
| Blogger    |           | ``          |
| Dev        |         | ``        |
| Ghost      |                | ``               |
| Hashnode   |        | ``       |
| Medium     |              | ``             |
| Micro.blog |  | `` |
| Rss        |                       | ``                      |
| Substack   | | ``    |
| Wix        |                          | ``                         |

[(Back to top)](#table-of-contents)

### 🌐 Browsers

| Name          | Badge                                                                                                                       | Markdown                                                                                                                      |
| ------------- | --------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Brave         |                           | ``                          |
| DuckDuckGo          |       | ``                   |
| Edge          |                    | ``                   |
| Firefox       |                     | ``            |
| Google Chrome |  | `` |
| IceCat        |                  | ``
| IE            |  | `` |
| Opera         |                           | ``                          |
| Safari        |                        | ``                       |
| Tor           |                         | ``                        |
| Vivaldi       |                     | ``                    |

[(Back to top)](#table-of-contents)

### 🔬 CI

| Name           | Badge                                                                                                                                 | Markdown                                                                                                                                |
| -------------- |---------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| CircleCI       |                     | ``                 |
| ChipperCI      |                     | ``                    |
| CloudBees      |                        | ``                       |
| GitLab CI      |                   | ``                  |
| GitHub Actions |  | `` |
| TeamCity       |                        | ``                       |
| Travis CI      |                    | ``                   |

[(Back to top)](#table-of-contents)

### 📲 CD

| Name           | Badge                                                                                                                          | Markdown                                                                                                                         |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------- |
| Octopus Deploy |  | `` |

[(Back to top)](#table-of-contents)

### 📂 Cloud Storage

| Name         | Badge                                                                                                                    | Markdown                                                                                                                   |
| ------------ | ------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------- |
| Dropbox      |           | ``          |
| Google Drive |  | `` |
| Mega.nz      |                 | ``                |
| Microsoft OneDrive   |        | ``       |
| Next Cloud   |        | ``       |
| OneDrive   |        | ``       |
| Proton Drive |   |  `` |

[(Back to top)](#table-of-contents)

### 💲 Cryptocurrency

| Name         | Badge                                                                                                                       | Markdown                                                                                                                      |
| ------------ | --------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Amp          |                                 | ``                                |
| Bitcoin      |                        | ``                       |
| Bitcoin Cash |  | `` |
| Bitcoin SV   |        | ``       |
| Binance      |                     | ``                    |
| Chainlink    |               | ``              |
| Dogecoin     |                  | ``                 |
| Dash         |                              | ``                             |
| Ethereum     |                  | ``                 |
| Iota         |                              | ``                             |
| Litecoin     |                  | ``                 |
| Monero       |                        | ``                       |
| Polkadot     |                  | ``                 |
| Stellar      |                     | ``                    |
| Tether       |                        | ``                       |
| Xrp          |                                  | ``                                 |
| Z Cash       |                          | ``                         |

[(Back to top)](#table-of-contents)

### 💾 Databases

| Name                 | Badge                                                                                                                                                | Markdown                                                                                                                                               |
| -------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Amazon DynamoDB      |                   | ``                  |
| Cassandra            |                    | ``                   |
| Cockroach Labs       |                      | ``                     |
| Couchbase            |                                        | ``                                       |
| Firebase             |                                           | ``                                          |
| InfluxDB             |                                           | ``                                          |
| MariaDB              |                                              | ``                                             |
| MusicBrainz          |                                 | ``                                |
| Microsoft SQL Server |  | `` |
| MongoDB              |                                       | ``                                      |
| MySQL                |                                             | ``                                               |
| Neo4J                |                                                    | ``                                                   |
| PlanetScale                |                                                    | ``                                                   |
| Postgres             |                                  | ``                                 |
| Realm                |                                                    | ``                                                   |
| Redis                |                                             | ``                                            |
| Single Store         |                              | ``                             |
| SQLite               |                                          | ``                                         |
| Supabase             |                                           | ``                                          |
| SurrealDB             |                                           | ``                                          |
| Teradata             |                                           | ``                                          |

[(Back to top)](#table-of-contents)

### 🎨 Design

| Name                    | Badge                                                                                                                                                                | Markdown                                                                                                                                                               |
| ----------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Adobe                   |                                                             | ``                                                            |
| Adobe Acrobat Reader    |           | ``          |
| Adobe After Effects     |              | ``             |
| Adobe Audition          |                                 | ``                                |
| Adobe Creative Cloud    |           | ``          |
| Adobe Dreamweaver       |                        | ``                       |
| Adobe Fonts             |                                          | ``                                         |
| Adobe Illustrator       |                     | ``                    |
| Adobe InDesign          |                                       | ``                                       |
| Adobe Lightroom         |                              | ``                             |
| Adobe Lightroom Classic |  | `` |
| Adobe Photoshop         |                           | ``                          |
| Adobe Premiere Pro      |                 | ``                |
| Adobe XD                |                                                     | ``                                                    |
| Aseprite                |                                                         | ``                                                        |
| Affinity Designer       |                       | ``                      |
| Affinity Photo          |                                   | ``                                  |
| Blender                 |                                                       | ``                                                      |
| Canva                   |                                                             | ``                                                            |
| Dribbble                |                                                           | ``                                                          |
| Figma                   |                                                             | ``                                                            |
| Framer                  |                                                                   | ``                                                                  |
| Gimp                    |                                                                      | ``                                      |
| Inkscape                |                                                          | ``                                                         |
| Invision                |                                                           | ``                                                          |
| Krita                   |                                                                   | ``                                                                  |
| Proto.io                |                                                          | ``                                                         |
| Sketch                  |                                                                 | ``                                                                |
| Storybook               |                                                       | ``                                                      |

[(Back to top)](#table-of-contents)

### 🧑‍💻 Developer/Forums

| Name           | Badge                                                                                                                                 | Markdown                                                                                                                                |
| -------------- | ------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| CodeChef       |                     | ``                    |
| Codeforces     |                      | ``                     |
| CodePen        |                               | ``                              |
| Hackerearth    |            | ``              |               
| Hackerrank    |                      | ``              |    
| LeetCode       |                          | ``                         |
| Kaggle         |                                  | ``                                 |
| OnePlus Forums |           | ``          |
| Quora          |                              | ``                             |
| Reddit         |                           | ``                          |
| ResearchGate   |                | ``               |
| Stack Exchange |     | ``    |
| Stack Overflow |          | ``         |
| XDA-Developers |  | `` |

[(Back to top)](#table-of-contents)

### 📑 Documentation Platforms

| Name      | Badge                                                                                                                 | Markdown                                                                                                                |
| --------- | --------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| Bookstack |  | `` |
| Wikipedia |  | `` |
| Wiki.js   |      | ``     |

[(Back to top)](#table-of-contents)

### 🎓 Education

| Name            | Badge                                                                                                                        | Markdown                                                                                                                       |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| Codecademy      |            | ``           |
| Codingninjas      |  | ``      |
| Codewars        |                   | ``                   |
| Coursera        |            | ``           |
| Datacamp        |                  | ``                 |
| Duolingo        |            | ``           |
| edX             |                           | ``                          |
| Exercism        |                   | ``                  |
| FreeCodeCamp    |   | `` |
| Future Learn    |      | ``     |
| GeeksforGeeks   |     | ``    |
| Khan Academy    |  | `` |
| MDN Web Docs    |          | ``         |
| Microsoft Learn |    | ``   |
| Pluralsight     |          | ``         |
| Scrimba         |                      | ``                     |
| Skill Share     |        | ``       |
| Udacity         |                       | ``                      |
| Udemy           |                            | ``                           |

[(Back to top)](#table-of-contents)

### 💰 Funding

| Name                | Badge                                                                                                                               | Markdown                                                                                                                              |
| ------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |---------------------------------------------------------------------------------------------------------------------------------------|
| Amazon Pay          |                 | ``                |
| Apple Pay           |                    | ``                   |
| Buy Me a Coffee     |  | `` |
| Github Sponsors     |           | ``          |
| Google Pay          |              | ``             |
| Ko-Fi               |                                  | ``                                 |
| LiberaPay           |                       | ``                      |
| Patreon             |                             | ``                            |
| PayPal              |                                | ``                               |
| Paytm               |                                  | ``                                 |
| Phonepe             |                             | ``                            |
| Samsung Pay         |              | ``             |
| Wise |                             | ``                            |

[(Back to top)](#table-of-contents)

### 📚 Frameworks, Platforms and Libraries

| Name               | Badge                                                                                                                                           | Markdown                                                                                                                                          |
| ------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| .NET               |                                                  | ``                                                 |
| AdonisJS           |                               | ``                              |
| Anaconda           |                               | ``                              |
| Angular            |                                  | ``                                 |
| Angular.js         |                          | ``                         |
| Ant Design         |                             | ``                            |
| Apache Spark       |                           | ``                        |
| Apache Kafka       |                                            | ``                                           |
| Apache Hadoop      |                      | ``                     |
| Apache Hive        |                            | ``                           |
| Apollo GraphQL     |                                    | ``                                   |
| Astro              |                                    | ``                                   |
| Aurelia            |                                    | ``                                   |
| Blazor             |                                     | ``                                    |
| Bootstrap          |                            | ``                           |
| Buefy              |                                              | ``                                             |
| Bulma              |                                              | ``                                             |
| Bun                |                                              | ``                                             |
|Celery              |               |``                                                          |
| Chakra UI          |                                   | ``                                  |
| Chart.js           |                                  | ``                                 |
| Code Igniter       |                     | ``                    |
| Context API        |                                                  | ``                                                 |
| DaisyUI            |  | ``                                    |
| Deno JS            |                                          | ``                                         |
| Directus           |                                  | ``                                 |
| Django             |                                     | ``                                    |
| DjangoREST         |      | ``     |
| Drupal             |                                     | ``                            |
| Electron.js        |                                   | ``                                  |
| Ember              |                                          | ``                                         |
| Expo               |                                                | ``                                               |
| Express.js         |                        | ``                       |
| FastAPI            |                                                         | ``                                                        |
| Fastify            |                                  | ``                                 |
| Flask              |                                           | ``                                          |
| Flutter            |                                  | ``                                 |
| Gatsby.js          |                                     | ``                                    |
| Green Sock         |                               | ``                              |
| Gulp               |                                           | ``                                          |
| Insomnia           |                                      | ``                                     |
| Hugo| | `` |
| Ionic              |                                | ``                                     |
|AIOHTTP             |                                    |`[AIOHTTP](https://img.shields.io/badge/iohttp-%232C5bb4.svg?style=for-the-badge&logo=aiohttp&logoColor=white)`                                   |
| Jasmine            |                                  | ``                                 |
| Jinja            |                                  | ``                                 |
| Joomla            |                          | ``                         |
| jQuery             |                                     | ``                                    |
| JWT/JSON Web Token |                                                      | ``                                                     |
| Laravel            |                                  | ``                                 |
| Less               |                                                  | ``                                                 |
| MUI                |                                              | ``                                             |
| Meteor JS          |                                | ``                               |
| MaxCompute         |                           | ``                          |
| NPM                |                                              | ``                                             |
| NestJS             |                                     | ``                                    |
| Next JS            |                                             | ``                                            |
| Node.js            |                                          | ``                                         |
| Nodemon            |                                | ``                               |
| Node-RED           |                             | ``                  |
| Nuxt JS            |                                          | ``                                        |
| Nx                 |                                                        | ``                                                       |
| OpenCV             |                                      | ``                                     |
| OpenGL             |                                                     | ``                                                    |
| P5js               |                                               | ``                                              |
| PNPM               |                                               | ``                                              |
|Poetry              |                                    |``                                          |
|Prefect             |                                  | ``                                 |
| Pug                |                                                       | ``                                                      |
| Qt                 |                                                 | ``                                                |
| Quasar             |                                            | ``                                            |
| ROS                |                                              | ``                                             |
| RabbitMQ           |                                      | ``                                     |
| Radix UI           |                                      | ``                                     |
| Rails              |                                | ``                               |
| React              |                                    | ``                                   |
| React Native       |                      | ``                     |
| React Query        |                        | ``                       |
| React Router       |                          | ``                         |
| React Hook Form    |        | ``       |
| Redux              |                                        | `` 
| Remix              |                                        | ``                                       |
| RollupJS           |                                       | ``                                     |
| RxDB               |                                           | ``                                     |
| RxJS               |                                      | ``                                     |
| SASS               |                                             | ``                                            |
| Semantic UI React  |  | `` |
| Socket.io          |                                  | ``                                 |
| SolidJS            |                                          | ``                                         |
| Spring             |                                     | ``                                    |
| Strapi             |                                     | ``                                    |
| Styled Components  |          | ``         |
| Stylus             |                                     | ``                                    |
| Svelte             |                                     | ``                                    |
| Symfony            |                                  | ``                                 |
| TailwindCSS        |                     | ``                    |
| Tauri              |                                    | ``                                   |
| Three.js           |                                        | ``                                        |
| Thymeleaf          |                            | ``                           |
| TypeGraphQL        |                                                         | ``                                                        |
| UnoCSS        |                                                         | ``                                                        |
| Vite             |                               | ``  
| Vue.js             |                               | ``                               |
| Vuetify            |                                        | ``                                       |
| WebGL              |                                               | ``                                              |
| Webpack            |                                  | ``                                 |
| Web3.js            |                                         | ``                                        |
| WindiCSS           |                                 | ``                                |
| WordPress   |         | ``        |
| Xamarin            |                                         | ``                                        |
| Yarn               |                                           | ``                                          |

[(Back to top)](#table-of-contents)

### 🎮 Gaming

| Name                | Badge                                                                                                                           | Markdown                                                                                                                          |
| ------------------- | ------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| Analogue            |                      | ``                     |
| Battle.net          |         | ``        |
| EA                  |                                 | ``                                |
| Epic Games          |           | ``          |
| Godot Engine        |                          | ``                         |
| Humble Bundle       |  | `` |
| Itch.io             |                     | ``                    |
| nVIDIA              |                     | ``                    |
| PlayStation Network |      | ``     |
| Riot Games          |              | ``             |
| Square Enix         |        | ``       |
| Steam               |                        | ``                       |
| Ubisoft             |                  | ``                 |
| Unity               |                        | ``                       |
| Unreal Engine       |  | `` |
| Xbox                |                           | ``                          |

[(Back to top)](#table-of-contents)

### 🕹️ Game Consoles

| Name             | Badge                                                                                                                                 | Markdown                                                                                                                                |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| 3DS              |                                  | ``                                 |
| Gamecube         |                   | ``                  |
| Playstation      |                   | ``                  |
| Playstation 2    |           | ``          |
| Playstation 3    |           | ``          |
| Playstation 4    |           | ``          |
| Playstation 5    |           | ``          |
| Playstation Vita |  | `` |
| Switch           |                         | ``                        |
| Wii              |                                           | ``                                          |
| Wii U            |                                    | ``                                   |
| Xbox             |                                 | ``                                |

[(Back to top)](#table-of-contents)

### ☁️ Hosting/SaaS

| Name          | Badge                                                                                                                           | Markdown                                                                                                                          |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| Alibaba Cloud |  | `` |
| AWS           |                       | ``                      |
| Azure         |               | ``              |
| Cloudflare    |                | ``               |
| Codeberg      |                      | ``                     |
| Datadog       |                  | ``                 |
| DigitalOcean  |   | ``  |
| Firebase      |                               | ``                              |
|Github Pages  |  |`` |
| Glitch        |                     | ``                    |
| Google Cloud  |    | ``   |
| Heroku        |                     | ``                    |
| Linode        |                            | ``                           |
| Netlify       |                | ``               |
| Oracle        |                            | ``                           |
| OpenStack     |            | ``           |
| OVH           |                            | ``                           |
|PythonAnywhere | |``           |
| Render        |                        | ``                       |
| Scaleway      |               | ``              |
| Vercel        |                     | ``                    |
| Vultr         |                                           | ``                                         |

[(Back to top)](#table-of-contents)

### 💻 IDEs/Editors

| Name               | Badge                                                                                                                                             | Markdown                                                                                                                                            |
| ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------- |
| Android Studio     |                | ``               |
| Atom               |                                             | ``                                            |
| CLion              |                                                  | ``                                                 |
| CodePen            |                                            | ``                                           |
| CodeSandbox        |                              | ``                             |
| Eclipse            |                                       | ``                                      |
| Emacs              |                                     | ``                                    |
| GoLand             |                                             | ``                                            |
| IntelliJ IDEA      |                      | ``                     |
| Jupyter Notebook   |                           | ``                          |
| Neovim             |                                      | ``                                     |
| NetBeans IDE       |                  | ``                 |
| Notepad++       |                  | ``                 |
| Obsidian           |                                 | ``                                |
| P5js Editor        |                                 | ``                                         |
| PhpStorm           |         | ``        |
| PyCharm            |                 | ``                |
| Replit             |                                              | ``                                             |
| Rider              |              | ``             |
| RStudio             |                                         | ``|
| Spyder              |                                     | ``                                       |
| Sublime Text       |                 | ``                 |
| Vim                |                                                | ``                                               |
| Visual Studio Code |  | `` |
| VS Code Insiders   |      | ``     |
| Visual Studio      |                   | ``                  |
| WebStorm           |                               | ``                              |
| Xcode              |                                                 | ``                                                |
| Zend               |                                                      | ``                                                     |
| Stackblitz               |                                                      | ``                                                     |

[(Back to top)](#table-of-contents)

### 📋 Languages

| Name             | Badge                                                                                                                                        | Markdown                                                                                                                                         |
| -------------    | --------------------------------------------------------------------------------------------------------------------------------             | ------------------------------------------------------------------------------------------------------------------------------------------------ |
| Apache Groovy    |              | ``               |
| Assembly Script  |       | ``    |
| C                |                                                 | ``                                                  |
| C#               |                                       | ``                                        |
| C++              |                                       | ``                                        |
| Clojure          |                            | ``                             |
| Crystal          |                               | ``                                |
| CSS3             |                                        | ``                                         |
| Dart             |                                        | ``                                         |
| Elixir           |                                  | ``                                   |
| Elm              |                                                  | ``                                                   |
| Erlang           |                                     | ``                                      |
| Fortran          |                               | ``                                |
| Go/Golang        |                                              | ``                                               |
| GraphQL          |                                     | ``                                      |
| Haskell          |                                      | ``                                       |
| HTML5            |                                     | ``                                      |
| Java             |                                        | ``                                         |
| JavaScript       |                  | ``                   |
| Julia            |                                           | ``                                            |
| Kotlin           |                                  | ``                                   |
| LaTeX            |                                     | ``                                      |
| Lua              |                                           | ``                                            |
| Markdown         |                            | ``                             |
| Nim              |                                           | ``                                            |
| Nix              |                                           | ``                                            |
| Objective-C      |                       | ``                        |
| OCaml            |                                     | ``                            |
| Octave           |                                      | ``                                       |
| Org Mode         |                                  | ``                                          |
| Perl             |                                        | ``                                         |
| PHP              |                                           | ``                                            |
| PowerShell       |                       | ``                      |
| Python           |                                        | ``                                         |
| R                |                                                 | ``                                                  |
| ReScript              |                                        | ``                                       |
| Ruby             |                                        | ``                                         |
| Rust             |                                        | ``                                         |
| Scala            |                                     | ``                                      |
| Shell Script     |                    | ``                     |
| Solidity         |                            | ``                             |
| Swift            |                                            | ``                                             |
| TypeScript       |                      | ``                       |
| Windows Terminal |  | `` |
|YAML              ||``|
| Zig              |                                           | ``                                            |

[(Back to top)](#table-of-contents)

### 🖥️ ML/DL

| Name         | Badge                                                                                                                           | Markdown                                                                                                                          |
| ------------ | ------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| Keras        |                        | ``                       |
|Matplotlib        |    | ``  
|mlflow        |                       | ``  
| NumPy        |                        | ``                       |
| Pandas       |                     | ``                    |
| Plotly       |                     | ``                    |
| PyTorch      |                  | ``                 |
| scikit-learn |  | `` |
| SciPy        |                       | ``                      |
| TensorFlow   |         | ``        |

[(Back to top)](#table-of-contents)

### 🎶 Music

| Name          | Badge                                                                                                                      | Markdown                                                                                                                     |
| ------------- | -------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Apple Music   |        | ``       |
| Audacity      |                 | ``                |
| Deezer        |                       | ``                      |
| Sound Cloud   |       | ``      |
| Spotify       |                    | ``                   |
| Shazam        |                       | ``                      |
| Tidal         |                          | ``                         |
| YouTube Music |  | `` |

[(Back to top)](#table-of-contents)

### 🏢 Office

| Name                 | Badge                                                                                                                                            | Markdown                                                                                                                                           |
| -------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------- |
| LibreOffice          |                           | ``                          |
| Microsoft            |                                    | ``                                   |
| Microsoft Access     |               | ``              |
| Microsoft Excel      |                  | ``                 |
| Microsoft Office     |               | ``              |
| Microsoft PowerPoint |   | ``  |
| Microsoft SharePoint |  | `` |
| Microsoft Visio      |                 | ``                |
| Microsoft Word       |                     | ``                    |

[(Back to top)](#table-of-contents)

### 🎛️ Operating System

| Name          | Badge                                                                                                                          | Markdown                                                                                                                         |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------------------------- |
| Alpine Linux  |  | `` |
| Android       |                        | ``                       |
| Arch          |                     | ``                    |
| Cent OS       |                      | ``                     |
| Chrome OS     |          | ``         |
| Debian        |                           | ``                          |
| Deepin        |                           | ``                          |
| Elementary OS |       | ``      |
| Fedora        |                           | ``                          |
| FreeBSD       |                    | ``                   |
| Gentoo        |                           | ``                   |
| iOS           |                                    | ``                                   |
| Kali          |                            | ``                           |
| Kubuntu       |                    | ``                   |
| Linux         |                              | ``                             |
| Linux Mint    |           | ``          |
| Lubuntu       |                    | ``                   |
| Lineageos     |                  | ``                  |
| Manjaro       |                        | ``                       |
| MX Linux      |                | ``               |
| macOS         |                         | ``                        |
| NixOS         |                         | ``                        |
| OpenWRT       |                        | ``                       |
| OpenBSD       |                    | ``                   |
| openSUSE      |                  | ``                 |
| Pop!\_OS       |                        | ``                       |
| Red Hat       |                       | ``                      |
| Rocky Linux   |       | ``      |
| Solus          |                     | `` 
| SUSE          |                                 | ``                                |
| Slackware     |              | ``             |
| Tails         |                          | ``                         |
| Ubuntu        |                           | ``                          |
| Unraid        |                    | ``                   |
| Wear OS       |                     | ``                    |
| Windows       |                        | ``                       |
| Windows 11    |                        | ``                       |
| Windows 95    |              | ``             |
| Windows XP    |              | ``             |
| Zorin OS      |                  | ``                 |

[(Back to top)](#table-of-contents)

### 🎋 ORM

| Name      | Badge                                                                                                          | Markdown                                                                                                         |
| --------- | -------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| Hibernate    |           | ``          |
| Prisma    |           | ``          |
| Sequelize |  | `` |
| Quill     |             | ``            |

[(Back to top)](#table-of-contents)

### 🥅 Other

| Name           | Badge                                                                                                                                  | Markdown                                                                                                                                 |
| -------------- | --------------------------------------------------------------------------------------------------------------------------------------| ---------------------------------------------------------------------------------------------------------------------------------------- |
| Airbnb         |                             | ``                           |
| Alfred         |                                            | ``                                           |
| Ansible        |                         | ``                        |
| Aqua Sec       |                             | ``                            |
| Arduino        |                               | ``                              |
| Babel          |                                      | ``                                     |
| Bitwarden      |                   | ``                  |
| Cisco         |                               | ``                              |
| CMake          |                               | ``                              |
| CodeCov        |                         | ``                        |
| Confluence     |                | ``               |
| Docker         |                            | ``                           |
| ESLint         |                                   | ``                                  |
| ElasticSearch  |                             | ``                            |
| Espressif      |                                                                                                                                           |``                     |
| Gradle         |                               | ``                              |
| Grafana        |                         | ``                        |
| Home Assistant |  | `` |
| Homebridge     |                | ``               |
| Jellyfin       |                     | ``                    |
| Jira           |                                  | ``                                 |
| Kubernetes     |                | ``               |
| Mosquitto      |            | ``           |
| Notion         |                            | ``                           |
| OpenSea        |                         | ``                        |
| Packer         |                        | ``                       |
| Pi-Hole        |                          | ``                         |
| Plex           |                                  | ``                                 |
| Portfolio      |                   | ``                  |
| Postman        |                                | ``                               |
| Power BI        |                                | ``                               |
| Prezi          |                               | ``                              |
| Prometheus     |                       | ``                      |
| Rancher        |                         | ``                        |
| Raspberry Pi   |                                 | ``                                |
| SonarLint         |                       | ``                           |
| SonarQube         |                       | ``                           |
| Splunk         |                            | ``                           |
| Swagger        |                           | ``                          |
| TOR            |                             | ``                            |
| Terraform      |                   | ``                  |
| Trello         |                            | ``                           |
| Uber           |                                  | ``                                 |
| Ubiquiti       |                      | ``                     |
| Vagrant        |                         | ``                        |
| Wireguard      |                   | ``                  |
| XFCE           |                                  | ``                                 |
| Zigbee         |                            | ``                           |

[(Back to top)](#table-of-contents)

### 🖥️ Quantum Programming Frameworks and Libraries

| Name   | Badge                                                                                                        | Markdown                                                                                                       |
| ------ | ------------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------------------- |
| Qiskit |  | `` |

[(Back to top)](#table-of-contents)

### 🔍 Search Engines

| Name       | Badge                                                                                                                   | Markdown                                                                                                                  |
| ---------- | ----------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Baidu      |                       | ``                      |
| Bing       |  | `` |
| DuckDuckGo |        | ``       |
| Google     |                    | ``                   |
| Yahoo!     |                    | ``                   |

[(Back to top)](#table-of-contents)

### 🗄️ Servers

| Name           | Badge                                                                                                                               | Markdown                                                                                                                              |
| -------------- | ----------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Apache         |                         | ``                        |
| Apache Airflow |    | ``   |
| Apache Ant     |                | ``               |
| Apache Flink   |          | ``         |
| Apache Maven   |          | ``         |
| Apache Tomcat  |  | `` |
| Gunicorn       |                     | ``                    |
| Jenkins        |                      | ``                     |
| Nginx          |                            | ``                           |

[(Back to top)](#table-of-contents)

### 💬 Social

| Name        | Badge                                                                                                                        | Markdown                                                                                                                       |
| ----------- | ---------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------ |
| Airtable    |                   | ``                  |
| Discord     |          | ``         |
| Facebook    |            | ``           |
| Gmail       |                            | ``                           |
| Goodreads   |               | ``              |
| Google Meet |        | ``       |
| Instagram   |         | ``        |
| KakaoTalk   |           | ``          |
| Line        |                               | ``                              |
| LinkedIn    |            | ``           |
| Linktree    |                   | ``                  |
| Meetup      |                         | ``                        |
| Messenger   |                | ``               |
| Mastodon    |               | ``              |
| Outlook     |  | `` |
| Odysee      |                  | ``                        |
| Pinterest   |         | ``        |
| Protonmail  |             | ``            |
| Polywork    |                   | ``                  |
| Reddit      |                         | ``                        |
| Signal      |                  | ``                 |
| Skype       |                     | ``                    |
| Slack       |                            | ``                           |
| Snapchat    |            | ``           |
| TeamSpeak   |                | ``               |
| Telegram    |                   | ``                  |
| Tencent QQ  |         | ``        |
| TikTok      |                  | ``                 |
| Thunderbird |      | ``                 |
| Tumblr      |                  | ``                 |
| Tutanota    |                   | ``                  |
| Twitch      |                  | ``                 |
| Viber       |                            | ``                           |
| WeChat      |                         | ``                        |
| WhatsApp    |                   | ``                  |
| Wire        |                               | ``                              |
| X     |               | ``              |
| Xbox        |                        | ``                       |
| XING        |                        | ``                       |
| YouTube     |               | ``              |
| Zoom        |                               | ``                              |
| Threads        |                        | ``                       |

[(Back to top)](#table-of-contents)

### 📱 Smartphone Brands

| Name       | Badge                                                                                                                 | Markdown                                                                                                                |
| ---------- | --------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| Apple      |              | ``             |
| ASUS       |                    | ``                   |
| BlackBerry |  | `` |
| Huawei     |           | ``          |
| Lenovo     |                  | ``                 |
| LG         |                          | ``                         |
| OnePlus    |        | ``       |
| Motorola   |     | ``    |
| Nokia      |              | ``             |
| Samsung    |        | ``       |
| Xiaomi     |           | ``          |

[(Back to top)](#table-of-contents)

### 🛍️ Store

| Name       | Badge                                                                                                               | Markdown                                                                                                              |
| ---------- | ------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| App Store  |       | ``      |
| F-Droid    |             | ``            |
| Play Store |  | `` |

[(Back to top)](#table-of-contents)

### 📺 Streaming

| Name            | Badge                                                                                                                             | Markdown                                                                                                                            |
| --------------- | --------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------- |
| Amazon Prime    |           | ``          |
| Apple TV        |                    | ``                   |
| Crunchyroll     |                | ``              |
| Facebook Gaming |  | `` |
| Facebook Live   |     | ``    |
| Fire TV         |              | ``             |
| Hulu            |                                    | ``                                   |
| Netflix         |                           | ``                          |
| Roku  |     | ``    |
| Twitch          |                              | ``                             |
| Youtube Gaming  |     | ``    |

[(Back to top)](#table-of-contents)

### 🧪 Testing

| Name            | Badge                                                                                                                               | Markdown                                                                                                                              |
| --------------- | ----------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------- |
| Cypress         |                        | ``                       |
| Jasmine         |                         | ``                        |
| Jest            |                                  | ``                                 |
| Mocha           |                               | ``                              |
| Selenium        |                        | ``                       |
| Testing Library |  | `` |

[(Back to top)](#table-of-contents)

### 🕓 Version Control

| Name           | Badge                                                                                                                      | Markdown                                                                                                                     |
| -------------- | -------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| Apache Subversion      |       | ``      |
| Bitbucket      |       | ``      |
| Forgejo        |       | ``      |
| Git            |                         | ``                        |
| Gitea          |                         | ``                        |
| Gitee          |                          | ``                         |
| GitHub         |                | ``               |
| GitLab         |                | ``               |
| Gitpod         |                   | ``                  |
| Mercurial      |          | ``         |
| Perforce Helix |  | `` |

[(Back to top)](#table-of-contents)

### ⌚️ Wearables

| Name       | Badge                                                                                                                 | Markdown                                                                                                                |
| ---------- | --------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------- |
| Fitbit      |              | ``             |

[(Back to top)](#table-of-contents)

### 💼 Work/Jobs

| Name         | Badge                                                                                                                      | Markdown                                                                                                                     |
| ------------ | -------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------- |
| AngelList    |       | ``      |
| Behance      |                    | ``                   |
| Freelancer   |           | ``          |
| Hacker Earth |  | `` |
| HackerRank   |          | ``         |
| Indeed       |                       | ``                      |
| Upwork       |                       | ``                      |


[(Back to top)](#table-of-contents)
