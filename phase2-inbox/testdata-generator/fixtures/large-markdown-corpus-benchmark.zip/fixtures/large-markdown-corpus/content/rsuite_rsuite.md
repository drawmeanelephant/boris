<p align="center">
  <a href="https://rsuitejs.com" target="_blank" rel="noopener noreferrer">
   
  </a>
</p>

English | [中文版][readm-cn]

[![npm][npm-svg]][npm-home]
[![GitHub Actions][actions-svg]][actions-home]
[![npm bundle size][npm-bundle-size-img]][npm-bundle-size]
[![rsuite.min.js][rsuite-min-js-img]][rsuite-min-js]
[![codecov][codecov-img]][codecov]
[![Discord][discord-svg]][discord-invite]
[![Gitter][gitter-svg]][gitter]
[![Gitter][gitter-cn-svg]][gitter-cn]
[![Gitpod ready-to-code][gitpod-img]][gitpod]

React Suite is a set of react component libraries for enterprise system products. It is a well-thought-out and developer-friendly UI framework.

### UI Design

React Suite Design Prototype and specification, click to [view][rsuite-design].

## Supported Platforms

### Browser

React Suite supports the latest, stable releases of all major browsers and platforms. IE<=10 is no longer supported since React Suite 5.0. React Suite is designed and implemented for use on modern desktop browsers rather than mobile browsers.

| IE   | Edge | Firefox | Chrome | Safari |
| ---- | ---- | ------- | ------ | ------ |
| >=11 | >=14 | >= 45   | >= 49  | >= 10  |

### Server

React Suite supports server side rendering. Support [Next.js](https://github.com/zeit/next.js) to build applications.

## Supported development environment

- Supports React 16 +
- Supports [TypeScript](http://www.typescriptlang.org/)
- Supports [Electron](https://electronjs.org/)
- Supports [Reason](https://github.com/shurygindv/bs-rsuite-ui-react)

## Installation

React Suite is available as an [npm package][npm-home].

```bash
npm i rsuite --save
```

or if you prefer Yarn

```bash
yarn add rsuite
```

## Usage

Here's a simple example

```jsx
import { Button } from 'rsuite';
import 'rsuite/styles/index.less'; // or 'rsuite/dist/rsuite.min.css'

function App() {
  return <Button appearance="primary">Hello World</Button>;
}
```

[**Live preview on CodeSandbox**][live-preview-on-codesandbox]

### Documentation

You can go through [full documentation][rsuite-doc-guide] or start with following sections

- [Quick start][rsuite-doc-guide]
- [Less Customization][rsuite-doc-guide-themes]
- [Internationalization][rsuite-doc-guide-intl]
- [Right-to-left][rsuite-doc-guide-rtl]
- [Components][rsuite-components-overview]

<details>
<summary>More examples</summary>

- [Management system][demo-admin]
- [Use modularized][demo-modular-import]
- [Use CDN][demo-cdn]
- [Internationalization][demo-intl-app]
- [Themes][demo-multiple-themes]
- [RTL - RTLCSS][demo-rtlcss]
- [RTL - PostCSS-RTL][demo-postcss-rtl]
- [Use in create-react-app][demo-create-react-app]
- [Use in Electron][demo-electron]
- [Use in Flow][demo-flow-app]
- [Use in TypeScript][demo-typescript-app]
- [Use in Next.js (App)][demo-nextjs-app]
- [Use in Next.js (Pages)][demo-nextjs-pages]
- [Use in UmiJS][demo-umi-app]
- [Use in Snowpack][demo-snowpack]
- [Use in Vite][demo-vite]
</details>

<a href="https://vercel.com?utm_source=rsuite&utm_campaign=oss" target="_blank">
  
</a>

## Previous major versions

The previous major version 4.x will no longer receive new features,
and it is recommended to upgrade to the latest 5.x releases.
Bug fixes for 4.x are still being supported for a period of time,
and security fixes are supported until 6.x is in progress.

### Documentations for previous major versions

- [4.x documentation](https://v4.rsuitejs.com/)
- [3.x documentation](https://v3.rsuitejs.com/)

## Changelog

Detailed changes for each release are documented in the [release notes][release-notes].

## Contribution

Make sure you've read the [guidelines][contributing] before you start contributing.

## Supporting React Suite

If you like React Suite, you can show your support by either

- Starring this repo
- [Leaving a comment here][issues-11] if you are using React Suite in your project (like we do :smile:)
- [Becoming a backer][opencollective-home] on OpenCollective

This project exists thanks to all the people who contribute.

<a href="https://github.com/rsuite/rsuite/graphs/contributors" target="_blank">
  
</a>

[![opencollective-now][opencollective-svg]][opencollective-home]

## License

React Suite is [MIT licensed][license]. Copyright (c) 2016-present, HYPERS.

[readm-cn]: https://github.com/rsuite/rsuite/blob/main/README_zh.md
[npm-svg]: https://img.shields.io/npm/v/rsuite
[npm-home]: https://www.npmjs.com/package/rsuite
[npm-bundle-size-img]: https://badgen.net/bundlephobia/minzip/rsuite?icon=npm
[npm-bundle-size]: https://bundlephobia.com/package/rsuite
[rsuite-min-js-img]: https://img.badgesize.io/https:/unpkg.com/rsuite/dist/rsuite.min.js?label=rsuite.min.js&compression=gzip
[rsuite-min-js]: https://unpkg.com/browse/rsuite/dist/rsuite.min.js
[actions-svg]: https://github.com/rsuite/rsuite/workflows/Node.js%20CI/badge.svg?branch=main
[actions-home]: https://github.com/rsuite/rsuite/actions?query=branch%3Amain+workflow%3A%22Node.js+CI%22
[discord-svg]: https://img.shields.io/badge/Discord-Join%20chat%20%E2%86%92-738bd7.svg
[discord-invite]: https://discord.gg/R8mnjwh
[rsuite-design]: https://rsuitejs.com/design/default
[live-preview-on-codesandbox]: https://codesandbox.io/s/rsuite-template-5vq6zo2z5l
[rsuite-doc-guide]: https://rsuitejs.com/en/guide/introduction
[rsuite-doc-guide-themes]: https://rsuitejs.com/en/guide/customization-less
[rsuite-doc-guide-intl]: https://rsuitejs.com/en/guide/intl
[rsuite-doc-guide-rtl]: https://rsuitejs.com/en/guide/rtl
[rsuite-components-overview]: https://rsuitejs.com/en/components/overview
[release-notes]: https://github.com/rsuite/rsuite/releases
[contributing]: https://github.com/rsuite/rsuite/blob/main/CONTRIBUTING.md
[prettierrc]: https://github.com/rsuite/rsuite/wiki/.prettierrc
[issues-11]: https://github.com/rsuite/rsuite/issues/11
[opencollective-svg]: https://opencollective.com/rsuite/tiers/backer.svg?avatarHeight=36
[opencollective-home]: https://opencollective.com/rsuite
[license]: https://github.com/rsuite/rsuite/blob/main/LICENSE
[rsuite-sample]: https://sample.rsuitejs.com/
[gitter]: https://gitter.im/rsuite/rsuite?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge
[gitter-svg]: https://img.shields.io/gitter/room/rsuite/rsuite?label=chat-english
[gitter-cn]: https://gitter.im/rsuite/rsuite-CN?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge
[gitter-cn-svg]: https://img.shields.io/gitter/room/rsuite/rsuite?label=chat-chinese
[demo-admin]: https://github.com/rsuite/rsuite-management-system
[demo-modular-import]: https://github.com/rsuite/rsuite/tree/main/examples/with-babel-preset-rsuite
[demo-cdn]: https://github.com/rsuite/rsuite/tree/main/examples/cdn
[demo-create-react-app]: https://github.com/rsuite/rsuite/tree/main/examples/create-react-app
[demo-electron]: https://github.com/rsuite/rsuite/tree/main/examples/with-electron
[demo-intl-app]: https://github.com/rsuite/rsuite/tree/main/examples/custom-i18n
[demo-multiple-themes]: https://github.com/rsuite/rsuite/tree/main/examples/custom-multiple-themes
[demo-flow-app]: https://github.com/rsuite/rsuite/tree/main/examples/with-flow
[demo-typescript-app]: https://github.com/rsuite/rsuite/tree/main/examples/with-typescript
[demo-nextjs-app]: https://github.com/rsuite/rsuite/tree/main/examples/with-nextjs-app
[demo-nextjs-pages]: https://github.com/rsuite/rsuite/tree/main/examples/with-nextjs-pages
[demo-umi-app]: https://github.com/rsuite/rsuite/tree/main/examples/with-umi
[demo-rtlcss]: https://github.com/rsuite/rsuite/tree/main/examples/with-rtlcss
[demo-postcss-rtl]: https://github.com/rsuite/rsuite/tree/main/examples/with-postcss-rtl
[demo-snowpack]: https://github.com/rsuite/rsuite/tree/main/examples/with-snowpack
[demo-vite]: https://github.com/rsuite/rsuite/tree/main/examples/with-vite
[codecov]: https://codecov.io/gh/rsuite/rsuite
[codecov-img]: https://codecov.io/gh/rsuite/rsuite/branch/main/graph/badge.svg?token=HGeKd0BD3t
[gitpod]: https://gitpod.io/#https://github.com/rsuite/rsuite
[gitpod-img]: https://img.shields.io/badge/Gitpod-ready--to--code-blue?logo=gitpod
