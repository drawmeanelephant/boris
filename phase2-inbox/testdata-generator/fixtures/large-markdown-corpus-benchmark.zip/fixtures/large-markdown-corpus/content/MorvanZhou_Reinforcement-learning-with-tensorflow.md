<p align="center">
    <a href="https://www.youtube.com/watch?v=pieI7rOXELI&list=PLXO45tsB95cIplu-fLMpUEEZTwrDNh6Ba" target="_blank">
    
    </a>
</p>


<br>

# Reinforcement Learning Methods and Tutorials

In these tutorials for reinforcement learning, it covers from the basic RL algorithms to advanced algorithms developed recent years.

**If you speak Chinese, visit [莫烦 Python](https://mofanpy.com) or my [Youtube channel](https://www.youtube.com/channel/UCdyjiB5H8Pu7aDTNVXTTpcg) for more.**

**As many requests about making these tutorials available in English, please find them in this playlist:** ([https://www.youtube.com/playlist?list=PLXO45tsB95cIplu-fLMpUEEZTwrDNh6Ba](https://www.youtube.com/playlist?list=PLXO45tsB95cIplu-fLMpUEEZTwrDNh6Ba))

# Table of Contents

* Tutorials
    * [Simple entry example](contents/1_command_line_reinforcement_learning)
    * [Q-learning](contents/2_Q_Learning_maze)
    * [Sarsa](contents/3_Sarsa_maze)
    * [Sarsa(lambda)](contents/4_Sarsa_lambda_maze)
    * [Deep Q Network (DQN)](contents/5_Deep_Q_Network)
    * [Using OpenAI Gym](contents/6_OpenAI_gym)
    * [Double DQN](contents/5.1_Double_DQN)
    * [DQN with Prioitized Experience Replay](contents/5.2_Prioritized_Replay_DQN)
    * [Dueling DQN](contents/5.3_Dueling_DQN)
    * [Policy Gradients](contents/7_Policy_gradient_softmax)
    * [Actor-Critic](contents/8_Actor_Critic_Advantage)
    * [Deep Deterministic Policy Gradient (DDPG)](contents/9_Deep_Deterministic_Policy_Gradient_DDPG)
    * [A3C](contents/10_A3C)
    * [Dyna-Q](contents/11_Dyna_Q)
    * [Proximal Policy Optimization (PPO)](contents/12_Proximal_Policy_Optimization)
    * [Curiosity Model](/contents/Curiosity_Model), [Random Network Distillation (RND)](/contents/Curiosity_Model/Random_Network_Distillation.py)
* [Some of my experiments](experiments)
    * [2D Car](experiments/2D_car)
    * [Robot arm](experiments/Robot_arm)
    * [BipedalWalker](experiments/Solve_BipedalWalker)
    * [LunarLander](experiments/Solve_LunarLander)

# Some RL Networks
### [Deep Q Network](contents/5_Deep_Q_Network)

<a href="contents/5_Deep_Q_Network">
    
</a>

### [Double DQN](contents/5.1_Double_DQN)

<a href="contents/5.1_Double_DQN">
    
</a>

### [Dueling DQN](contents/5.3_Dueling_DQN)

<a href="contents/5.3_Dueling_DQN">
    
</a>

### [Actor Critic](contents/8_Actor_Critic_Advantage)

<a href="contents/8_Actor_Critic_Advantage">
    
</a>

### [Deep Deterministic Policy Gradient](contents/9_Deep_Deterministic_Policy_Gradient_DDPG)

<a href="contents/9_Deep_Deterministic_Policy_Gradient_DDPG">
    
</a>

### [A3C](contents/10_A3C)

<a href="contents/10_A3C">
    
</a>

### [Proximal Policy Optimization (PPO)](contents/12_Proximal_Policy_Optimization)

<a href="contents/12_Proximal_Policy_Optimization">
    
</a>

### [Curiosity Model](/contents/Curiosity_Model)

<a href="/contents/Curiosity_Model">
    
</a>

# Donation

*If this does help you, please consider donating to support me for better tutorials. Any contribution is greatly appreciated!*

<div >
  <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&amp;business=morvanzhou%40gmail%2ecom&amp;lc=C2&amp;item_name=MorvanPython&amp;currency_code=AUD&amp;bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHosted">
    </a>
</div>

<div>
  <a href="https://www.patreon.com/morvan">
    </a>
</div>
