# Fsociety Hacking Tools Pack

[](https://www.python.org/downloads/release/python-2714/) 
 
 
[](https://github.com/Manisso/fsociety/blob/master/LICENSE)

A Penetration Testing Framework, you will have every script that a hacker needs. Works with Python 2. For a Python 3 version see our updated version at [`fsociety-team/fsociety`](https://github.com/fsociety-team/fsociety).

## Fsociety Contains All Tools Used in Mr. Robot Series

[](https://wikipedia.org/wiki/Mr._Robot)

## Menu

- Information Gathering
- Password Attacks
- Wireless Testing
- Exploitation Tools
- Sniffing & Spoofing
- Web Hacking
- Private Web Hacking
- Post Exploitation
- Contributors
- Install & Update

### Information Gathering:

- Nmap
- Setoolkit
- Host To IP
- WPScan
- CMS Scanner
- XSStrike
- Dork - Google Dorks Passive Vulnerability Auditor
- Scan A server's Users
- Crips

### Password Attacks:

- Cupp
- Ncrack

### Wireless Testing:

- Reaver
- Pixiewps
- Bluetooth Honeypot

### Exploitation Tools:

- ATSCAN
- sqlmap
- Shellnoob
- Commix
- FTP Auto Bypass
- JBoss Autopwn

### Sniffing & Spoofing:

- Setoolkit
- SSLtrip
- pyPISHER
- SMTP Mailer

### Web Hacking:

- Drupal Hacking
- Inurlbr
- Wordpress & Joomla Scanner
- Gravity Form Scanner
- File Upload Checker
- Wordpress Exploit Scanner
- Wordpress Plugins Scanner
- Shell and Directory Finder
- Joomla! 1.5 - 3.4.5 remote code execution
- Vbulletin 5.X remote code execution
- BruteX - Automatically brute force all services running on a target
- Arachni - Web Application Security Scanner Framework

### Private Web Hacking:

- Get all websites
- Get joomla websites
- Get wordpress websites
- Control Panel Finder
- Zip Files Finder
- Upload File Finder
- Get server users
- SQli Scanner
- Ports Scan (range of ports)
- Ports Scan (common ports)
- Get server Info
- Bypass Cloudflare

### Post Exploitation:

- Shell Checker
- POET
- Weeman

# Installation

## Installation [Linux](https://wikipedia.org/wiki/Linux) [](https://fr.wikipedia.org/wiki/Linux)

```bash
bash <(wget -qO- https://git.io/vAtmB)
```

## Installation

Download [Termux](https://play.google.com/store/apps/details?id=com.termux)

```bash
bash <(wget -qO- https://git.io/vAtmB)
```

Follow this video [Arif - Tech](https://www.youtube.com/watch?v=JwK5oOBjpgQ)

## Installation [Windows](https://wikipedia.org/wiki/Microsoft_Windows)[](https://fr.wikipedia.org/wiki/Microsoft_Windows)

Download Linux Bash Like [Cygwin](https://www.cygwin.com/)

Download [Python](https://www.python.org/downloads/release/python-2714/)

Use Google Cloud Console [Cloud Shell](https://console.cloud.google.com/cloudshell/editor?project=&pli=1&shellonly=true)

Or use free Ubuntu VPS [c9.io](https://c9.io/)

## [Docker](https://en.wikipedia.org/wiki/Docker_(software)) Usage 

### Dependecies

[Docker](https://www.docker.com/)

[Docker-compose](https://docs.docker.com/compose/install/)

```bash
docker-compose build
docker-compose up -d
docker-compose exec fsociety fsociety
docker-compose down # destroys instance
```

# Screenshots

[](https://asciinema.org/a/URj2nvpbYpeJyJe43KlASZ7fz)



# Contributors

[alexcreek](https://github.com/alexcreek)

[mswell](https://github.com/mswell)

[Ev3](https://github.com/Ev3)

[huangsam](https://github.com/huangsam)

[RyanFilho](https://github.com/RyanFilho)

[gabru-md](https://github.com/gabru-md)

[jdrago999](https://github.com/jdrago999)

[CRO-TheHacker](https://github.com/CRO-THEHACKER)

# License

[MIT Licence](https://github.com/Manisso/fsociety/blob/master/LICENSE)
