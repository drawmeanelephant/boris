<p align="center">
  <a href="https://reach.tech/router/">
    
  </a>
</p>

<p align="center">
  Next Generation Routing for <a href="https://facebook.github.io/react">React</a>
</p>

<p align="center">
  <a href="https://www.npmjs.com/package/@reach/router"></a>
  <a href="https://www.npmjs.com/package/@reach/router"></a>
  <a href="https://travis-ci.org/reach/router"></a>
</p>

## Documentation

[Documentation Site](https://reach.tech/router)

You can also find the docs in the [website directory](./website/src/markdown).

## Community

[Join us on Spectrum](https://spectrum.chat/reach)

## Legal

MIT License
Copyright (c) 2018-present, Ryan Florence
